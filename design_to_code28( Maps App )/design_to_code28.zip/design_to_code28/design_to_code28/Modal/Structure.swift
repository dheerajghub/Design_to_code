//
//  Structure.swift
//  design_to_code28
//
//  Created by Dheeraj Kumar Sharma on 28/03/21.
//

import Foundation

struct Places {
    let type: String!
    let locations: [Location]!
}

struct Location {
    let index: Int!
    let title: String!
    let latitude: Double!
    let longitude: Double!
}

let places = [
    Places (
    type: "cafe",
    locations: [
        Location(index: 0, title: "Hide out cafe", latitude: 31.10479702423062, longitude: 77.17292657057098),
        Location(index: 1,title: "Book cafe", latitude: 31.10504964673161, longitude: 77.17592528000891),
        Location(index: 2,title: "cafe coffee day", latitude: 31.10446631739544, longitude: 77.1746646418731),
        Location(index: 3,title: "Honey Hut cafe", latitude: 31.104342302035313, longitude: 77.17500260018186),
        Location(index: 4,title: "Indian coffee house", latitude: 31.105461001462334, longitude: 77.1709375077356)
    ]
) ,
    Places (
    type: "restaurant",
    locations: [
        Location(index: 0,title: "Scandal Delights Bar & Restaurant", latitude: 31.104959334312724, longitude: 77.17255066104718),
        Location(index: 1,title: "Aunty's", latitude: 31.104826170242063, longitude: 77.1724964081464),
        Location(index: 2,title: "Goofa Ashiana Restaurant", latitude: 31.104612506434727, longitude: 77.17418639241245),
        Location(index: 3,title: "Guptaji vaishnav bhojnalaya", latitude: 31.10436152284812, longitude: 77.17402217468414),
        Location(index: 4,title: "Brunch-Shimla", latitude: 31.10499225105471, longitude: 77.17447907992941),
        Location(index: 5,title: "Dobby's", latitude: 31.10518790154428, longitude: 77.17155763636052),
        Location(index: 6,title: "Paitpooja Restaurant", latitude: 31.103960968372807, longitude: 77.17126023217482),
        Location(index: 7,title: "Rendezvous Bar & Restaurant", latitude: 31.105484261112014, longitude: 77.17278059843069),
        Location(index: 8,title: "Alacatre Restaurant & Bar", latitude: 31.105445204957007, longitude: 77.17279951185856),
        Location(index: 9,title: "La Pino'z Pizza", latitude: 31.103746719492765, longitude: 77.17380770346321),
    ]
) ,
    Places (
    type: "clothes",
    locations: [
        Location(index: 0,title: "Lakar bazar market", latitude: 31.10544841202586, longitude: 77.17456334265104),
        Location(index: 1,title: "Skechers", latitude: 31.105545903907807, longitude: 77.17277775685872),
        Location(index: 2,title: "Tibetan Refugee Market", latitude: 31.105393170390407, longitude: 77.17252537918384),
        Location(index: 3,title: "REC Padam Dev Complex", latitude: 31.105034335973652, longitude: 77.17491895128815),
        Location(index: 4,title: "Jaipuri Emporium", latitude: 31.10417562867378, longitude: 77.17383356452356),
        Location(index: 5,title: "Tibetian Arts", latitude: 31.10521899734762, longitude: 77.17686221671758),
        Location(index: 6,title: "Landmark", latitude: 31.103543249471958, longitude: 77.17650093336435),
        Location(index: 7,title: "Maria Brothers", latitude: 31.103732454272567, longitude: 77.17588373249191)
    ]
) ,
    Places (
    type: "bar",
    locations: [
        Location(index: 0,title: "Letalboot", latitude: 31.104851048172446, longitude: 77.17340199927898),
        Location(index: 1,title: "Splash Bar", latitude: 31.10459781583516, longitude: 77.17390226502084),
        Location(index: 2,title: "La Glace Bar", latitude: 31.104546630494724, longitude: 77.1736977538741),
        Location(index: 3,title: "Topaz Restro Bar", latitude: 31.104136442032285, longitude: 77.1764881049552),
        Location(index: 4,title: "Sol Lounge", latitude: 31.102394342797513, longitude: 77.17704003283431),
        Location(index: 5,title: "Cloud Nine Bar", latitude: 31.102234566340535, longitude: 77.17708108506628),
        Location(index: 6,title: "Scandal Bar",  latitude: 31.104935505801524, longitude: 77.17255475089455),
        Location(index: 7,title: "Himani Bar", latitude: 31.104352830387214, longitude: 77.17376415042732)
    ]
) ,
    Places (
    type: "theatre",
    locations: [
        Location(index: 0,title: "Himachal Pradesh Sirmour", latitude: 31.104969416746354, longitude: 77.17338233516607),
        Location(index: 1,title: "Kukreja Movies Shimla", latitude: 31.1047213871782, longitude: 77.17035680364015),
        Location(index: 2,title: "Shahi Theatre", latitude: 31.104335562117868, longitude: 77.17007785392498),
        Location(index: 3,title: "Freemason Hall", latitude: 31.104298816792266, longitude: 77.17683702009992),
        Location(index: 4,title: "Ritz Cineplex", latitude: 31.104014040036816, longitude: 77.17676191825353),
        Location(index: 5,title: "Rigel theatre", latitude: 31.10541954282649, longitude: 77.17706232563908)
    ]
) ,
    Places (
    type: "gas",
    locations: [
        Location(index: 0,title: "Bharat Petroleum Pump", latitude: 31.105109597141688, longitude: 77.20353870550731),
        Location(index: 1,title: "Indian Oil", latitude: 31.10377566300916, longitude: 77.20020030341607),
        Location(index: 2,title: "Indian Oil Petrol Pump", latitude: 31.095898717607216, longitude: 77.18135687827888),
        Location(index: 3,title: "LPG Gas Godown", latitude: 31.092214115693668, longitude: 77.20687710759856),
        Location(index: 4,title: "HRTC Petrol Pump", latitude: 31.108857216571405, longitude: 77.21236692437081),
        Location(index: 5,title: "Himfed Petrol Pump", latitude: 31.10441087207581, longitude: 77.17349308668616),
        Location(index: 6,title: "Hindistan Petroleum", latitude: 31.09791616079269, longitude: 77.14008480255774),
        Location(index: 7,title: "Hp Petrol Pump", latitude: 31.086034467992814, longitude: 77.17749577573477)
    ]
)
]

struct PlaceDetail {
    let type: String!
    let places:[PlacesInfo]!
}

struct PlacesInfo {
    let img: String!
    let placeName: String!
    let rating: String!
    let status: String!
}

let placesDetail = [
    PlaceDetail(type: "cafe", places: [
        PlacesInfo(img: "img1", placeName: "Hide Out Cafe", rating: "4.3", status: "Open now: 8am - 10:15pm"),
        PlacesInfo(img: "img2", placeName: "Book Cafe", rating: "4.4", status: "Open now: 8:45am - 10pm"),
        PlacesInfo(img: "img3", placeName: "Cafe Cofee Day", rating: "4.1", status: "Open now: 10am - 9pm"),
        PlacesInfo(img: "img4", placeName: "Honey Hut Cafe", rating: "4.4", status: "Open now: 9am - 10pm"),
        PlacesInfo(img: "img5", placeName: "Indian Coffee House", rating: "3.9", status: "Open now: 8am - 8pm")
    ]),
    
    PlaceDetail(type: "restaurant", places: [
        PlacesInfo(img: "img6", placeName: "Scandal Delights Bar & Restaurant", rating: "3.9", status: "Open now: 9am - 10:30pm"),
        PlacesInfo(img: "img7", placeName: "Aunty's", rating: "4.1", status: "Open now: 11am - 9:30pm"),
        PlacesInfo(img: "img8", placeName: "Goofa Ashiana Restaurant", rating: "3.9", status: "Open now: 9am - 10:30pm"),
        PlacesInfo(img: "img9", placeName: "Guptaji Vaishnav Bhojnalaya", rating: "4.1", status: "Close Today"),
        PlacesInfo(img: "img10", placeName: "Brunch-Shimla", rating: "4.9", status: "Closed Today"),
        PlacesInfo(img: "img11", placeName: "Dobby's", rating: "4.3", status: "Open now: 10am - 9pm"),
        PlacesInfo(img: "img12", placeName: "Paitpooja Restaurant", rating: "4.1", status: "Open now: 7am - 11pm"),
        PlacesInfo(img: "img13", placeName: "Rendezvous Bar & Restaurant", rating: "3.9", status: "Open now: 11am - 11pm"),
        PlacesInfo(img: "img14", placeName: "Alacatre Restaurant & Bar", rating: "4.1", status: "Open now: 11am - 10pm"),
        PlacesInfo(img: "img15", placeName: "La Pino'z Pizza", rating: "3.7", status: "Open now: 11am - 10:30pm")
    ]),
    
    PlaceDetail(type: "clothes", places: [
        PlacesInfo(img: "img16", placeName: "Lakar Bazar Market", rating: "4.2", status: "Open now: 7:35am - 10pm"),
        PlacesInfo(img: "img17", placeName: "Skechers", rating: "3.8", status: "Open now: 10am - 10pm"),
        PlacesInfo(img: "img18", placeName: "Tibetan Refugee Market", rating: "3.9", status: "Closed Today"),
        PlacesInfo(img: "img19", placeName: "REC Padam Dev Complex", rating: "4.0", status: "Close Today"),
        PlacesInfo(img: "img20", placeName: "Jaipuri Emporium", rating: "3.0", status: "Closed Today"),
        PlacesInfo(img: "img21", placeName: "Tibetian Arts", rating: "4.0", status: "Open now: 8am - 6pm"),
        PlacesInfo(img: "img22", placeName: "Landmark", rating: "4.1", status: "Open now: 12am - 9:30pm"),
        PlacesInfo(img: "img23", placeName: "Maria Brothers", rating: "4.5", status: "Closed Today")
    ]),
    
    PlaceDetail(type: "bar", places: [
        PlacesInfo(img: "img16", placeName: "Lakar Bazar Market", rating: "4.2", status: "Open now: 7:35am - 10pm"),
        PlacesInfo(img: "img17", placeName: "Skechers", rating: "3.8", status: "Open now: 10am - 10pm"),
        PlacesInfo(img: "img18", placeName: "Tibetan Refugee Market", rating: "3.9", status: "Closed Today"),
        PlacesInfo(img: "img19", placeName: "REC Padam Dev Complex", rating: "4.0", status: "Close Today"),
        PlacesInfo(img: "img20", placeName: "Jaipuri Emporium", rating: "3.0", status: "Closed Today"),
        PlacesInfo(img: "img21", placeName: "Tibetian Arts", rating: "4.0", status: "Open now: 8am - 6pm"),
        PlacesInfo(img: "img22", placeName: "Landmark", rating: "4.1", status: "Open now: 12am - 9:30pm"),
        PlacesInfo(img: "img23", placeName: "Maria Brothers", rating: "4.5", status: "Closed Today")
    ]),
    
    PlaceDetail(type: "theatre", places: [
        PlacesInfo(img: "img16", placeName: "Lakar Bazar Market", rating: "4.2", status: "Open now: 7:35am - 10pm"),
        PlacesInfo(img: "img17", placeName: "Skechers", rating: "3.8", status: "Open now: 10am - 10pm"),
        PlacesInfo(img: "img18", placeName: "Tibetan Refugee Market", rating: "3.9", status: "Closed Today"),
        PlacesInfo(img: "img19", placeName: "REC Padam Dev Complex", rating: "4.0", status: "Close Today"),
        PlacesInfo(img: "img20", placeName: "Jaipuri Emporium", rating: "3.0", status: "Closed Today"),
        PlacesInfo(img: "img21", placeName: "Tibetian Arts", rating: "4.0", status: "Open now: 8am - 6pm")
    ]),
    
    PlaceDetail(type: "gas", places: [
        PlacesInfo(img: "img16", placeName: "Lakar Bazar Market", rating: "4.2", status: "Open now: 7:35am - 10pm"),
        PlacesInfo(img: "img17", placeName: "Skechers", rating: "3.8", status: "Open now: 10am - 10pm"),
        PlacesInfo(img: "img18", placeName: "Tibetan Refugee Market", rating: "3.9", status: "Closed Today"),
        PlacesInfo(img: "img19", placeName: "REC Padam Dev Complex", rating: "4.0", status: "Close Today"),
        PlacesInfo(img: "img20", placeName: "Jaipuri Emporium", rating: "3.0", status: "Closed Today"),
        PlacesInfo(img: "img21", placeName: "Tibetian Arts", rating: "4.0", status: "Open now: 8am - 6pm"),
        PlacesInfo(img: "img22", placeName: "Landmark", rating: "4.1", status: "Open now: 12am - 9:30pm"),
        PlacesInfo(img: "img23", placeName: "Maria Brothers", rating: "4.5", status: "Closed Today")
    ])
]
