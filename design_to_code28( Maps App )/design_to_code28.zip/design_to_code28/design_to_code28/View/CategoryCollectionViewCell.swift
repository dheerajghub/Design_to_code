//
//  CategoryCollectionViewCell.swift
//  design_to_code28
//
//  Created by Dheeraj Kumar Sharma on 28/03/21.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    override var isSelected: Bool {
        didSet{
            cardView.layer.borderColor = isSelected ? Colors.appPink.cgColor : UIColor.white.cgColor
            checkImage.isHidden = isSelected ? false : true
        }
    }
    
    let cardView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 34.5
        v.layer.borderWidth = 2.5
        v.layer.borderColor = UIColor.white.cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 2)
        v.layer.shadowRadius = 7
        v.layer.shadowColor = UIColor.black.withAlphaComponent(0.15).cgColor
        v.layer.shadowOpacity = 1
        return v
    }()
    
    let checkImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "check")
        img.isHidden = true
        return img
    }()
    
    let categoryLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 30)
        l.textAlignment = .center
        return l
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    func setUpViews() {
        addSubview(cardView)
        addSubview(checkImage)
        cardView.addSubview(categoryLabel)
        categoryLabel.pin(to: cardView)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardView.leadingAnchor.constraint(equalTo: leadingAnchor , constant: 3),
            cardView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -3),
            cardView.topAnchor.constraint(equalTo: topAnchor, constant: 3),
            cardView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -3),
            
            checkImage.trailingAnchor.constraint(equalTo: trailingAnchor),
            checkImage.topAnchor.constraint(equalTo: topAnchor),
            checkImage.widthAnchor.constraint(equalToConstant: 25),
            checkImage.heightAnchor.constraint(equalToConstant: 25)
        ])
    }
    
}
