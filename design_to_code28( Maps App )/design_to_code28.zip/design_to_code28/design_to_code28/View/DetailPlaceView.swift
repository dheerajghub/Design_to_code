//
//  DetailPlaceView.swift
//  design_to_code28
//
//  Created by Dheeraj Kumar Sharma on 28/03/21.
//

import UIKit

protocol DetailCardActions {
    func didCloseBtnTapped()
}

class DetailPlaceView: UIView {

    // MARK:- PROPERTIES
    
    var placeData:[PlacesInfo]?
    var choosedCategory: Int? {
        didSet {
            placeData = placesDetail[choosedCategory!].places
            collectionView.reloadData()
        }
    }
    var delegate: DetailCardActions?
    
    let categoryLabel: PaddingLabel = {
        let l = PaddingLabel(padding: UIEdgeInsets(top: 3, left: 10, bottom: 3, right: 10))
        l.text = "Cafe"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Heavy", size: 18)
        l.translatesAutoresizingMaskIntoConstraints = false
        l.backgroundColor = Colors.appPink
        l.layer.cornerRadius = 5
        l.layer.masksToBounds = true
        return l
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.register(DetailCardCollectionViewCell.self, forCellWithReuseIdentifier: "DetailCardCollectionViewCell")
        cv.setCollectionViewLayout(layout, animated: false)
        cv.contentInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .clear
        cv.delaysContentTouches = false
        return cv
    }()
    
    lazy var closeBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setImage(UIImage(named: "close"), for: .normal)
        btn.addTarget(self, action: #selector(closeBtnPressed), for: .touchUpInside)
        return btn
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    func setUpViews() {
        addSubview(categoryLabel)
        addSubview(collectionView)
        addSubview(closeBtn)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            categoryLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            categoryLabel.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            
            collectionView.leadingAnchor.constraint(equalTo: leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor),
            collectionView.topAnchor.constraint(equalTo: categoryLabel.bottomAnchor, constant: 5),
            
            closeBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            closeBtn.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            closeBtn.heightAnchor.constraint(equalToConstant: 25),
            closeBtn.widthAnchor.constraint(equalToConstant: 25)
        ])
    }
    
    @objc func closeBtnPressed(){
        delegate?.didCloseBtnTapped()
    }

}

extension DetailPlaceView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let placeData = placeData {
            return placeData.count
        }
        return Int()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DetailCardCollectionViewCell", for: indexPath) as! DetailCardCollectionViewCell
        if let placeData = placeData {
            cell.cardTitle.text = placeData[indexPath.row].placeName
            cell.ratingTitle.text = placeData[indexPath.row].rating
            cell.statusTitle.text = placeData[indexPath.row].status
            cell.placeImage.image = UIImage(named: placeData[indexPath.row].img)
            cell.categoryTitle.text = placesDetail[choosedCategory!].type
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 250, height: 290)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            let cell = collectionView.cellForItem(at: indexPath) as! DetailCardCollectionViewCell
            cell.cardView.transform = .init(scaleX: 0.95, y: 0.95)
        } ,completion:nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            let cell = collectionView.cellForItem(at: indexPath) as! DetailCardCollectionViewCell
            cell.cardView.transform = .identity
        } ,completion:nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        cell.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        cell.alpha = 0
        UIView.animate(withDuration: 0.85, delay: 0.05 * Double(indexPath.row), usingSpringWithDamping: 1, initialSpringVelocity: 4, options: .curveEaseInOut, animations: {
            cell.transform = .identity
            cell.alpha = 1
        })
    }
    
}
