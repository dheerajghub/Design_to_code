//
//  DetailCardCollectionViewCell.swift
//  design_to_code28
//
//  Created by Dheeraj Kumar Sharma on 28/03/21.
//

import UIKit

class DetailCardCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    override var isSelected: Bool {
        didSet {
            cardView.layer.borderColor = isSelected ? Colors.appPink.withAlphaComponent(0.8).cgColor : UIColor.clear.cgColor
        }
    }
    
    let cardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 5
        v.layer.shadowColor = UIColor.black.withAlphaComponent(0.1).cgColor
        v.layer.shadowOffset = CGSize(width: 1, height: 1)
        v.layer.shadowRadius = 5
        v.layer.shadowOpacity = 1
        v.layer.borderWidth = 3
        v.layer.borderColor = UIColor.clear.cgColor
        return v
    }()
    
    let placeImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img1")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.maskedCorners = [.layerMinXMinYCorner , .layerMaxXMinYCorner]
        img.layer.cornerRadius = 5
        return img
    }()
    
    let cardTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Crusty Morning"
        l.textColor = UIColor.black.withAlphaComponent(0.8)
        l.font = UIFont(name: "Avenir-Black", size: 17)
        return l
    }()
    
    let ratingTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "4.3"
        l.font = UIFont(name: "Avenir-Heavy", size: 17)
        l.textColor = Colors.appPink
        l.textAlignment = .right
        return l
    }()
    
    let categoryTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "cafe"
        l.textColor = .lightGray
        l.font = UIFont(name: "Avenir-Book", size: 16)
        return l
    }()
    
    let statusTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Open now: 9am - 7pm"
        l.textColor = Colors.appGreen
        l.font = UIFont(name: "Avenir-Book", size: 16)
        return l
    }()
    
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    func setUpViews() {
        addSubview(cardView)
        cardView.addSubview(placeImage)
        cardView.addSubview(cardTitle)
        cardView.addSubview(ratingTitle)
        cardView.addSubview(categoryTitle)
        cardView.addSubview(statusTitle)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            cardView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            cardView.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            cardView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10),
            
            placeImage.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
            placeImage.trailingAnchor.constraint(equalTo: cardView.trailingAnchor),
            placeImage.topAnchor.constraint(equalTo: cardView.topAnchor),
            placeImage.heightAnchor.constraint(equalToConstant: 160),
            
            cardTitle.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            cardTitle.topAnchor.constraint(equalTo: placeImage.bottomAnchor, constant: 15),
            cardTitle.trailingAnchor.constraint(equalTo: ratingTitle.leadingAnchor, constant: -10),
            
            ratingTitle.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -15),
            ratingTitle.topAnchor.constraint(equalTo: placeImage.bottomAnchor, constant: 15),
            ratingTitle.widthAnchor.constraint(equalToConstant: 40),
            
            categoryTitle.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            categoryTitle.topAnchor.constraint(equalTo: ratingTitle.bottomAnchor, constant: 3),
            
            statusTitle.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 15),
            statusTitle.topAnchor.constraint(equalTo: categoryTitle.bottomAnchor, constant: 5)
        ])
    }
    
}
