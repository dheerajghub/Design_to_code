//
//  HomeViewController.swift
//  design_to_code28
//
//  Created by Dheeraj Kumar Sharma on 28/03/21.
//

import UIKit
import MapKit

class HomeViewController: UIViewController {
    
    // MARK:- PROPERTIES
    
    let categoryArr = ["☕️" , "🍽" , "👖" , "🍺" , "🎬" , "⛽️"]
    private let locationManager = CLLocationManager()
    private var currentCoordinate: CLLocationCoordinate2D?
    var choosedType = "cafe"
    private var cardBottomConstraints: NSLayoutConstraint?
    
    let mapView: MKMapView = {
        let mv = MKMapView()
        mv.translatesAutoresizingMaskIntoConstraints = false
        mv.mapType = .standard
        return mv
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.register(CategoryCollectionViewCell.self, forCellWithReuseIdentifier: "CategoryCollectionViewCell")
        cv.setCollectionViewLayout(layout, animated: false)
        cv.contentInset = UIEdgeInsets(top: 0, left: 25, bottom: 0, right: 25)
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .clear
        return cv
    }()
    
    let overlayView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    lazy var detailPlaceView: DetailPlaceView = {
        let v = DetailPlaceView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(red: 253/255, green: 253/255, blue: 253/255, alpha: 1)
        v.layer.maskedCorners = [.layerMinXMinYCorner , .layerMaxXMinYCorner]
        v.layer.shadowColor = UIColor.black.withAlphaComponent(0.15).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: -2)
        v.layer.shadowRadius = 7
        v.layer.shadowOpacity = 1
        v.delegate = self
        return v
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViews()
        setUpConstraints()
        configureLocationServices()
    }
    
    // MARK:- FUNCTIONS

    func setUpViews(){
        view.addSubview(mapView)
        view.addSubview(overlayView)
        view.addSubview(collectionView)
        view.addSubview(detailPlaceView)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [self] in
            overlayView.createGradientLayer(colors: [UIColor.black.withAlphaComponent(0.3).cgColor , UIColor.clear.cgColor] , view: overlayView)
        }
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.heightAnchor.constraint(equalToConstant: 110),
            
            overlayView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlayView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            overlayView.topAnchor.constraint(equalTo: view.topAnchor),
            overlayView.heightAnchor.constraint(equalToConstant: 180),
            
            mapView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            mapView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            mapView.topAnchor.constraint(equalTo: view.topAnchor),
            mapView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//            mapView.bottomAnchor.constraint(equalTo: detailPlaceView.topAnchor),
            
            detailPlaceView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            detailPlaceView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            detailPlaceView.heightAnchor.constraint(equalToConstant: 380)
        ])
        
        cardBottomConstraints = detailPlaceView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 380)
        cardBottomConstraints?.isActive = true
        
    }
    
    private func configureLocationServices(){
        locationManager.delegate = self
        mapView.isRotateEnabled = false
        mapView.delegate = self
    }
    
    private func zoomToLatestLocation(with coordinate: CLLocationCoordinate2D){
        let zoomRegion = MKCoordinateRegion(center: coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
        mapView.setRegion(zoomRegion, animated: true)
    }
    
    private func zoomToFit(_ allLocations: [CLLocationCoordinate2D]) {
        var allLocations = allLocations
        let poly:MKPolygon = MKPolygon(coordinates: &allLocations, count: allLocations.count)
        self.mapView.setVisibleMapRect(poly.boundingMapRect, edgePadding: UIEdgeInsets(top: 40.0, left: 40.0, bottom: 180.0, right: 40.0), animated: true)
    }
    
    private func beginLocationUpdates(locationManager: CLLocationManager){
        mapView.showsUserLocation = true
        mapView.showsPointsOfInterest = false
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
    }
    
    private func addAnnotations(_ type: String) {
        var annotationsArray = [CLLocationCoordinate2D]()
        
        //Remove annotations
        let allAnnotations = self.mapView.annotations
        mapView.removeAnnotations(allAnnotations)
        
        for place in places {
            if place.type == type {
                choosedType = type
                for location in place.locations {
                    let annotation = MKPointAnnotation()
                    annotation.title = location.title
                    annotation.subtitle = "\(location.index ?? 0)"
                    let ann = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
                    annotation.coordinate = ann
                    annotationsArray.append(ann)
                    mapView.addAnnotation(annotation)
                }
            }
        }
        zoomToFit(annotationsArray)
    }
    
    private func detailCardAnimation(_ state: String) {
        if state == "close" {
            self.cardBottomConstraints?.constant = 380
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut) {
                self.view.layoutIfNeeded()
            }
        } else {
            self.cardBottomConstraints?.constant = -0
            UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut) {
                self.view.layoutIfNeeded()
            }
        }
    }
    
}

extension HomeViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCollectionViewCell", for: indexPath) as! CategoryCollectionViewCell
        cell.categoryLabel.text = categoryArr[indexPath.row]
        if indexPath.row == 0 {
            collectionView.selectItem(at: indexPath, animated: true, scrollPosition: .centeredHorizontally)
            cell.checkImage.isHidden = false
            cell.cardView.layer.borderColor = Colors.appPink.cgColor
        }
        detailPlaceView.choosedCategory = indexPath.row
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 75, height: 75)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        addAnnotations(places[indexPath.row].type)
        detailPlaceView.categoryLabel.text = places[indexPath.row].type.capitalized
        detailPlaceView.choosedCategory = indexPath.row
    }
    
}

extension HomeViewController: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("Did get updated location!")
        guard let latestLocation = locations.first else { return }
        if currentCoordinate == nil {
            zoomToLatestLocation(with: latestLocation.coordinate)
            addAnnotations("cafe")
        }
        currentCoordinate = latestLocation.coordinate
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
            case .authorizedAlways , .authorizedWhenInUse:
                beginLocationUpdates(locationManager: manager)
                break
            case .notDetermined , .denied , .restricted:
                locationManager.requestAlwaysAuthorization()
                break
            default:
                break
        }
    }
    
}

extension HomeViewController: MKMapViewDelegate , DetailCardActions {

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "AnnotationView")

        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "AnnotationView")
        }

        if annotation === mapView.userLocation {
            annotationView?.image = UIImage(named: "meAnnotation")
        } else {
            annotationView?.image = UIImage(named: "placeAnnotation")
        }
        annotationView?.canShowCallout = true
        return annotationView
    }

    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let title = view.annotation?.title
        if title != "My Location" {
            let index = Int((view.annotation?.subtitle ?? "0")!)
            let indexPath = IndexPath(item: index!, section: 0)
            detailPlaceView.collectionView.scrollToItem(at: indexPath, at: .left, animated: true)
            detailPlaceView.collectionView.selectItem(at: indexPath, animated: true, scrollPosition: .left)
            detailCardAnimation("open")
        }
        
    }
    
    func mapView(_ mapView: MKMapView, didAdd views: [MKAnnotationView]) {
        var i = -1
        for view in views {
            i += 1
            let delay = 0.03 * Double(i)
            UIView.animate(withDuration: 0.1, delay: delay, options: .curveEaseInOut) {
                view.isHidden = true
                view.transform = CGAffineTransform(scaleX: 0.4, y: 0.4)
            } completion: { (Bool) in
                view.isHidden = false
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 5, options: .curveEaseInOut) {
                    view.transform = CGAffineTransform(scaleX: 1, y: 1)
                }
            }
        }
    }
    
    func didCloseBtnTapped() {
        detailCardAnimation("close")
    }

}
