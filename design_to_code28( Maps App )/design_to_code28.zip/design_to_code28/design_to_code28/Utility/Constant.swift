//
//  Constant.swift
//  design_to_code28
//
//  Created by Dheeraj Kumar Sharma on 28/03/21.
//

import UIKit

struct Colors {
    static let appPink = UIColor(red: 236/255, green: 61/255, blue: 107/255, alpha: 1)
    static let appGreen = UIColor(red: 0/255, green: 159/255, blue: 6/255, alpha: 1)
}
