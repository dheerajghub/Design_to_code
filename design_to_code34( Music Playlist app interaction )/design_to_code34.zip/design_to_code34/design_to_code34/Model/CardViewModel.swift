//
//  CardViewModel.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 31/05/21.
//

import Foundation

struct CardViewModel {
    let categoryImage: String
    let categoryName: String
    let categoryDate: String
    let cardTitle: String
    let likeCount: String
    let duration: String
    let cardDescription:String
    let cardImage: String
    let cardList:[CardListModel]!
}

struct CardListModel {
    let listImage: String
    let listTitle: String
    let listSubtitle: String
}


let CardData = [
    
    CardViewModel(
        categoryImage: "cat1",
        categoryName: "PIANO DAILY",
        categoryDate: "June 2018",
        cardTitle: "Cinematic Piano",
        likeCount: "9,543",
        duration: "5h 35m",
        cardDescription: "Beautiful, dreamy and dramatic instrumental neo classical piano scores from movies and tv series.",
        cardImage: "card1",
        cardList: [
            CardListModel(
                listImage: "list1",
                listTitle: "Rosemary's Baby",
                listSubtitle: "Krzysztof Komeda"
            ),
            CardListModel(
                listImage: "list2",
                listTitle: "Janus",
                listSubtitle: ""
            ),
            CardListModel(
                listImage: "list3",
                listTitle: "By the Sea",
                listSubtitle: "Eleni Karaindrou"
            ),
            CardListModel(
                listImage: "list4",
                listTitle: "Rsalee Theme",
                listSubtitle: "Max Richter - Hostiles"
            ),
            CardListModel(
                listImage: "list1",
                listTitle: "Rosemary's Baby",
                listSubtitle: "Krzysztof Komeda"
            ),
            CardListModel(
                listImage: "list2",
                listTitle: "Janus",
                listSubtitle: ""
            ),
            CardListModel(
                listImage: "list3",
                listTitle: "By the Sea",
                listSubtitle: "Eleni Karaindrou"
            ),
            CardListModel(
                listImage: "list4",
                listTitle: "Rsalee Theme",
                listSubtitle: "Max Richter - Hostiles"
            ),
            CardListModel(
                listImage: "list1",
                listTitle: "Rosemary's Baby",
                listSubtitle: "Krzysztof Komeda"
            ),
            CardListModel(
                listImage: "list2",
                listTitle: "Janus",
                listSubtitle: ""
            ),
            CardListModel(
                listImage: "list3",
                listTitle: "By the Sea",
                listSubtitle: "Eleni Karaindrou"
            ),
            CardListModel(
                listImage: "list4",
                listTitle: "Rsalee Theme",
                listSubtitle: "Max Richter - Hostiles"
            )
        ]
    ),
    
    CardViewModel(
        categoryImage: "cat2",
        categoryName: "PERFECT OLDIES",
        categoryDate: "July 2018",
        cardTitle: "80s Smash Hits",
        likeCount: "9,543",
        duration: "5h 35m",
        cardDescription: "The music of 1980's remains a tribute to glorious excess and left us with some huge tunes. Celebrate them here.",
        cardImage: "card2",
        cardList: [
            CardListModel(
                listImage: "list1",
                listTitle: "Rosemary's Baby",
                listSubtitle: "Krzysztof Komeda"
            ),
            CardListModel(
                listImage: "list2",
                listTitle: "Janus",
                listSubtitle: ""
            ),
            CardListModel(
                listImage: "list3",
                listTitle: "By the Sea",
                listSubtitle: "Eleni Karaindrou"
            ),
            CardListModel(
                listImage: "list4",
                listTitle: "Rsalee Theme",
                listSubtitle: "Max Richter - Hostiles"
            ),
            CardListModel(
                listImage: "list1",
                listTitle: "Rosemary's Baby",
                listSubtitle: "Krzysztof Komeda"
            ),
            CardListModel(
                listImage: "list2",
                listTitle: "Janus",
                listSubtitle: ""
            ),
            CardListModel(
                listImage: "list3",
                listTitle: "By the Sea",
                listSubtitle: "Eleni Karaindrou"
            ),
            CardListModel(
                listImage: "list4",
                listTitle: "Rsalee Theme",
                listSubtitle: "Max Richter - Hostiles"
            ),
            CardListModel(
                listImage: "list1",
                listTitle: "Rosemary's Baby",
                listSubtitle: "Krzysztof Komeda"
            ),
            CardListModel(
                listImage: "list2",
                listTitle: "Janus",
                listSubtitle: ""
            ),
            CardListModel(
                listImage: "list3",
                listTitle: "By the Sea",
                listSubtitle: "Eleni Karaindrou"
            ),
            CardListModel(
                listImage: "list4",
                listTitle: "Rsalee Theme",
                listSubtitle: "Max Richter - Hostiles"
            )
        ]
    )
]
