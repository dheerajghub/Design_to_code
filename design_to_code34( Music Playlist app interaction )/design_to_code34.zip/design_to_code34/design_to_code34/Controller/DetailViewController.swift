//
//  DetailViewController.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 29/05/21.
//

import UIKit

enum ViewState {
    case hidden
    case shown
}

class DetailViewController: UIViewController, UIScrollViewDelegate {

    // MARK:- PROPERTIES
    
    var navBarTopAnchor: NSLayoutConstraint?
    var cardModel: CardViewModel!
    
    lazy var scrollView: UIScrollView = {
        let view = UIScrollView(frame: .zero)
        view.autoresizingMask = .flexibleHeight
        view.showsHorizontalScrollIndicator = false
        view.showsVerticalScrollIndicator = false
        view.translatesAutoresizingMaskIntoConstraints = false
        view.bounces = false
        view.clipsToBounds = true
        view.delegate = self
        return view
    }()
    
    lazy var cardView: CustomCardView = {
        let v = CustomCardView(backgroundColor: .red, viewMode: .full, cardData: cardModel)
        v.translatesAutoresizingMaskIntoConstraints = false
        v.updateLayout(for: .full)
        v.cardContainerView.layer.cornerRadius = 0.0
        v.data = cardModel
        return v
    }()
    
    lazy var navBar: CustomNavBar = {
        let v = CustomNavBar()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .black
        v.data = cardModel
        return v
    }()
    
    lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.delegate = self
        tv.dataSource = self
        tv.tableFooterView = UIView()
        tv.separatorStyle = .none
        tv.showsVerticalScrollIndicator = false
        tv.register(DetailTableViewCell.self, forCellReuseIdentifier: "DetailTableViewCell")
        tv.isScrollEnabled = false
        tv.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        return tv
    }()
    
    lazy var closeBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        btn.layer.cornerRadius = 15
        btn.setBackgroundImage(UIImage(named: "back")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        btn.addTarget(self, action: #selector(closePressed), for: .touchUpInside)
        return btn
    }()
    
    // MARK:- MAIN
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViews()
        setUpConstraints()
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    // MARK:- FUNCTION
    
    fileprivate func setUpViews(){
        view.addSubview(scrollView)
        scrollView.addSubview(cardView)
        scrollView.addSubview(tableView)
        view.addSubview(navBar)
        view.addSubview(closeBtn)
    }
    
    fileprivate func setUpConstraints(){
        
        let window = UIApplication.shared.windows[0]
        let topPadding = window.safeAreaInsets.top
        print(topPadding)
        
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            cardView.topAnchor.constraint(equalTo: scrollView.topAnchor , constant: -topPadding),
            cardView.centerXAnchor.constraint(equalTo: scrollView.centerXAnchor),
            cardView.heightAnchor.constraint(equalToConstant: 500),
            cardView.widthAnchor.constraint(equalToConstant: view.frame.size.width),
            
            tableView.topAnchor.constraint(equalTo: cardView.bottomAnchor),
            tableView.centerXAnchor.constraint(equalTo: scrollView.centerXAnchor),
            tableView.widthAnchor.constraint(equalToConstant: view.frame.size.width),
            tableView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            tableView.heightAnchor.constraint(equalToConstant: CGFloat((80 * cardModel.cardList.count) + 20)),
            
            closeBtn.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            closeBtn.widthAnchor.constraint(equalToConstant: 30),
            closeBtn.heightAnchor.constraint(equalToConstant: 30),
            closeBtn.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            
            navBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navBar.heightAnchor.constraint(equalToConstant: (topPadding + 80))
        ])
        
        navBarTopAnchor = navBar.topAnchor.constraint(equalTo: view.topAnchor , constant: -(topPadding + 60))
        navBarTopAnchor?.isActive = true
    }
    
    func viewState(_ state: ViewState) {
        if state == .hidden {
            cardView.isHidden = true
            closeBtn.isHidden = true
            tableView.isHidden = true
            navBar.isHidden = true
        } else {
            cardView.isHidden = false
            closeBtn.isHidden = false
            tableView.isHidden = false
            navBar.isHidden = false
        }
    }
    
    @objc func closePressed() {
        dismiss(animated: true, completion: nil)
    }

}

extension DetailViewController: UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cardModel.cardList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailTableViewCell", for: indexPath) as! DetailTableViewCell
        cell.selectionStyle = .none
        cell.data = cardModel.cardList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        
        let window = UIApplication.shared.windows[0]
        let topPadding = window.safeAreaInsets.top
        
        print(scrollView.contentOffset.y)
        
        if scrollView.contentOffset.y >= 300 {
            navBarTopAnchor?.constant = 0
        } else {
            navBarTopAnchor?.constant = -(topPadding + 80)
        }
        
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
            self.view.layoutIfNeeded()
        }
        
    }
    
}
