//
//  HomeViewController.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 29/05/21.
//

import UIKit

class HomeViewController: UIViewController {

    // MARK:- PROPERTIES
    
    let transitionManager = CardTransitionManager()
    
    lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.delegate = self
        tv.dataSource = self
        tv.register(CardViewTableViewCell.self, forCellReuseIdentifier: "CardViewTableViewCell")
        tv.separatorStyle = .none
        tv.tableFooterView = UIView()
        tv.showsVerticalScrollIndicator = false
        return tv
    }()
    
    // MARK:- MAIN
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViews()
        setUpConstraints()
    }
    
    // MARK:- FUNCTIONS
    
    func setUpViews(){
        view.backgroundColor = .white
        view.addSubview(tableView)
    }
    
    func setUpConstraints(){
        tableView.pin(to: view)
    }

}

extension HomeViewController: UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return CardData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CardViewTableViewCell", for: indexPath) as! CardViewTableViewCell
        cell.data = CardData[indexPath.row]
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let VC = DetailViewController()
        VC.modalPresentationStyle = .overCurrentContext
        VC.transitioningDelegate = transitionManager
        VC.cardModel = CardData[indexPath.row]
        present(VC, animated: true, completion: nil)
        CFRunLoopWakeUp(CFRunLoopGetCurrent())
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
    }
    
    func selectedCellCardView() -> CustomCardView? {
        guard let indexPath = tableView.indexPathForSelectedRow else { return nil }
        guard let cell = tableView.cellForRow(at: indexPath) as? CardViewTableViewCell else { return nil }
        cell.tag = indexPath.row
        let cardView = cell.cardView
        return cardView
    }
    
}
