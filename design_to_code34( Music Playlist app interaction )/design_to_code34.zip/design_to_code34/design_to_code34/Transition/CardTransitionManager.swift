//
//  CardTransitionManager.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 29/05/21.
//

import UIKit

enum CardTransitionType {
    case presentation
    case dismissal
    
    var blurAlpha: CGFloat { return self == .presentation ? 1 : 0 }
    var dimAlpha: CGFloat { return self == .presentation ? 0.5 : 0 }
    var cornerRadius: CGFloat { return self == .presentation ? 30.0 : 0.0}
    var cardMode: ViewMode { return self == .presentation ? .card : .full}
    var next: CardTransitionType { return self == .presentation ? .dismissal : .presentation}
     
}

class CardTransitionManager: NSObject {
    
    let transitionDuration = 0.8
    var transition: CardTransitionType = .presentation
    let shrinkDuration: Double = 0.2
    
    lazy var blurEffectView: UIVisualEffectView = {
        let blurrEffect = UIBlurEffect(style: .light)
        let visualEffectView = UIVisualEffectView(effect: blurrEffect)
        return visualEffectView
    }()
    
    lazy var dimmingView: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        return v
    }()
    
    lazy var whiteView: UIView = {
        let v = UIView()
        v.backgroundColor = .white
        return v
    }()
    
    // MARK:- Helper Method
    
    private func addBackgroundViews(to containerView: UIView) {
        blurEffectView.frame = containerView.frame
        blurEffectView.alpha = transition.next.blurAlpha
        containerView.addSubview(blurEffectView)
        
        
        dimmingView.frame = containerView.frame
        dimmingView.alpha = transition.next.dimAlpha
        containerView.addSubview(dimmingView)
    }
    
    private func createCardViewCopy(cardView: CustomCardView) -> CustomCardView {
        // Get the data from card view model for transition change
        let cardModel = cardView.dataModel
        let cardViewCopy = CustomCardView(backgroundColor: .red , viewMode: transition.cardMode, cardData: cardModel!)
        return cardViewCopy
    }
    
}

extension CardTransitionManager: UIViewControllerAnimatedTransitioning {
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return transitionDuration
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        
        let containerView = transitionContext.containerView
        containerView.subviews.forEach({ $0.removeFromSuperview() })
        
        addBackgroundViews(to: containerView)
        
        let fromView = transitionContext.viewController(forKey: .from)
        let toView = transitionContext.viewController(forKey: .to)
        
        guard let cardView = (transition == .presentation) ? (fromView as! HomeViewController).selectedCellCardView() : (toView as! HomeViewController).selectedCellCardView() else { return }
        
        let cardViewCopy = createCardViewCopy(cardView: cardView)
        containerView.addSubview(cardViewCopy)
        cardView.isHidden = true
        
        let absoluteCardViewFrame = cardView.convert(cardView.frame, to: nil)
        cardViewCopy.frame = absoluteCardViewFrame
        cardViewCopy.layoutIfNeeded()
        
        whiteView.frame = transition == .presentation ? cardViewCopy.cardContainerView.frame : cardViewCopy.frame
        whiteView.layer.cornerRadius = transition.cornerRadius
        // insert shadowview as a subview if any
        cardViewCopy.insertSubview(whiteView, belowSubview: cardViewCopy.cardContainerView)
        
        if transition == .presentation {
            let detailView = toView as! DetailViewController
            containerView.addSubview(detailView.view)
            detailView.viewState(.hidden)

            moveAndConvertToCardView(cardView: cardViewCopy, containerView: containerView, yOriginToMoveTo: 0) {
                detailView.viewState(.shown)
                cardViewCopy.removeFromSuperview()
                cardView.isHidden = false
                transitionContext.completeTransition(true)
            }

        } else {
            // Dismissal
            let detailView = fromView as! DetailViewController
            detailView.viewState(.hidden)
            
            cardViewCopy.frame = CGRect(x: 0, y: 0, width: detailView.cardView.frame.width, height: detailView.cardView.frame.height)
            
            moveAndConvertToCardView(cardView: cardViewCopy, containerView: containerView, yOriginToMoveTo: absoluteCardViewFrame.origin.y) {
                cardView.isHidden = false
                transitionContext.completeTransition(true)
            }
        }
    }
    
    func makeShrinkAnimator(for cardView: CustomCardView) -> UIViewPropertyAnimator {
        return UIViewPropertyAnimator(duration: shrinkDuration, curve: .easeOut) {
            cardView.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            self.dimmingView.alpha = 0.05
        }
    }
    
    func makeExpandContractAnimator(for cardView: CustomCardView , in containerView: UIView, yOrigin: CGFloat) -> UIViewPropertyAnimator {
        let springTiming = UISpringTimingParameters(dampingRatio: 0.75, initialVelocity: CGVector(dx: 0, dy: 4))
        let animator = UIViewPropertyAnimator(duration: transitionDuration - shrinkDuration, timingParameters: springTiming)
        
        animator.addAnimations {
            cardView.transform = .identity
            cardView.cardContainerView.layer.cornerRadius = self.transition.next.cornerRadius
            cardView.frame.origin.y = yOrigin
            
            self.blurEffectView.alpha = self.transition.blurAlpha
            self.dimmingView.alpha = self.transition.dimAlpha
            
            self.whiteView.layer.cornerRadius = self.transition.next.cornerRadius
            self.whiteView.frame = containerView.frame
            
            containerView.layoutIfNeeded()
            
            self.whiteView.frame = self.transition == .presentation ? containerView.frame : cardView.cardContainerView.frame
        }
        
        return animator
    }
    
    func moveAndConvertToCardView(cardView: CustomCardView, containerView: UIView , yOriginToMoveTo: CGFloat , completion: @escaping () -> ()) {
        
        let shrinkAnimator = makeShrinkAnimator(for: cardView)
        let expandContractAnimator = makeExpandContractAnimator(for: cardView, in: containerView, yOrigin: yOriginToMoveTo)
        
        expandContractAnimator.addCompletion { _ in
            completion()
        }
        
        if transition == .presentation {
            shrinkAnimator.addCompletion { _ in
                cardView.layoutIfNeeded()
                cardView.updateLayout(for: self.transition.next.cardMode)
                expandContractAnimator.startAnimation()
            }
            shrinkAnimator.startAnimation()
        } else {
            cardView.layoutIfNeeded()
            cardView.updateLayout(for: self.transition.next.cardMode)
            expandContractAnimator.startAnimation()
        }
        
    }
    
}

extension CardTransitionManager: UIViewControllerTransitioningDelegate {
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition = .presentation
        return self
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition = .dismissal
        return self
    }
    
}
