//
//  CustomNavBar.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 31/05/21.
//

import UIKit

class CustomNavBar: UIView {

    // MARK:- PROPERTIES
    
    var data: CardViewModel?{
        didSet{
            manageData()
        }
    }
    
    let categoryTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        l.textColor = .white
        l.textAlignment = .center
        return l
    }()
    
    let cardTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        l.textColor = .white
        l.textAlignment = .center
        return l
    }()
    
    let featureLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textAlignment = .center
        return l
    }()
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let overlayView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        return v
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    
    fileprivate func setUpViews(){
        addSubview(cardImage)
        addSubview(overlayView)
        addSubview(categoryTitle)
        addSubview(cardTitle)
        addSubview(featureLabel)
        
        cardImage.pin(to: self)
        overlayView.pin(to: self)
    }
    
    fileprivate func setUpConstraints(){
        NSLayoutConstraint.activate([
            categoryTitle.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor, constant: 5),
            categoryTitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            categoryTitle.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            
            cardTitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            cardTitle.trailingAnchor.constraint(equalTo: trailingAnchor,constant: -20),
            cardTitle.topAnchor.constraint(equalTo: categoryTitle.bottomAnchor, constant: 5),
            
            featureLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            featureLabel.trailingAnchor.constraint(equalTo: trailingAnchor,constant: -20),
            featureLabel.topAnchor.constraint(equalTo: cardTitle.bottomAnchor, constant: 5)
        ])
    }
    
    func manageData(){
        guard let data = data else { return }
        cardTitle.text = data.cardTitle
        categoryTitle.text = data.categoryName
        featureLabel.attributedText = featureText(data.likeCount, data.duration)
        cardImage.image = UIImage(named: data.cardImage)
    }
    
}
