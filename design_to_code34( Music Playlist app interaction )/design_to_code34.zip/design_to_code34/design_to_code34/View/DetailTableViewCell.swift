//
//  DetailTableViewCell.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 30/05/21.
//

import UIKit

class DetailTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    
    var data: CardListModel? {
        didSet {
            manageData()
        }
    }
    
    let thumbImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "demo")
        img.layer.cornerRadius = 5
        img.clipsToBounds = true
        return img
    }()
    
    let title: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Rosemary's baby"
        l.font = UIFont.systemFont(ofSize: 17, weight: .bold)
        l.textColor = .black
        return l
    }()
    
    let subtitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Krzysztof Komeda"
        l.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        l.textColor = .lightGray
        return l
    }()
    
    let likeBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "love")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .lightGray
        return btn
    }()
    
    let moreBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "more")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .lightGray
        return btn
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    
    fileprivate func setUpViews(){
        addSubview(thumbImage)
        addSubview(title)
        addSubview(subtitle)
        addSubview(likeBtn)
        addSubview(moreBtn)
    }
    
    fileprivate func setUpConstraints(){
        NSLayoutConstraint.activate([
            thumbImage.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            thumbImage.centerYAnchor.constraint(equalTo: centerYAnchor),
            thumbImage.heightAnchor.constraint(equalToConstant: 60),
            thumbImage.widthAnchor.constraint(equalToConstant: 60),
            
            title.leadingAnchor.constraint(equalTo: thumbImage.trailingAnchor, constant: 15),
            title.topAnchor.constraint(equalTo: topAnchor, constant: 17),
            
            subtitle.leadingAnchor.constraint(equalTo: thumbImage.trailingAnchor, constant: 15),
            subtitle.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 4),
            
            moreBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -15),
            moreBtn.widthAnchor.constraint(equalToConstant: 35),
            moreBtn.heightAnchor.constraint(equalToConstant: 35),
            moreBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            likeBtn.trailingAnchor.constraint(equalTo: moreBtn.leadingAnchor, constant: -15),
            likeBtn.widthAnchor.constraint(equalToConstant: 35),
            likeBtn.heightAnchor.constraint(equalToConstant: 35),
            likeBtn.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func manageData(){
        guard let data = data else { return }
        title.text = data.listTitle
        subtitle.text = data.listSubtitle
        thumbImage.image = UIImage(named: data.listImage)
    }

}
