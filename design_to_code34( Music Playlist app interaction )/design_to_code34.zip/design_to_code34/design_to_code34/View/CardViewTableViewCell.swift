//
//  CardViewTableViewCell.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 29/05/21.
//

import UIKit

class CardViewTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    
    var dataModel: CardViewModel?
    var data: CardViewModel? {
        didSet {
            self.dataModel = data
            cardView.data = data!
        }
    }
    
    lazy var cardView: CustomCardView = {
        let v = CustomCardView(backgroundColor: .red, viewMode: .card, cardData: CardData[0])
        v.translatesAutoresizingMaskIntoConstraints = false
        v.clipsToBounds =  true
        v.data = dataModel
        return v
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    
    fileprivate func setUpViews(){
        addSubview(cardView)
    }
    
    fileprivate func setUpConstraints(){
        cardView.pin(to: self)
    }

}
