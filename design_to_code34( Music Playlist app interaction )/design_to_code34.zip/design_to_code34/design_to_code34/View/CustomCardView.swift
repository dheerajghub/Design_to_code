//
//  CustomCardView.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 29/05/21.
//

import UIKit

enum ViewMode {
    case full
    case card
}

class CustomCardView: UIView {

    // MARK:- PROPERTIES
    
    var bgColor: UIColor?
    var vmode: ViewMode?
    var containerLeadingConstraints: NSLayoutConstraint?
    var containerTopConstraints: NSLayoutConstraint?
    var containerTrailingConstraints: NSLayoutConstraint?
    var containerBottomConstraints: NSLayoutConstraint?
    var dataModel: CardViewModel?
    var data: CardViewModel? {
        didSet {
            self.dataModel = data
            manageData()
        }
    }
    
    lazy var cardContainerView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = bgColor
        v.layer.cornerRadius = 30
        v.clipsToBounds = true
        v.layer.shadowColor = UIColor.red.cgColor
        v.layer.shadowOpacity = 1
        v.layer.shadowOffset = CGSize(width: 0, height: -2)
        v.layer.shadowRadius = 20
        return v
    }()
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.backgroundColor = .white
        return img
    }()
    
    let overlayView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        return v
    }()
    
    let profileView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .clear
        v.layer.borderWidth = 1
        v.layer.borderColor = UIColor.white.cgColor
        v.layer.cornerRadius = 25
        return v
    }()
    
    let cardProfilePicture: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.backgroundColor = .black
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 20
        img.clipsToBounds = true
        return img
    }()
    
    let addButton: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = .white
        btn.setBackgroundImage(UIImage(named: "plus"), for: .normal)
        btn.layer.cornerRadius = 10
        return btn
    }()
    
    let cardCategoryTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 12, weight: .bold)
        l.textColor = .white
        return l
    }()
    
    let cardCategorySubTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 11, weight: .regular)
        l.textColor = .white
        return l
    }()
    
    let cardTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .white
        l.font = UIFont.systemFont(ofSize: 31 , weight: .bold)
        l.textAlignment = .center
        return l
    }()
    
    let featureLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let cardSubtitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        l.textAlignment = .center
        l.textColor = .white
        l.numberOfLines = 0
        return l
    }()
    
    let actionView: CardActionView = {
        let v = CardActionView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    
    // MARK:- MAIN
    
    init(backgroundColor: UIColor , viewMode: ViewMode , cardData: CardViewModel) {
        let frame = CGRect.zero
        self.bgColor = backgroundColor
        self.vmode = viewMode
        self.data = cardData
        super.init(frame: frame)
        
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    
    fileprivate func setUpViews(){
        addSubview(cardContainerView)
        cardContainerView.addSubview(cardImage)
        cardContainerView.addSubview(overlayView)
        
        cardContainerView.addSubview(profileView)
        profileView.addSubview(cardProfilePicture)
        profileView.addSubview(addButton)
        
        cardContainerView.addSubview(cardCategoryTitle)
        cardContainerView.addSubview(cardCategorySubTitle)
        cardContainerView.addSubview(cardTitle)
        cardContainerView.addSubview(featureLabel)
        cardContainerView.addSubview(cardSubtitle)
        cardContainerView.addSubview(actionView)
        
        updateLayout(for: vmode!)
    }
    
    fileprivate func setUpConstraints(){
        containerLeadingConstraints = cardContainerView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30)
        containerLeadingConstraints?.isActive = true
        
        containerTopConstraints = cardContainerView.topAnchor.constraint(equalTo: topAnchor, constant: 15)
        containerTopConstraints?.isActive = true
        
        containerBottomConstraints = cardContainerView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -15)
        containerBottomConstraints?.isActive = true
        
        containerTrailingConstraints = cardContainerView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30)
        containerTrailingConstraints?.isActive = true
        
        overlayView.pin(to: cardContainerView)
        cardImage.pin(to: cardContainerView)
        
        NSLayoutConstraint.activate([
            
            profileView.topAnchor.constraint(equalTo: cardContainerView.topAnchor, constant: 60),
            profileView.centerXAnchor.constraint(equalTo: cardContainerView.centerXAnchor),
            profileView.widthAnchor.constraint(equalToConstant: 50),
            profileView.heightAnchor.constraint(equalToConstant: 50),
            
            addButton.trailingAnchor.constraint(equalTo: profileView.trailingAnchor, constant: 4),
            addButton.bottomAnchor.constraint(equalTo: profileView.bottomAnchor, constant: 4),
            addButton.widthAnchor.constraint(equalToConstant: 20),
            addButton.heightAnchor.constraint(equalToConstant: 20),
            
            cardProfilePicture.centerXAnchor.constraint(equalTo: profileView.centerXAnchor),
            cardProfilePicture.centerYAnchor.constraint(equalTo: profileView.centerYAnchor),
            cardProfilePicture.widthAnchor.constraint(equalToConstant: 40),
            cardProfilePicture.heightAnchor.constraint(equalToConstant: 40),
            
            cardCategoryTitle.topAnchor.constraint(equalTo: profileView.bottomAnchor, constant: 10),
            cardCategoryTitle.centerXAnchor.constraint(equalTo: cardContainerView.centerXAnchor),
            
            cardCategorySubTitle.centerXAnchor.constraint(equalTo: cardContainerView.centerXAnchor),
            cardCategorySubTitle.topAnchor.constraint(equalTo: cardCategoryTitle.bottomAnchor, constant: 2),
            
            cardTitle.topAnchor.constraint(equalTo: cardCategorySubTitle.bottomAnchor, constant: 20),
            cardTitle.leadingAnchor.constraint(equalTo: cardContainerView.leadingAnchor, constant: 20),
            cardTitle.trailingAnchor.constraint(equalTo: cardContainerView.trailingAnchor, constant: -20),
            
            featureLabel.topAnchor.constraint(equalTo: cardTitle.bottomAnchor, constant: 10),
            featureLabel.centerXAnchor.constraint(equalTo: cardContainerView.centerXAnchor),
            
            cardSubtitle.topAnchor.constraint(equalTo: featureLabel.bottomAnchor, constant: 30),
            cardSubtitle.leadingAnchor.constraint(equalTo: cardContainerView.leadingAnchor, constant: 40),
            cardSubtitle.trailingAnchor.constraint(equalTo: cardContainerView.trailingAnchor, constant: -40),
            
            actionView.bottomAnchor.constraint(equalTo: cardContainerView.bottomAnchor, constant: -20),
            actionView.leadingAnchor.constraint(equalTo: cardContainerView.leadingAnchor, constant: 20),
            actionView.trailingAnchor.constraint(equalTo: cardContainerView.trailingAnchor, constant: -20),
            actionView.heightAnchor.constraint(equalToConstant: 80)
        ])
    }
    
    func updateLayout(for mode: ViewMode) {
        if mode == .full {
            containerLeadingConstraints?.constant = 0
            containerTopConstraints?.constant = 0
            containerBottomConstraints?.constant = 0
            containerTrailingConstraints?.constant = 0
            cardSubtitle.isHidden = false
            
            actionView.downloadView.isHidden = false
            actionView.moreView.isHidden = false
            actionView.stackView.addArrangedSubview(actionView.downloadView)
            actionView.stackView.addArrangedSubview(actionView.notInterestedView)
            actionView.stackView.addArrangedSubview(actionView.playView)
            actionView.stackView.addArrangedSubview(actionView.likeView)
            actionView.stackView.addArrangedSubview(actionView.moreView)
            
        } else {
            containerLeadingConstraints?.constant = 30
            containerTopConstraints?.constant = 15
            containerBottomConstraints?.constant = -15
            containerTrailingConstraints?.constant = -30
            cardSubtitle.isHidden = true
            
            actionView.downloadView.isHidden = true
            actionView.moreView.isHidden = true
            actionView.stackView.removeArrangedSubview(actionView.downloadView)
            actionView.stackView.removeArrangedSubview(actionView.moreView)
        }
    }
    
    func manageData(){
        guard let data = data else { return }
        cardCategoryTitle.text = data.categoryName
        cardCategorySubTitle.text = data.categoryDate
        cardTitle.text = data.cardTitle
        featureLabel.attributedText = featureText(data.likeCount, data.duration)
        cardSubtitle.text = data.cardDescription
        cardImage.image = UIImage(named: data.cardImage)
        cardProfilePicture.image = UIImage(named: data.categoryImage)
    }

}
