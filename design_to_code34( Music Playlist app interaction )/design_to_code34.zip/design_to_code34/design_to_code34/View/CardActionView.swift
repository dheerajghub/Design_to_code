//
//  CardActionView.swift
//  design_to_code34
//
//  Created by Dheeraj Kumar Sharma on 30/05/21.
//

import UIKit

class CardActionView: UIView {

    // MARK:- PROPERTIES
    
    let stackView: UIStackView = {
        let sv = UIStackView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.axis = .horizontal
        sv.distribution = .fillEqually
        return sv
    }()
    
    let downloadView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let notInterestedView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let playView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let likeView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let moreView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let downloadBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        btn.layer.cornerRadius = 22.5
        btn.setBackgroundImage(UIImage(named: "download")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        return btn
    }()
    
    let notInterestedBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        btn.layer.cornerRadius = 22.5
        btn.setBackgroundImage(UIImage(named: "restrict")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        return btn
    }()
    
    let playBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor.white
        btn.layer.cornerRadius = 35
        btn.setBackgroundImage(UIImage(named: "playBtn")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .black
        return btn
    }()
    
    let likeBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        btn.layer.cornerRadius = 22.5
        btn.setBackgroundImage(UIImage(named: "like")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        return btn
    }()
    
    let moreBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        btn.layer.cornerRadius = 22.5
        btn.setBackgroundImage(UIImage(named: "more")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        return btn
    }()
    
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    
    fileprivate func setUpViews(){
        addSubview(stackView)
        stackView.addArrangedSubview(notInterestedView)
        stackView.addArrangedSubview(playView)
        stackView.addArrangedSubview(likeView)
        
        downloadView.addSubview(downloadBtn)
        notInterestedView.addSubview(notInterestedBtn)
        playView.addSubview(playBtn)
        likeView.addSubview(likeBtn)
        moreView.addSubview(moreBtn)
    }
    
    fileprivate func setUpConstraints(){
        stackView.pin(to: self)
        NSLayoutConstraint.activate([
            
            downloadBtn.centerXAnchor.constraint(equalTo: downloadView.centerXAnchor),
            downloadBtn.centerYAnchor.constraint(equalTo: downloadView.centerYAnchor),
            downloadBtn.widthAnchor.constraint(equalToConstant: 45),
            downloadBtn.heightAnchor.constraint(equalToConstant: 45),
            
            notInterestedBtn.centerXAnchor.constraint(equalTo: notInterestedView.centerXAnchor),
            notInterestedBtn.centerYAnchor.constraint(equalTo: notInterestedView.centerYAnchor),
            notInterestedBtn.widthAnchor.constraint(equalToConstant: 45),
            notInterestedBtn.heightAnchor.constraint(equalToConstant: 45),
            
            playBtn.centerXAnchor.constraint(equalTo: playView.centerXAnchor),
            playBtn.centerYAnchor.constraint(equalTo: playView.centerYAnchor),
            playBtn.widthAnchor.constraint(equalToConstant: 70),
            playBtn.heightAnchor.constraint(equalToConstant: 70),
            
            likeBtn.centerXAnchor.constraint(equalTo: likeView.centerXAnchor),
            likeBtn.centerYAnchor.constraint(equalTo: likeView.centerYAnchor),
            likeBtn.widthAnchor.constraint(equalToConstant: 45),
            likeBtn.heightAnchor.constraint(equalToConstant: 45),
            
            moreBtn.centerXAnchor.constraint(equalTo: moreView.centerXAnchor),
            moreBtn.centerYAnchor.constraint(equalTo: moreView.centerYAnchor),
            moreBtn.widthAnchor.constraint(equalToConstant: 45),
            moreBtn.heightAnchor.constraint(equalToConstant: 45)
            
        ])
    }
}
