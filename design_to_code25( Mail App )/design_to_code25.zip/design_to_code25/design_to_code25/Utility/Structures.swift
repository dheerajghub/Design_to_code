//
//  Structures.swift
//  design_to_code25
//
//  Created by Dheeraj Kumar Sharma on 24/01/21.
//

import Foundation

struct MailData {
    let userImage:String!
    let userName: String!
    let subject: String!
    let time: String!
    let body: String!
    var isStarred: Bool!
    let isAttachement: Bool!
}
