//
//  ViewController.swift
//  design_to_code25
//
//  Created by Dheeraj Kumar Sharma on 24/01/21.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
    }
    
}

