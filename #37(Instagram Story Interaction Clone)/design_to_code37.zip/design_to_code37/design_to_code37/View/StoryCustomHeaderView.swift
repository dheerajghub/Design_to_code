//
//  StoryCustomHeaderView.swift
//  design_to_code37
//
//  Created by Dheeraj Kumar Sharma on 15/08/21.
//

import UIKit

protocol HeaderActionDelegate {
    func didCloseTapped()
}

class StoryCustomHeaderView: UIView {

    // MARK: PROPERTIES -
    
    let trackLayer = CAShapeLayer()
    var delegate: HeaderActionDelegate?
    var animateFrom = 0.0
    
    let gradientView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let userInfoView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let profileView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let profileImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "user")
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 16
        img.clipsToBounds = true
        return img
    }()
    
    let plusButton: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setImage(UIImage(named: "ic_plus")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        btn.backgroundColor = UIColor(red: 69/255, green: 142/255, blue: 255/255, alpha: 1)
        btn.layer.cornerRadius = 6
        btn.layer.borderWidth = 1
        btn.layer.borderColor = UIColor.white.cgColor
        return btn
    }()
    
    lazy var storyLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.attributedText = setAttributedLabel("Your Story", "12h")
        
        l.layer.shadowColor = UIColor.black.cgColor
        l.layer.shadowRadius = 5
        l.layer.shadowOffset = CGSize(width: 0, height: 0)
        l.layer.shadowOpacity = 0.3
        
        return l
    }()
    
    lazy var closeBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "ic_close")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.tintColor = .white
        btn.addTarget(self, action: #selector(closeBtnPressed), for: .touchUpInside)
        
        btn.layer.shadowColor = UIColor.black.withAlphaComponent(0.5).cgColor
        btn.layer.shadowRadius = 5
        btn.layer.shadowOffset = CGSize(width: 0, height: 0)
        btn.layer.shadowOpacity = 0.2
        
        return btn
    }()
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
        setUpLayer()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
//        backgroundColor = .black
        addSubview(gradientView)
        addSubview(userInfoView)
        userInfoView.addSubview(profileView)
        profileView.addSubview(profileImage)
        profileView.addSubview(plusButton)
        userInfoView.addSubview(storyLabel)
        userInfoView.addSubview(closeBtn)
    }
    
    func setUpContraints(){
        gradientView.pin(to: self)
        profileImage.pin(to: profileView)
        NSLayoutConstraint.activate([
            userInfoView.leadingAnchor.constraint(equalTo: leadingAnchor),
            userInfoView.trailingAnchor.constraint(equalTo: trailingAnchor),
            userInfoView.heightAnchor.constraint(equalToConstant: 32),
            userInfoView.topAnchor.constraint(equalTo: topAnchor, constant: 17),
            
            profileView.leadingAnchor.constraint(equalTo: userInfoView.leadingAnchor, constant: 12),
            profileView.centerYAnchor.constraint(equalTo: userInfoView.centerYAnchor),
            profileView.heightAnchor.constraint(equalToConstant: 32),
            profileView.widthAnchor.constraint(equalToConstant: 32),
            
            storyLabel.leadingAnchor.constraint(equalTo: profileView.trailingAnchor, constant: 5),
            storyLabel.centerYAnchor.constraint(equalTo: userInfoView.centerYAnchor),
            
            plusButton.trailingAnchor.constraint(equalTo: profileView.trailingAnchor, constant: 2),
            plusButton.bottomAnchor.constraint(equalTo: profileView.bottomAnchor, constant: 2),
            plusButton.widthAnchor.constraint(equalToConstant: 12),
            plusButton.heightAnchor.constraint(equalToConstant: 12),
            
            closeBtn.trailingAnchor.constraint(equalTo: userInfoView.trailingAnchor, constant: -5),
            closeBtn.centerYAnchor.constraint(equalTo: userInfoView.centerYAnchor),
            closeBtn.widthAnchor.constraint(equalToConstant: 32),
            closeBtn.heightAnchor.constraint(equalToConstant: 32)
        ])
    }
    
    func setUpLayer(){
        let linePath = UIBezierPath()
        linePath.move(to: CGPoint(x: 0, y: 0))
        linePath.addLine(to: CGPoint(x: UIScreen.main.bounds.width - 20, y: 0))
        
        let line = CAShapeLayer()
        line.path = linePath.cgPath
        line.opacity = 1.0
        line.lineWidth = 2
        line.lineCap = .round
        line.strokeColor = UIColor.white.withAlphaComponent(0.3).cgColor
        line.position = CGPoint(x: 10, y: 8)
        
        line.shadowColor = UIColor.black.cgColor
        line.shadowOffset = CGSize(width: 0, height: 0)
        line.shadowRadius = 10
        line.shadowOpacity = 1.0
        
        self.layer.addSublayer(line)
        
        trackLayer.path = linePath.cgPath
        trackLayer.opacity = 1.0
        trackLayer.lineWidth = 2
        trackLayer.lineCap = .round
        trackLayer.strokeEnd = 0.55
        trackLayer.strokeColor = UIColor.white.cgColor
        trackLayer.position = CGPoint(x: 10, y: 8)
        
        self.layer.addSublayer(trackLayer)
    }
    
    func startAnimatingTrackLayer(){
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = animateFrom
        animation.duration = 30
        animation.toValue = 1.0
        animation.fillMode = .forwards
        animation.isRemovedOnCompletion = false
        trackLayer.add(animation, forKey: "strokeAnimation")
    }
    
    func stopAnimatingTrackLayer(){
        if let presentationLayer = trackLayer.presentation() {
            trackLayer.strokeEnd = presentationLayer.strokeEnd
        }
        trackLayer.removeAnimation(forKey: "strokeAnimation")
        animateFrom = Double(trackLayer.strokeEnd)
    }
    
    func setAttributedLabel(_ title: String, _ subTitle: String) -> NSAttributedString{
        let attributedText = NSMutableAttributedString(attributedString: NSAttributedString(string: "\(title)  ", attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14, weight: .semibold) , NSAttributedString.Key.foregroundColor: UIColor.white]))
        attributedText.append(NSAttributedString(string: "\(subTitle)", attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14, weight: .medium) , NSAttributedString.Key.foregroundColor: UIColor.white.withAlphaComponent(0.8)]))
        return attributedText
    }
    
    @objc func closeBtnPressed(){
        delegate?.didCloseTapped()
    }
    
}
