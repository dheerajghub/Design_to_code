//
//  CustomBottomActionView.swift
//  design_to_code37
//
//  Created by Dheeraj Kumar Sharma on 14/08/21.
//

import UIKit

class CustomBottomActionView: UIView {

    // MARK: PROPERTIES -
    
    let imageArr = ["img1", "img2" , "img3"]
    
    /// Seen By view
    
    let seenByView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .black
        return v
    }()
    
    let seenByStackView: UIStackView = {
        let sv = UIStackView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.spacing = -8
        sv.axis = .horizontal
        sv.distribution = .fillEqually
        return sv
    }()
    
    let seenByLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Seen by 1,204"
        l.textColor = .white
        l.font = UIFont.systemFont(ofSize: 11, weight: .medium)
        return l
    }()
    
    ///:
    
    /// Other Actions
    
    let otherActionStackView: UIStackView = {
        let sv = UIStackView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.spacing = 5
        sv.axis = .horizontal
        sv.distribution = .fillEqually
        return sv
    }()
    
    let faceBookBtnView: StoryGlobalActionView = {
        let v = StoryGlobalActionView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.actionImageView.image = UIImage(named: "ic_facebook")
        v.actionTitleLabel.text = "facebook".capitalized
        return v
    }()
    
    let highlightBtnView: StoryGlobalActionView = {
        let v = StoryGlobalActionView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.actionImageView.image = UIImage(named: "ic_highlight")
        v.actionTitleLabel.text = "highlight".capitalized
        return v
    }()
    
    let moreBtnView: StoryGlobalActionView = {
        let v = StoryGlobalActionView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.actionImageView.image = UIImage(named: "ic_more")
        v.actionTitleLabel.text = "more".capitalized
        return v
    }()
    
    ///:
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        addSubview(seenByView)
        seenByView.addSubview(seenByStackView)
        seenByView.addSubview(seenByLabel)
        for i in imageArr {
            createDynamicImageView(i)
        }
        
        addSubview(otherActionStackView)
        otherActionStackView.addArrangedSubview(faceBookBtnView)
        otherActionStackView.addArrangedSubview(highlightBtnView)
        otherActionStackView.addArrangedSubview(moreBtnView)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            seenByView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            seenByView.topAnchor.constraint(equalTo: topAnchor),
            seenByView.widthAnchor.constraint(equalToConstant: 80),
            seenByView.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            seenByStackView.centerXAnchor.constraint(equalTo: seenByView.centerXAnchor),
            seenByStackView.heightAnchor.constraint(equalToConstant: 30),
            seenByStackView.topAnchor.constraint(equalTo: seenByView.topAnchor, constant: 6),
            
            seenByLabel.topAnchor.constraint(equalTo: seenByStackView.bottomAnchor, constant: 4),
            seenByLabel.centerXAnchor.constraint(equalTo: seenByView.centerXAnchor),
            
            otherActionStackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            otherActionStackView.topAnchor.constraint(equalTo: topAnchor),
            otherActionStackView.widthAnchor.constraint(equalToConstant: 190),
            otherActionStackView.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            faceBookBtnView.widthAnchor.constraint(equalToConstant: 60),
            faceBookBtnView.heightAnchor.constraint(equalToConstant: 60),
            
            highlightBtnView.widthAnchor.constraint(equalToConstant: 60),
            highlightBtnView.heightAnchor.constraint(equalToConstant: 60),
            
            moreBtnView.widthAnchor.constraint(equalToConstant: 60),
            moreBtnView.heightAnchor.constraint(equalToConstant: 60)
        ])
    }
    
    func createDynamicImageView(_ data: String){
        
        let seenBy: UIImageView = {
            let img = UIImageView()
            img.translatesAutoresizingMaskIntoConstraints = false
            img.image = UIImage(named: data)
            img.clipsToBounds = true
            img.layer.cornerRadius = 15
            img.layer.borderWidth = 2
            img.contentMode = .scaleAspectFill
            img.layer.borderColor = UIColor.black.cgColor
            return img
        }()
        
        seenByStackView.addArrangedSubview(seenBy)
        
        NSLayoutConstraint.activate([
            seenBy.widthAnchor.constraint(equalToConstant: 30),
            seenBy.heightAnchor.constraint(equalToConstant: 30)
        ])
        
    }

}

