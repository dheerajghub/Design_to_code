//
//  StoryGlobalActionView.swift
//  design_to_code37
//
//  Created by Dheeraj Kumar Sharma on 14/08/21.
//

import UIKit

class StoryGlobalActionView: UIView {

    // MARK: PROPERTIES -
    
    let actionImageView: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let actionTitleLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .white
        l.font = UIFont.systemFont(ofSize: 11, weight: .medium)
        return l
    }()
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        addSubview(actionImageView)
        addSubview(actionTitleLabel)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            actionImageView.centerXAnchor.constraint(equalTo: centerXAnchor),
            actionImageView.widthAnchor.constraint(equalToConstant: 25),
            actionImageView.heightAnchor.constraint(equalToConstant: 25),
            actionImageView.topAnchor.constraint(equalTo: topAnchor, constant: 8.5),
            
            actionTitleLabel.topAnchor.constraint(equalTo: actionImageView.bottomAnchor, constant: 5),
            actionTitleLabel.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }

}
