//
//  StoryViewController.swift
//  design_to_code37
//
//  Created by Dheeraj Kumar Sharma on 14/08/21.
//

import UIKit
import AVKit

protocol StoryActionDelegate {
    func didViewDismissed()
}

class StoryViewController: UIViewController {

    // MARK: PROPERTIES -
    
    var player = AVPlayer()
    var delegate: StoryActionDelegate?
    
    lazy var storyHeaderView: StoryCustomHeaderView = {
        let v = StoryCustomHeaderView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.delegate = self
        return v
    }()
    
    let storyCardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 10
        v.layer.masksToBounds = true
        return v
    }()
    
    lazy var storyActionView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.isUserInteractionEnabled = true
        
        /// Adding Long press Gestures
        let longTapGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        v.addGestureRecognizer(longTapGesture)
        
        return v
    }()
    
    let bottomActionView: CustomBottomActionView = {
        let v = CustomBottomActionView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    lazy var nextBtn: UIView = {
        let btn = UIView()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.isUserInteractionEnabled = true
        
        /// Adding Tap Gestures
        let nextTapGesture = UITapGestureRecognizer(target: self, action: #selector(nextBtnTapped))
        btn.addGestureRecognizer(nextTapGesture)
        
        /// Adding Long press Gestures
        let longTapGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        btn.addGestureRecognizer(longTapGesture)
        
        return btn
    }()
    
    lazy var previousBtn: UIView = {
        let btn = UIView()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.isUserInteractionEnabled = true
        
        /// Adding Tap Gestures
        let previousTapGesture = UITapGestureRecognizer(target: self, action: #selector(previousBtnTapped))
        btn.addGestureRecognizer(previousTapGesture)
        
        /// Adding Long press Gestures
        let longTapGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(_:)))
        btn.addGestureRecognizer(longTapGesture)
        
        return btn
    }()
    
    // MARK: MAIN -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViews()
        setUpContraints()
        
        DispatchQueue.main.async {
            self.storyHeaderView.gradientView.createGradientLayer([UIColor.black.withAlphaComponent(0.2).cgColor, UIColor.clear.cgColor], CGPoint(x: 0, y: 0), CGPoint(x: 0, y: 1))
            self.setUpVideoPlayer()
        }
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        view.backgroundColor = .black
        view.addSubview(storyCardView)
        view.addSubview(bottomActionView)
        
        view.addSubview(storyActionView)
        storyActionView.addSubview(nextBtn)
        storyActionView.addSubview(previousBtn)
        
        view.addSubview(storyHeaderView)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            storyCardView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            storyCardView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            storyCardView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            storyCardView.bottomAnchor.constraint(equalTo: bottomActionView.topAnchor),
            
            bottomActionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomActionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomActionView.heightAnchor.constraint(equalToConstant: 60),
            bottomActionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            storyHeaderView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            storyHeaderView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            storyHeaderView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            storyHeaderView.heightAnchor.constraint(equalToConstant: 70),
            
            storyActionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            storyActionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            storyActionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            storyActionView.bottomAnchor.constraint(equalTo: bottomActionView.bottomAnchor),
            
            previousBtn.leadingAnchor.constraint(equalTo: storyCardView.leadingAnchor),
            previousBtn.topAnchor.constraint(equalTo: storyCardView.topAnchor),
            previousBtn.bottomAnchor.constraint(equalTo: storyCardView.bottomAnchor),
            previousBtn.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width * 0.3),
            
            nextBtn.trailingAnchor.constraint(equalTo: storyCardView.trailingAnchor),
            nextBtn.topAnchor.constraint(equalTo: storyCardView.topAnchor),
            nextBtn.bottomAnchor.constraint(equalTo: storyCardView.bottomAnchor),
            nextBtn.widthAnchor.constraint(equalToConstant: UIScreen.main.bounds.width * 0.3)
        ])
    }
    
    func setUpVideoPlayer(){
        guard let path = Bundle.main.path(forResource: "demo", ofType:"mp4") else {
            debugPrint("video.m4v not found")
            return
        }
        player = AVPlayer(url: URL(fileURLWithPath: path))
        let playerLayer = AVPlayerLayer(player: player)
        playerLayer.frame = self.storyCardView.bounds
        playerLayer.videoGravity = .resizeAspectFill
        self.storyCardView.layer.addSublayer(playerLayer)
        player.play()
        
        storyHeaderView.animateFrom = 0
        storyHeaderView.startAnimatingTrackLayer()
    }
    
    func toggleHiddenViews(_ state: String){
        if state == "hide" {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
                self.storyHeaderView.alpha = 0
                self.bottomActionView.alpha = 0
            } completion: { finished in
                self.storyHeaderView.isHidden = true
                self.bottomActionView.isHidden = true
            }
        } else {
            self.storyHeaderView.isHidden = false
            self.bottomActionView.isHidden = false
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
                self.storyHeaderView.alpha = 1
                self.bottomActionView.alpha = 1
            }
        }
    }
    
    @objc func handleLongPress(_ gesture: UILongPressGestureRecognizer){
        if gesture.state == .began || gesture.state == .changed {
            player.pause()
            storyHeaderView.stopAnimatingTrackLayer()
            toggleHiddenViews("hide")
        } else if gesture.state == .ended {
            storyHeaderView.startAnimatingTrackLayer()
            player.play()
            toggleHiddenViews("show")
        }
    }
    
    @objc func nextBtnTapped(){
        /// Dismiss or play next video if any....
        storyHeaderView.animateFrom = 1
        storyHeaderView.startAnimatingTrackLayer()
    }
    
    @objc func previousBtnTapped(){
        /// Play video again
        let timeIntvl: TimeInterval = 0
        let cmTime = CMTime(seconds: timeIntvl, preferredTimescale: 1000000)
        player.seek(to: cmTime)
        player.play()
        
        storyHeaderView.animateFrom = 0
        storyHeaderView.startAnimatingTrackLayer()
        
        toggleHiddenViews("show")
    }
}

extension StoryViewController: HeaderActionDelegate {
    
    func didCloseTapped() {
        player.pause()
        delegate?.didViewDismissed()
        dismiss(animated: true, completion: nil)
    }
    
}
