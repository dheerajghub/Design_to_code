//
//  HomeViewController.swift
//  design_to_code37
//
//  Created by Dheeraj Kumar Sharma on 15/08/21.
//

import UIKit

class HomeViewController: UIViewController, UIViewControllerTransitioningDelegate {

    // MARK: PROPERTIES -
    
    let transition = CircularTransition()
    
    let circularLayer = CAShapeLayer()
    var timer = Timer()
    var labelTimer = Timer()
    var labelCount = 0
    
    var labelArray = ["Instagram Story Clone" , "using Swift UIKit"]
    
    let copyrightLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "@dheeraj.iosdev"
        l.textColor = UIColor(red: 225/225, green: 48/255, blue: 108/255, alpha: 0.1)
        l.font = UIFont.systemFont(ofSize: 25, weight: .black)
        return l
    }()
    
    let animationLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.systemFont(ofSize: 30, weight: .black)
        l.isHidden = true
        l.alpha = 0
        l.transform = .init(scaleX: 0.5, y: 0.5)
        l.textColor = .black
        l.numberOfLines = 0
        l.textAlignment = .center
        return l
    }()
    
    let profileBtnOverlay: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.isHidden = true
        v.alpha = 0
        return v
    }()
    
    lazy var profileBtnView: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "user"), for: .normal)
        btn.layer.cornerRadius = 30
        btn.clipsToBounds = true
        btn.addTarget(self, action: #selector(profileTapped), for: .touchUpInside)
        return btn
    }()
    
    // MARK: MAIN -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpViews()
        setUpContraints()
        setUpLayer()
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        view.backgroundColor = .white
        view.addSubview(profileBtnOverlay)
        profileBtnOverlay.addSubview(profileBtnView)
        
        view.addSubview(animationLabel)
        
        labelTimer = Timer.scheduledTimer(withTimeInterval: 2.4, repeats: true) { [weak self] timer in
            self?.animateIntroLabel(true)
        }
        
        view.addSubview(copyrightLabel)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            profileBtnOverlay.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            profileBtnOverlay.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileBtnOverlay.widthAnchor.constraint(equalToConstant: 80),
            profileBtnOverlay.heightAnchor.constraint(equalToConstant: 80),
            
            profileBtnView.centerYAnchor.constraint(equalTo: profileBtnOverlay.centerYAnchor),
            profileBtnView.centerXAnchor.constraint(equalTo: profileBtnOverlay.centerXAnchor),
            profileBtnView.widthAnchor.constraint(equalToConstant: 60),
            profileBtnView.heightAnchor.constraint(equalToConstant: 60),
            
            animationLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            animationLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            animationLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
            animationLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30),
            
            copyrightLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            copyrightLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -15)
        ])
    }
    
    func setUpLayer(){
        let circularPath = UIBezierPath(arcCenter: .zero, radius: 35, startAngle: -CGFloat.pi / 2, endAngle: 2 * CGFloat.pi, clockwise: true)
        
        circularLayer.strokeColor = UIColor(red: 225/225, green: 48/255, blue: 108/255, alpha: 1).cgColor
        circularLayer.fillColor = UIColor.clear.cgColor
        circularLayer.lineWidth = 3
        circularLayer.path = circularPath.cgPath
        circularLayer.position = CGPoint(x: 40, y: 40)
        
        circularLayer.shadowColor = UIColor.black.withAlphaComponent(0.1).cgColor
        circularLayer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        circularLayer.shadowOpacity = 1.0
        circularLayer.shadowRadius = 10.0
        
        profileBtnOverlay.layer.addSublayer(circularLayer)
    }
    
    func layerScaleAnimation( _ scale: Bool){
        let scaleAnimation = CABasicAnimation(keyPath: "transform.scale")
        if scale {
            scaleAnimation.duration = 0.4
            scaleAnimation.fromValue = 1.0
            scaleAnimation.toValue = 1.1
            scaleAnimation.fillMode = .forwards
            scaleAnimation.isRemovedOnCompletion = false
            circularLayer.strokeColor = UIColor(red: 225/225, green: 48/255, blue: 108/255, alpha: 0.5).cgColor
        } else {
            scaleAnimation.duration = 0.2
            scaleAnimation.fromValue = 1.1
            scaleAnimation.toValue = 1.0
            scaleAnimation.fillMode = .backwards
            scaleAnimation.isRemovedOnCompletion = true
            circularLayer.strokeColor = UIColor(red: 225/225, green: 48/255, blue: 108/255, alpha: 1).cgColor
        }
        scaleAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        circularLayer.add(scaleAnimation, forKey: "scale")
    }
    
    func layerLineWidthAnimation(){
        let animation = CABasicAnimation(keyPath: "lineWidth")
        animation.duration = 0.7
        animation.fromValue = 3
        animation.toValue = 5
        animation.repeatCount = .greatestFiniteMagnitude
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        animation.autoreverses = true
        circularLayer.add(animation, forKey: "width")
    }
    
    func animateIntroLabel(_ shouldHideLastText: Bool){
        if labelCount == labelArray.count {
            labelTimer.invalidate()
            showStoryView()
            return
        }
        
        animationLabel.isHidden = false
        animationLabel.text = labelArray[labelCount]
        UIView.animate(withDuration: 0.4, delay: 0, options: .curveEaseInOut) { [self] in
            animationLabel.alpha = 1
            animationLabel.transform = .identity
        } completion: { [self] finised in
            if labelCount != labelArray.count - 1 {
                if shouldHideLastText {
                    UIView.animate(withDuration: 0.3, delay: 1, options: .curveEaseInOut) {
                        animationLabel.alpha = 0
                        animationLabel.transform = .init(scaleX: 1.4, y: 1.4)
                    } completion: { [self] finised in
                        animationLabel.isHidden = true
                        animationLabel.transform = .init(scaleX: 0.5, y: 0.5)
                    }
                }
            } else {
                UIView.animate(withDuration: 0.3, delay: 1, options: .curveEaseInOut) {
                    animationLabel.alpha = 0
                    animationLabel.transform = .init(scaleX: 1.4, y: 1.4)
                } completion: { [self] finised in
                    animationLabel.isHidden = true
                    animationLabel.transform = .init(scaleX: 0.5, y: 0.5)
                }
            }
        }
        labelCount += 1
    }
    
    func showStoryView(){
        profileBtnOverlay.isHidden = false
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut) { [self] in
            profileBtnOverlay.alpha = 1
            profileBtnOverlay.transform = .init(scaleX: 1.5, y: 1.5)
        }
    }
    
    @objc func profileTapped(){
        layerScaleAnimation(true)
        layerLineWidthAnimation()
        
        UIView.animate(withDuration: 0.4, delay: 0, options: .curveEaseInOut) { [self] in
            profileBtnView.transform = .init(scaleX: 0.7, y: 0.7)
        }
        
        timer = Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { [weak self] timer in
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseInOut) { [self] in
                self?.profileBtnView.transform = .identity
                self?.layerScaleAnimation(false)
                self?.circularLayer.removeAnimation(forKey: "width")
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                let VC = StoryViewController()
                VC.modalPresentationStyle = .custom
                VC.transitioningDelegate = self
                VC.delegate = self
                self?.present(VC, animated: true, completion: nil)
            }
        }
        
    }
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .present
        transition.startingPoint = self.view.center
        transition.circleColor = UIColor(red: 225/225, green: 48/255, blue: 108/255, alpha: 1)
        
        return transition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .dismiss
        transition.startingPoint = self.view.center
        transition.circleColor = UIColor(red: 225/225, green: 48/255, blue: 108/255, alpha: 1)
        
        return transition
    }

}

extension HomeViewController: StoryActionDelegate {
    
    func didViewDismissed() {
        
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseInOut) { [self] in
            profileBtnOverlay.transform = .identity
            profileBtnOverlay.alpha = 0
        } completion: { [self] finished in
            profileBtnView.isHidden = true
            labelCount = 0
            labelArray = ["Happy Independence Day 🇮🇳"]
            animateIntroLabel(false)
        }
    }
    
}
