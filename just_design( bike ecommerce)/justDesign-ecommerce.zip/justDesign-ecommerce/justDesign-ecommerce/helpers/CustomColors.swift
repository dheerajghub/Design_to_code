//
//  CustomColors.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColor {
    
    static let mainColor:UIColor = UIColor(red: 247/255, green: 247/255, blue: 253/255, alpha: 1)
    static let matteBlack:UIColor = UIColor(red: 41/255, green: 41/255, blue: 41/255, alpha: 1)
    static let textGray:UIColor = UIColor(red: 147/255, green: 148/255, blue: 169/255, alpha: 1)
    static let textLightGray:UIColor = UIColor(red: 148/255, green: 153/255, blue: 179/255, alpha: 0.7)
    static let cardLightBlue:UIColor = UIColor(red: 230/255, green: 234/255, blue: 251/255, alpha: 1)
    static let cardBlue:UIColor = UIColor(red: 9/255, green: 100/255, blue: 246/255, alpha: 1)
    static let matteGreen:UIColor = UIColor(red: 88/255, green: 197/255, blue: 152/255, alpha: 1)
    
}

