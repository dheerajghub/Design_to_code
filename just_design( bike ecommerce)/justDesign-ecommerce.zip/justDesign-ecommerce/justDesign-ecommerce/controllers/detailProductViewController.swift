//
//  detailProductViewController.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct ProductDetailContent{
    var image:String!
    var productName:String!
    var price:String!
    var desc:String!
}

enum likeBtnState{
    case liked
    case notliked
}

class detailProductViewController: UIViewController, UIGestureRecognizerDelegate {
    
    @IBOutlet weak var likeBtn: UIButton!
    @IBOutlet weak var buyNowBtn: UIButton!
    @IBOutlet weak var productName:UILabel!
    @IBOutlet weak var productPrice:UILabel!
    @IBOutlet weak var productDesc:UILabel!
    @IBOutlet weak var productImage:UIImageView!
    var state:likeBtnState?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setUpViews()
        setNavigationBar()
        productImage.image = UIImage(named: "pdimg1")
        productImage.contentMode = .scaleAspectFill
        state = .notliked
    }
    
    override var prefersStatusBarHidden: Bool{
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setNavigationBar()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        animateImage()
        animateText()
        animateBtn()
    }
    
    func setNavigationBar(){
        
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.barTintColor = .white
        navigationController?.navigationBar.layer.shadowOpacity = 0
        navigationController?.interactivePopGestureRecognizer!.delegate = self
        navigationController?.interactivePopGestureRecognizer!.isEnabled = true
        
        //Nav bar Buttons
        let back = UIButton(type: .system)
        back.setImage(UIImage(named: "back")?.withRenderingMode(.alwaysOriginal), for: .normal)
        back.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: back)
        back.addTarget(self, action: #selector(backBtn), for: .touchUpInside)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = back
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
        
        
        let cart = UIButton(type: .system)
        cart.setImage(UIImage(named: "cart")?.withRenderingMode(.alwaysOriginal), for: .normal)
        cart.frame = CGRect(x: 0, y: 0, width: 0, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: cart)
        cart.addTarget(self, action: #selector(cartBtn), for: .touchUpInside)
        
        let cartButtonItem = UIBarButtonItem()
        cartButtonItem.customView = cart
        
        let search = UIButton(type: .system)
        search.setImage(UIImage(named: "search")?.withRenderingMode(.alwaysOriginal), for: .normal)
        search.frame = CGRect(x: 0, y: 0, width: 60, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: cart)
        search.addTarget(self, action: #selector(searchBtn), for: .touchUpInside)
        
        let searchButtonItem = UIBarButtonItem()
        searchButtonItem.customView = search
        
        navigationItem.setRightBarButtonItems([cartButtonItem, searchButtonItem ], animated: true)
    }
    
    func setUpViews(){
        likeBtn.layer.borderWidth = 1
        likeBtn.layer.borderColor = CustomColor.textGray.cgColor
        likeBtn.backgroundColor = .clear
        likeBtn.setImage(UIImage(named: "likegrey")?.withRenderingMode(.alwaysOriginal), for: .normal)
        likeBtn.layer.masksToBounds = true
        likeBtn.layer.cornerRadius = 15
        
        buyNowBtn.layer.cornerRadius = 15
        buyNowBtn.setTitle("Buy now", for: .normal)
        buyNowBtn.titleLabel!.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        buyNowBtn.setTitleColor(.white, for: .normal)
        buyNowBtn.backgroundColor = CustomColor.matteGreen
        
        productName.textColor = CustomColor.cardBlue
        productPrice.textColor = CustomColor.matteBlack
        productDesc.textColor = CustomColor.textLightGray
        
        productName.text = "IF MODE AL7005"
        productPrice.text = "$ 2,850"
        let titleText = "The clean and striking IF MODE is aimed at commuters of the mobile generation who, until now, may have not considered cycling or folding bikes to be an option."
        
        let paragraphStyle = NSMutableParagraphStyle()
        //line height size
        paragraphStyle.lineSpacing = 4
        let attrString = NSMutableAttributedString(string: titleText)
        attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, attrString.length))
        productDesc.attributedText = attrString
        productDesc.textAlignment = NSTextAlignment.left
        
        productImage.isHidden = true
        productDesc.isHidden = true
        productName.isHidden = true
        productPrice.isHidden = true
        likeBtn.isHidden = true
        buyNowBtn.isHidden = true
    }
    
    func animateImage(){
        UIView.animate(withDuration: 0.01, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.productImage.center.x -= 200
            self.productImage.transform = .init(scaleX: 0.8, y: 0.8)
            self.productImage.alpha = 0.5
        }, completion: { _ in
            UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.productImage.isHidden = false
                self.productImage.transform = .init(scaleX: 1, y: 1)
                self.productImage.center.x += 200
                self.productImage.alpha = 1
            })
        })
    }
    
    func animateText(){
        UIView.animate(withDuration: 0.01, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.productName.center.y += 100
            self.productName.alpha = 0.5
            self.productPrice.center.y += 150
            self.productPrice.alpha = 0.5
            self.productDesc.center.y += 200
            self.productDesc.alpha = 0.5
        }, completion: { _ in
            UIView.animate(withDuration: 0.8, delay: 0.02, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.productName.isHidden = false
                self.productName.center.y -= 100
                self.productName.alpha = 1
                self.productPrice.isHidden = false
                self.productPrice.center.y -= 150
                self.productPrice.alpha = 1
                self.productDesc.isHidden = false
                self.productDesc.center.y -= 200
                self.productDesc.alpha = 1
            })
        })
    }
    
    func animateBtn(){
        UIView.animate(withDuration: 0.01, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.8, options: .curveEaseIn, animations: {
            self.likeBtn.center.y += 100
            self.likeBtn.alpha = 0.5
            self.buyNowBtn.center.y += 200
            self.buyNowBtn.alpha = 0.5
        }, completion: { _ in
            UIView.animate(withDuration: 1, delay: 0.03, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.likeBtn.isHidden = false
                self.likeBtn.center.y -= 100
                self.likeBtn.alpha = 1
                self.buyNowBtn.isHidden = false
                self.buyNowBtn.center.y -= 200
                self.buyNowBtn.alpha = 1
            })
        })
    }
    
    @objc func backBtn(){
        navigationController?.popViewController(animated: true)
    }
    
    @objc func cartBtn(){
        
    }
    
    @objc func searchBtn(){
        
    }
    
    @IBAction func likeBtnPressed(_ sender: UIButton) {
        sender.touchAnimation(s: sender)
        if(state == .notliked){
            likeBtn.backgroundColor = CustomColor.matteBlack
            likeBtn.setImage(UIImage(named: "selectedlikegrey")?.withRenderingMode(.alwaysOriginal), for: .normal)
            likeBtn.layer.borderWidth = 0
            state = .liked
        } else {
            likeBtn.backgroundColor = .white
            likeBtn.setImage(UIImage(named: "likegrey")?.withRenderingMode(.alwaysOriginal), for: .normal)
            likeBtn.layer.borderWidth = 1
            state = .notliked
        }
    }
    
    @IBAction func buyNowPressed(_ sender: UIButton) {
        sender.touchAnimation(s: sender)
    }
    
}
