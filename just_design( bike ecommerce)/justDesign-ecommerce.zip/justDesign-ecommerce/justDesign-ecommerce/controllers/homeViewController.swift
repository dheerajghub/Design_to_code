//
//  homeViewController.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

private let featureProductIdentifier = "featuredProductCollectionViewCell"
private let productCategoryIdentifier = "productCategoryCollectionViewCell"

class homeViewController: UIViewController {
    
    @IBOutlet weak var collectionView:UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = CustomColor.mainColor
        collectionView.backgroundColor = CustomColor.mainColor
        setNavigationBar()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: featureProductIdentifier , bundle: nil), forCellWithReuseIdentifier: featureProductIdentifier)
        collectionView.register(UINib(nibName: productCategoryIdentifier , bundle: nil), forCellWithReuseIdentifier: productCategoryIdentifier)
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        setNavigationBar()
    }
    
    func setNavigationBar(){
        
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.barTintColor = CustomColor.mainColor
        navigationController?.navigationBar.layer.shadowOpacity = 0
        
        //Nav bar Buttons
        let menu = UIButton(type: .system)
        menu.setImage(UIImage(named: "menu")?.withRenderingMode(.alwaysOriginal), for: .normal)
        menu.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: menu)
        menu.addTarget(self, action: #selector(menuBtn), for: .touchUpInside)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = menu
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
        
        
        let cart = UIButton(type: .system)
        cart.setImage(UIImage(named: "cart")?.withRenderingMode(.alwaysOriginal), for: .normal)
        cart.frame = CGRect(x: 0, y: 0, width: 0, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: cart)
        cart.addTarget(self, action: #selector(cartBtn), for: .touchUpInside)
        
        let cartButtonItem = UIBarButtonItem()
        cartButtonItem.customView = cart
        
        let search = UIButton(type: .system)
        search.setImage(UIImage(named: "search")?.withRenderingMode(.alwaysOriginal), for: .normal)
        search.frame = CGRect(x: 0, y: 0, width: 60, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: cart)
        search.addTarget(self, action: #selector(searchBtn), for: .touchUpInside)
        
        let searchButtonItem = UIBarButtonItem()
        searchButtonItem.customView = search
        
        navigationItem.setRightBarButtonItems([cartButtonItem, searchButtonItem ], animated: true)
    }
    
    @objc func menuBtn(){
        
    }
    
    @objc func cartBtn(){
        
    }
    
    @objc func searchBtn(){
        
    }
    
}

extension homeViewController:UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource , actionProtocol {
    
    func didCardTap() {
        performSegue(withIdentifier: "detail", sender: self)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == 0{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "featuredProductCollectionViewCell", for: indexPath) as! featuredProductCollectionViewCell
            return cell
        }
        if indexPath.row == 1{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "productCategoryCollectionViewCell", for: indexPath) as! productCategoryCollectionViewCell
            cell.delegate = self
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.row == 0 {
            return CGSize(width: collectionView.frame.width, height: 230)
        }
        if indexPath.row == 1 {
            return CGSize(width: collectionView.frame.width, height: 450)
        }
        return CGSize()
    }
    
}

