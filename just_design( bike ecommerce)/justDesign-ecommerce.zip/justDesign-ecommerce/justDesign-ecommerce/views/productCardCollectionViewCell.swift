//
//  productCardCollectionViewCell.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class productCardCollectionViewCell: UICollectionViewCell {
    
    var data:ProductContent?{
        didSet{
            manageData()
        }
    }
    
    @IBOutlet weak var cardView:UIView!
    @IBOutlet weak var cardImage:UIImageView!
    @IBOutlet weak var productName:UILabel!
    @IBOutlet weak var productPrice:UILabel!
    @IBOutlet weak var likeBtn: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setUpViews()
    }
    
    func setUpViews(){
        cardView.layer.cornerRadius = 20
        cardView.layer.shadowColor = CustomColor.matteBlack.cgColor
        cardView.layer.shadowOffset = CGSize(width: 0, height: 3)
        cardView.layer.shadowRadius = 7
        cardView.layer.shadowOpacity = 0.08
        
        productName.textColor = CustomColor.textGray
        productPrice.textColor = CustomColor.matteBlack
        
        cardImage.contentMode = .scaleAspectFill
    }
    
    func manageData(){
        guard let data = data else {return}
        productPrice.text = data.price
        productName.text = data.productName.uppercased()
        cardImage.image = UIImage(named: data.image)
        if(data.isLiked){
            likeBtn.setImage(UIImage(named: "selectedlike"), for: .normal)
        } else {
            likeBtn.setImage(UIImage(named: "like"), for: .normal)
        }
    }
    
}

