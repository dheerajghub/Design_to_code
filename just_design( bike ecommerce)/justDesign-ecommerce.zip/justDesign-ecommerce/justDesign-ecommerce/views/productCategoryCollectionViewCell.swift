//
//  productCategoryCollectionViewCell.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct ProductContent{
    var image:String!
    var isLiked:Bool!
    var productName:String!
    var price:String!
}

protocol actionProtocol {
    func didCardTap()
}

class productCategoryCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionView:UICollectionView!
    var productData = [ProductContent]()
    var delegate:actionProtocol?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "productCardCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "productCardCollectionViewCell")
        collectionView.delaysContentTouches = false
        collectionView.backgroundColor = CustomColor.mainColor
        
        productData = [
            ProductContent(image: "pimg1", isLiked: false, productName: "IF MODE AL7005", price: "$2,850"),
            ProductContent(image: "pimg2", isLiked: true, productName: "IF MOVE 9 SPEED", price: "$2,050")
        ]
    }
    
}

extension productCategoryCollectionViewCell:UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "productCardCollectionViewCell", for: indexPath) as! productCardCollectionViewCell
        cell.data = productData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let layout = collectionViewLayout as! UICollectionViewFlowLayout
        collectionView.collectionViewLayout = layout
        collectionView.contentInset = UIEdgeInsets(top: 10, left: 5 , bottom: 10, right: 5)
        return CGSize(width: 230, height: 430)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.didCardTap()
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            if let cell = collectionView.cellForItem(at: indexPath) as? productCardCollectionViewCell {
                cell.cardView.transform = .init(scaleX: 0.95, y: 0.95)
            }
        }, completion: { _ in
        })
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            if let cell = collectionView.cellForItem(at: indexPath) as? productCardCollectionViewCell {
                cell.cardView.transform = .identity
            }
        }, completion: { _ in
        })
    }
}
