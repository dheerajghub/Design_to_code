//
//  productCollectionViewCell.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class productCollectionViewCell: UICollectionViewCell {
    
    override var isSelected: Bool {
        didSet{
            UIView.animate(withDuration: 0.1) {
                self.contentView.backgroundColor = self.isSelected ? CustomColor.cardBlue : CustomColor.cardLightBlue
                self.isSelected ? self.scaleUpImage() : self.scaleDownImage()
                self.layoutIfNeeded()
            }
        }
    }
    
    @IBOutlet weak var productImg:UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        productImg.contentMode = .scaleAspectFill
        self.contentView.backgroundColor = CustomColor.cardLightBlue
        self.contentView.layer.cornerRadius = 25
    }
    
    func scaleUpImage(){
        UIView.animate(withDuration: 0.2, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.productImg.transform = .init(scaleX: 0.9, y: 0.9)
        }, completion: { _ in
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.productImg.transform = .init(scaleX: 1.2, y: 1.2)
            })
        })
    }
    
    func scaleDownImage(){
        UIView.animate(withDuration: 0.2, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.productImg.transform = .init(scaleX: 0.9, y: 0.9)
        }, completion: { _ in
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
                self.productImg.transform = .identity
            })
        })
    }
    
}
