//
//  featuredProductCollectionViewCell.swift
//  justDesign-ecommerce
//
//  Created by Dheeraj Kumar Sharma on 01/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class featuredProductCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var subtitle:UILabel!
    @IBOutlet weak var title:UILabel!
    @IBOutlet weak var collectionView:UICollectionView!
    @IBOutlet weak var cardView: UIView!
    var products:[String]!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        title.textColor = CustomColor.matteBlack
        subtitle.textColor = CustomColor.textGray
        cardView.backgroundColor = CustomColor.mainColor
        collectionView.backgroundColor = CustomColor.mainColor
        collectionView.delaysContentTouches = false
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "productCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "productCollectionViewCell")
        products = [ "img1", "img2", "img3", "img4" ]
    }
}

extension featuredProductCollectionViewCell:UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "productCollectionViewCell", for: indexPath) as! productCollectionViewCell
        cell.productImg.image = UIImage(named: products[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let layout = collectionViewLayout as! UICollectionViewFlowLayout
        collectionView.collectionViewLayout = layout
        collectionView.contentInset = UIEdgeInsets(top: 10, left: 20 , bottom: 10, right: 20)
        return CGSize(width: 80, height: 80)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            if let cell = collectionView.cellForItem(at: indexPath) as? productCollectionViewCell {
                cell.contentView.transform = .init(scaleX: 0.90, y: 0.90)
            }
        }, completion: { _ in
        })
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            if let cell = collectionView.cellForItem(at: indexPath) as? productCollectionViewCell {
                cell.contentView.transform = .identity
            }
        }, completion: { _ in
        })
    }
}
