//
//  FolderMenuCollectionViewCell.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 07/02/21.
//

import UIKit

class FolderMenuCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    override var isSelected: Bool {
        didSet {
            titleLabel.textColor = isSelected ? AppColor.appYellow : AppColor.textColor
        }
    }
    
    let titleLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Avenir-Black", size: 18)
        l.textColor = AppColor.textColor
        return l
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    
    func setUpViews(){
        addSubview(titleLabel)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            titleLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            titleLabel.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
}
