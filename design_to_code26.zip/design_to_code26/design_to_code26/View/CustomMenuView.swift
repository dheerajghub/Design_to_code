//
//  CustomMenuView.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 31/01/21.
//

import UIKit

class CustomMenuView: UIView {
    
    // MARK:- PROPERTIES
    
    let dataArr = ["Latest" , "For you" , "Discover"]
    
    lazy var collectionView: UICollectionView = {
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        cv.setCollectionViewLayout(layout, animated: false)
        cv.delegate = self
        cv.dataSource = self
        cv.register(FolderMenuCollectionViewCell.self, forCellWithReuseIdentifier: "FolderMenuCollectionViewCell")
        cv.backgroundColor = UIColor.clear
        cv.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 20)
        return cv
    }()
    
    let searchBtn: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "search")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = AppColor.textColor
        return img
    }()
    
    let dividerView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = AppColor.dividerView
        return v
    }()
    
    // MARK:- INIT
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = AppColor.backgroundColor
        setUpview()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS

    func setUpview(){
        addSubview(dividerView)
        addSubview(collectionView)
        addSubview(searchBtn)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            dividerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            dividerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            dividerView.heightAnchor.constraint(equalToConstant: 1),
            dividerView.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            collectionView.leadingAnchor.constraint(equalTo: leadingAnchor),
            collectionView.topAnchor.constraint(equalTo: topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: dividerView.topAnchor),
            collectionView.trailingAnchor.constraint(equalTo: searchBtn.leadingAnchor),
            
            searchBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            searchBtn.heightAnchor.constraint(equalToConstant: 32),
            searchBtn.widthAnchor.constraint(equalToConstant: 32),
            searchBtn.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
}

extension CustomMenuView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FolderMenuCollectionViewCell", for: indexPath) as! FolderMenuCollectionViewCell
        cell.titleLabel.text = dataArr[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let font = UIFont(name: "Avenir-Heavy", size: 18)!
        let estimatedW = dataArr[indexPath.row].width(withConstrainedHeight: 50, font: font)
        return CGSize(width: estimatedW, height: 50)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
}
