//
//  FeedTableViewCell.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 07/02/21.
//

import UIKit

class FeedTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    
    var data:FeedData?{
        didSet{
            manageData()
        }
    }
    
    let feedImageView: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let titleLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "August 27, 2020 - PBS NewHour full episode"
        l.font = UIFont(name: "Avenir-Heavy", size: 18)
        l.numberOfLines = 2
        l.textColor = AppColor.textColor
        return l
    }()
    
    let indicatorView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = AppColor.appYellow
        v.layer.cornerRadius = 5
        return v
    }()
    
    let durationLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "53min"
        l.font = UIFont(name: "Avenir-Heavy", size: 18)
        l.textColor = AppColor.textColor2
        return l
    }()
    
    let moreBtn: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "more")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = AppColor.textColor
        return img
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTION
    func setUpViews(){
        backgroundColor = .clear
        addSubview(feedImageView)
        addSubview(titleLabel)
        addSubview(durationLabel)
        addSubview(indicatorView)
        addSubview(moreBtn)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            feedImageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            feedImageView.widthAnchor.constraint(equalToConstant: 80),
            feedImageView.heightAnchor.constraint(equalToConstant: 80),
            feedImageView.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            titleLabel.leadingAnchor.constraint(equalTo: feedImageView.trailingAnchor, constant: 25),
            titleLabel.trailingAnchor.constraint(equalTo: moreBtn.leadingAnchor, constant: -9),
            titleLabel.topAnchor.constraint(equalTo: topAnchor, constant: 18),
            
            durationLabel.leadingAnchor.constraint(equalTo: indicatorView.trailingAnchor, constant: 10),
            durationLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 4),
            
            indicatorView.leadingAnchor.constraint(equalTo: feedImageView.trailingAnchor, constant: 25),
            indicatorView.heightAnchor.constraint(equalToConstant: 10),
            indicatorView.widthAnchor.constraint(equalToConstant: 10),
            indicatorView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 11),
            
            moreBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            moreBtn.heightAnchor.constraint(equalToConstant: 30),
            moreBtn.widthAnchor.constraint(equalToConstant: 30),
            moreBtn.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func manageData(){
        guard  let data = data else {return}
        titleLabel.text = data.title
        durationLabel.text = data.duration
        indicatorView.backgroundColor = data.active ? AppColor.appYellow : AppColor.appBlue
        feedImageView.image = UIImage(named: data.thumbImage)
    }
    
}
