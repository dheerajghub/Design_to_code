//
//  CustomPlayerView.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 07/02/21.
//

import UIKit
import MarqueeLabel

class CustomPlayerView: UIView {

    // MARK:- PROPERTIES
    
    var videoTimer: Timer?
    var time = 0.0
    
    let imageView: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img5")
        return img
    }()
    
    let marqueeLabel: MarqueeLabel = {
        let l = MarqueeLabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "#1521 - Josh Dubin & Jason Flom"
        l.font = UIFont(name: "Avenir-Heavy", size: 18)
        l.textColor = AppColor.textColor
        l.type = .continuous
        l.animationCurve = .linear
        l.fadeLength = 10.0
        l.leadingBuffer = 30.0
        l.trailingBuffer = 30.0
        return l
    }()
    
    let pausePlayBtn: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "pause")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = AppColor.textColor
        return img
    }()
    
    let trackBar: UIProgressView = {
        let v = UIProgressView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.progressTintColor = AppColor.appYellow
        v.progress = 0.0
        return v
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    func setUpViews(){
        addSubview(imageView)
        addSubview(marqueeLabel)
        addSubview(pausePlayBtn)
        addSubview(trackBar)
        
        videoTimer = Timer.scheduledTimer(timeInterval: 0.001, target: self, selector: #selector(changeTrackBar), userInfo: nil, repeats: true)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: leadingAnchor),
//            imageView.heightAnchor.constraint(equalToConstant: 90),
            imageView.topAnchor.constraint(equalTo: topAnchor),
            imageView.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 90),
            
            marqueeLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 10),
            marqueeLabel.trailingAnchor.constraint(equalTo: pausePlayBtn.leadingAnchor),
            marqueeLabel.topAnchor.constraint(equalTo: topAnchor, constant: 32),
            
            pausePlayBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            pausePlayBtn.topAnchor.constraint(equalTo: topAnchor, constant: 25),
            pausePlayBtn.heightAnchor.constraint(equalToConstant: 40),
            pausePlayBtn.widthAnchor.constraint(equalToConstant: 40),
            
            trackBar.leadingAnchor.constraint(equalTo: imageView.trailingAnchor),
            trackBar.trailingAnchor.constraint(equalTo: trailingAnchor),
            trackBar.topAnchor.constraint(equalTo: topAnchor)
        ])
    }
    
    @objc func changeTrackBar(){
        time += 0.001
        trackBar.progress = Float(time / 120)
        if time >= 120 {
            videoTimer!.invalidate()
        }
    }
    
}
