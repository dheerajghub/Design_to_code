//
//  HomeViewController.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 31/01/21.
//

import UIKit

class HomeViewController: UIViewController {

    // MARK:- PROPERTIES
    
    var feedData = [FeedData]()
    
    let menuView: CustomMenuView = {
        let v = CustomMenuView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.delegate = self
        tv.dataSource = self
        tv.register(FeedTableViewCell.self, forCellReuseIdentifier: "FeedTableViewCell")
        tv.backgroundColor = .clear
        tv.showsVerticalScrollIndicator = false
        tv.tableFooterView = UIView()
        tv.delaysContentTouches = false
        return tv
    }()
    
    let playerView: CustomPlayerView = {
        let pv = CustomPlayerView()
        pv.translatesAutoresizingMaskIntoConstraints = false
        pv.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.06)
        return pv
    }()
    
    // MARK:- MAIN
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigations()
        setUpViews()
        setUpconstraints()
    }

    // MARK:- FUNCTIONS
    
    func setUpNavigations(){
        
        if #available(iOS 11.0, *) {
            self.navigationController?.navigationBar.largeTitleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white, NSAttributedString.Key.font: UIFont(name: "Avenir-Black", size: 35)!]
        }
        
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.view.backgroundColor = AppColor.backgroundColor
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.title = "Feed"
        
        // Menu button
        let menuButton = UIButton(type: .system)
        menuButton.setImage(UIImage(named: "menu")?.withRenderingMode(.alwaysTemplate), for: .normal)
        menuButton.imageView?.contentMode = .scaleAspectFill
        menuButton.tintColor = AppColor.textColor
        menuButton.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: menuButton)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = menuButton
        
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: true)
        
        // Add button
        let addButton = UIButton(type: .system)
        addButton.setImage(UIImage(named: "add")?.withRenderingMode(.alwaysTemplate), for: .normal)
        addButton.imageView?.contentMode = .scaleAspectFill
        addButton.tintColor = AppColor.appYellow
        addButton.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: menuButton)
        
        let rightBarButtonItem = UIBarButtonItem()
        rightBarButtonItem.customView = addButton
        
        navigationItem.setRightBarButton(rightBarButtonItem, animated: true)
        
    }
    
    func setUpViews() {
        overrideUserInterfaceStyle = .dark
        view.backgroundColor = AppColor.backgroundColor
        view.addSubview(menuView)
        view.addSubview(tableView)
        view.addSubview(playerView)
        
        feedData = [
            FeedData(title: "3 the Einstien lettre - The Bomb", duration: "22min", active: false, thumbImage: "img1"),
            FeedData(title: "577: Something only i can see", duration: "1h 4min", active: false, thumbImage: "img2"),
            FeedData(title: "#1521 - Josh Dubin & Jason Flom", duration: "2min", active: true, thumbImage: "img5"),
            FeedData(title: "August 26, 2020 - PBS NewsHour full episode", duration: "53min", active: false, thumbImage: "img4"),
            FeedData(title: "Nice  White  Parents - Ep. 5", duration: "1hr 4min", active: false, thumbImage: "img3"),
            FeedData(title: "Keep your friend closer - Recast", duration: "43min", active: false, thumbImage: "img6")
        ]
        
    }
    
    func setUpconstraints(){
        NSLayoutConstraint.activate([
            menuView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            menuView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            menuView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            menuView.heightAnchor.constraint(equalToConstant: 50),
            
            tableView.topAnchor.constraint(equalTo: menuView.bottomAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: playerView.topAnchor),
            
            playerView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            playerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            playerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            playerView.heightAnchor.constraint(equalToConstant: 120)
        ])
    }
}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return feedData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FeedTableViewCell", for: indexPath) as! FeedTableViewCell
        cell.separatorInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: tableView.frame.width)
        cell.selectionStyle = .none
        cell.data = feedData[indexPath.row]
        cell.backgroundColor = feedData[indexPath.row].active ? UIColor(red: 1, green: 1, blue: 1, alpha: 0.1) : UIColor.clear
        return cell
    }
    
    func tableView(_ tableView: UITableView, didHighlightRowAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
            let cell = tableView.cellForRow(at: indexPath) as! FeedTableViewCell
            cell.contentView.backgroundColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.1)
        }
    }
    
    func tableView(_ tableView: UITableView, didUnhighlightRowAt indexPath: IndexPath) {
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) {
            let cell = tableView.cellForRow(at: indexPath) as! FeedTableViewCell
            cell.contentView.backgroundColor = UIColor.clear
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = deleteAction(at: indexPath)
        return UISwipeActionsConfiguration(actions: [delete])
    }
    
    
    func deleteAction(at indexPath: IndexPath) -> UIContextualAction {
        let action = UIContextualAction(style: .normal, title: "") { [self] (action, view, completion) in
            feedData.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .middle)
            completion(true)
        }
        action.image = UIImage(named: "bin")?.withRenderingMode(.alwaysTemplate).withTintColor(.white)
        action.backgroundColor = UIColor.red
        return action
    }
    
}
