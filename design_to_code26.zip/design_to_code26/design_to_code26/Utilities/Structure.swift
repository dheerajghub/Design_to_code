//
//  Structure.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 07/02/21.
//

import Foundation

struct FeedData {
    let title: String!
    let duration: String!
    let active: Bool!
    let thumbImage: String!
}
