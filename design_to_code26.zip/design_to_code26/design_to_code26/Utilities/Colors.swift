//
//  Colors.swift
//  design_to_code26
//
//  Created by Dheeraj Kumar Sharma on 31/01/21.
//

import UIKit

struct AppColor {
    static let backgroundColor = UIColor(red: 6/255, green: 6/255, blue: 6/255, alpha: 1)
    static let dividerView = UIColor(red: 1, green: 1, blue: 1, alpha: 0.1)
    static let textColor = UIColor(red: 1, green: 1, blue: 1, alpha: 0.8)
    static let textColor2 = UIColor(red: 1, green: 1, blue: 1, alpha: 0.4)
    static let appBlue = UIColor(red: 34/255, green: 136/255, blue: 1, alpha: 1)
    static let appYellow = UIColor(red: 1, green: 235/255, blue: 0, alpha: 1)
}
