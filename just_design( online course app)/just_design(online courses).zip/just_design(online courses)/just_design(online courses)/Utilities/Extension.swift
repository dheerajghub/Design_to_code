//
//  Extension.swift
//  just_design(online courses)
//
//  Created by Dheeraj Kumar Sharma on 11/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct Fonts{
    static let avertaExtraBold = "AvertaDemoPE-ExtraBold"
    static let avertaRegular = "AvertaDemoPECuttedDemo-Regular"
}

struct CustomColors {
    static let AppBlack:UIColor = UIColor(red: 31/255, green: 31/255, blue: 31/255, alpha: 1)
    static let AppBlue:UIColor = UIColor(red: 29/255, green: 37/255, blue: 110/255, alpha: 1)
    static let AppPurple:UIColor = UIColor(red: 98/255, green: 84/255, blue: 182/255, alpha: 1)
    static let AppOrange:UIColor = UIColor(red: 255/255, green: 127/255, blue: 45/255, alpha: 1)
    static let AppSkyBlue:UIColor = UIColor(red: 76/255, green: 177/255, blue: 255/255, alpha: 1)
    static let AppGray:UIColor = UIColor(red: 180/255, green: 180/255, blue: 180/255, alpha: 1)
    static let AppCardGray:UIColor = UIColor(red: 244/255, green: 245/255, blue: 251/255, alpha: 1)
}
