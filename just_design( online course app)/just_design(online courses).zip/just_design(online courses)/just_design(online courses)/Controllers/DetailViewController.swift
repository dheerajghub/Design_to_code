//
//  DetailViewController.swift
//  just_design(online courses)
//
//  Created by Dheeraj Kumar Sharma on 12/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    //Header View
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    
    //Fotter View
    @IBOutlet weak var dividerView: UIView!
    @IBOutlet weak var footerLabel: UILabel!
    @IBOutlet weak var moreLabel: UIButton!
    
    //Body view
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "LessonsCardCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "LessonsCardCollectionViewCell")
        self.collectionView.isHidden = true
        view.backgroundColor = CustomColors.AppBlue
        setUpNavigationBar()
        setUpViews()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setUpHeaderAnimation()
        setUpFooterAnimation()
    }
    
    override var prefersStatusBarHidden: Bool {
      return true
    }
    
    func setUpNavigationBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        
        //Nav bar Buttons
        let back = UIButton(type: .system)
        back.setImage(UIImage(named: "back")?.withRenderingMode(.alwaysOriginal), for: .normal)
        back.frame = CGRect(x: 0, y: 0, width: 30, height: 40)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: back)
        back.addTarget(self, action: #selector(backBtn), for: .touchUpInside)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = back
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
        
        
        let activity = UIButton(type: .system)
        activity.setImage(UIImage(named: "pulse")?.withRenderingMode(.alwaysOriginal), for: .normal)
        activity.frame = CGRect(x: 0, y: 0, width: 50, height: 40)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: activity)
        activity.addTarget(self, action: #selector(activityBtn), for: .touchUpInside)
        
        let rightBarButtonItem = UIBarButtonItem()
        rightBarButtonItem.customView = activity
        navigationItem.setRightBarButton(rightBarButtonItem, animated: false)
    }
    
    func setUpViews(){
        self.collectionView.backgroundColor = CustomColors.AppBlue
        titleLabel.isHidden = true
        subtitleLabel.isHidden = true
        self.dividerView.isHidden = true
        self.footerLabel.isHidden = true
        self.moreLabel.isHidden = true
        titleLabel.textColor = CustomColors.AppGray
        subtitleLabel.textColor = .white
        footerLabel.textColor = CustomColors.AppGray
    }
    
    func setUpHeaderAnimation(){
        UIView.animate(withDuration: 0.1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.titleLabel.center.y += 50
            self.subtitleLabel.center.y += 100
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0.02, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.titleLabel.isHidden = false
                self.subtitleLabel.isHidden = false
                self.titleLabel.alpha = 1
                self.subtitleLabel.alpha = 1
                self.titleLabel.center.y -= 50
                self.subtitleLabel.center.y -= 100
            })
        })
    }
    
    func setUpFooterAnimation(){
        UIView.animate(withDuration: 0.1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.dividerView.alpha = 0
            self.footerLabel.alpha = 0
            self.moreLabel.alpha = 0
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0.02, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.dividerView.isHidden = false
                self.footerLabel.isHidden = false
                self.moreLabel.isHidden = false
                self.dividerView.alpha = 1
                self.footerLabel.alpha = 1
                self.moreLabel.alpha = 1
            })
        })
    }
    
    @objc func backBtn(){
        navigationController?.popViewController(animated: true)
    }
    
    @objc func activityBtn(){
        
    }
}

extension DetailViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LessonsCardCollectionViewCell", for: indexPath) as! LessonsCardCollectionViewCell
        
        UIView.animate(withDuration: 0.1, delay: 0.5, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            cell.cardView.transform = .init(scaleX: 1.3, y: 1.3)
            cell.startLessonBtn.transform = .init(scaleX: 0.3, y: 0.3)
            cell.cardView.layer.cornerRadius = 0
            cell.cardView.alpha = 0
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0.02, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.collectionView.isHidden = false
                cell.cardView.transform = .identity
                cell.startLessonBtn.transform = .identity
                cell.cardView.alpha = 1
            })
        })
        
        UIView.animate(withDuration: 2, delay: 0.5, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            cell.cardView.layer.cornerRadius = 20
        } ,completion:{ _ in
        })
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        collectionView.contentInset = UIEdgeInsets(top: 40, left: 20, bottom: 40, right: 20)
        return CGSize(width: self.collectionView.frame.width - 40, height: 500)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
