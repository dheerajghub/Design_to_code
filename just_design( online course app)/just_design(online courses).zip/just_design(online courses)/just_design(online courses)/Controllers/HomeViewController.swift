//
//  HomeViewController.swift
//  just_design(online courses)
//
//  Created by Dheeraj Kumar Sharma on 11/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    /// Remember viewer, this is not the actual structure how app model work this is only for design , And you will learn how the stack views works how you can play with animations , enjoy exploring.
    
    //Header View
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel:UILabel!
    @IBOutlet weak var progressView: UIProgressView!
    
    //Card1
    @IBOutlet weak var cardOneView: UIView!
    @IBOutlet weak var cardOneSubTitle: UILabel!
    @IBOutlet weak var cardOneTitle: UILabel!
    @IBOutlet weak var cardOneImage: UIImageView!
    
    //Card2
    @IBOutlet weak var cardTwoView: UIView!
    @IBOutlet weak var cardTwoSubTitle: UILabel!
    @IBOutlet weak var cardTwoDes: UILabel!
    @IBOutlet weak var cardTwoTitle: UILabel!
    @IBOutlet weak var cardTwoImage: UIImageView!
    
    //card3
    @IBOutlet weak var cardThreeView: UIView!
    @IBOutlet weak var cardThreeTitle: UILabel!
    @IBOutlet weak var cardThreeImage: UIImageView!
    
    //card4
    @IBOutlet weak var cardFourView: UIView!
    @IBOutlet weak var cardFourTitle: UILabel!
    @IBOutlet weak var cardFourSubtitle: UILabel!
    
    @IBOutlet weak var tabBtn1: UIImageView!
    @IBOutlet weak var tabBtn2: UIImageView!
    @IBOutlet weak var tabBtn3: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigationBar()
        setUpViews()
    }
    
    override var prefersStatusBarHidden: Bool {
      return true
    } 
    
    override func viewWillAppear(_ animated: Bool) {
        setUpViews()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        setUpHeaderAnimation()
        setUpBodyAnimation()
    }
    
    func setUpNavigationBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        
        //Nav bar Buttons
        let menu = UIButton(type: .system)
        menu.setImage(UIImage(named: "menu")?.withRenderingMode(.alwaysOriginal), for: .normal)
        menu.frame = CGRect(x: 0, y: 0, width: 50, height: 40)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: menu)
        menu.addTarget(self, action: #selector(menuBtn), for: .touchUpInside)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = menu
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
        
        
        let search = UIButton(type: .system)
        search.setImage(UIImage(named: "search")?.withRenderingMode(.alwaysOriginal), for: .normal)
        search.frame = CGRect(x: 0, y: 0, width: 50, height: 40)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: search)
        search.addTarget(self, action: #selector(searchBtn), for: .touchUpInside)
        
        let rightBarButtonItem = UIBarButtonItem()
        rightBarButtonItem.customView = search
        navigationItem.setRightBarButton(rightBarButtonItem, animated: false)
    }
    
    func setUpViews(){
        
        //Header
        userImage.layer.cornerRadius = 20
        titleLabel.font = UIFont(name: Fonts.avertaExtraBold, size: 30)
        subtitleLabel.font = UIFont(name: Fonts.avertaRegular, size: 14)
        titleLabel.text = "Your \nCourses"
        subtitleLabel.text = "Overall progress"
        titleLabel.textColor = CustomColors.AppBlack
        subtitleLabel.textColor = CustomColors.AppGray
        self.titleLabel.isHidden = true
        self.subtitleLabel.isHidden = true
        self.userImage.isHidden = true
        self.tabBtn1.isHidden = true
        self.tabBtn2.isHidden = true
        self.tabBtn3.isHidden = true
        self.progressView.isHidden = true
        
        //Card1
        cardOneView.isHidden = true
        cardOneView.layer.cornerRadius = 20
        cardOneView.backgroundColor = CustomColors.AppSkyBlue
        cardOneTitle.textColor = .white
        cardOneSubTitle.textColor = .white
        cardOneImage.layer.cornerRadius = 10
        
        //Card2
        cardTwoView.isHidden = true
        cardTwoView.layer.cornerRadius = 20
        cardTwoView.backgroundColor = CustomColors.AppCardGray
        cardTwoTitle.textColor = CustomColors.AppBlack
        cardTwoSubTitle.textColor = CustomColors.AppGray
        cardTwoDes.textColor = CustomColors.AppGray
        cardTwoImage.layer.cornerRadius = 10
        
        //Card3
        cardThreeView.isHidden = true
        cardThreeView.backgroundColor = CustomColors.AppCardGray
        cardThreeView.layer.masksToBounds = true
        cardThreeView.layer.cornerRadius = 20
        cardThreeTitle.textColor = CustomColors.AppBlack
        
        //Card4
        cardFourView.isHidden = true
        cardFourView.layer.cornerRadius = 20
        cardFourView.backgroundColor = CustomColors.AppCardGray
        cardFourTitle.textColor = CustomColors.AppBlack
        cardFourSubtitle.textColor = CustomColors.AppGray
        
    }
    
    func setUpHeaderAnimation(){
        UIView.animate(withDuration: 0.1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.titleLabel.center.y += 100
            self.subtitleLabel.center.y += 100
            self.titleLabel.alpha = 0
            self.subtitleLabel.alpha = 0
            self.userImage.transform = .init(scaleX: 0.3, y: 0.3)
        } ,completion:{ _ in
            UIView.animate(withDuration: 0.8, delay: 0.02, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.titleLabel.isHidden = false
                self.subtitleLabel.isHidden = false
                self.userImage.isHidden = false
                self.titleLabel.alpha = 1
                self.subtitleLabel.alpha = 1
                self.titleLabel.center.y -= 100
                self.subtitleLabel.center.y -= 100
                self.userImage.transform = .identity
            })
        })
        
        UIView.animate(withDuration: 0.4, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.progressView.setProgress(0.1, animated: true)
        } ,completion:{ _ in
            UIView.animate(withDuration: 3, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.progressView.isHidden = false
                self.progressView.setProgress(0.7, animated: true)
            })
        })
    }
    
    func setUpBodyAnimation(){
        
        //Card1
        UIView.animate(withDuration: 0.4, delay: 0.1, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.cardOneView.center.y += 100
            self.cardOneImage.transform = .init(scaleX: 0.3, y: 0.3)
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.cardOneView.isHidden = false
                self.cardOneView.center.y -= 100
                self.cardOneImage.transform = .identity
            })
        })
        
        //Card2
        UIView.animate(withDuration: 0.4, delay: 0.2, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.cardTwoView.center.y += 100
            self.cardTwoImage.transform = .init(scaleX: 0.3, y: 0.3)
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.cardTwoView.isHidden = false
                self.cardTwoView.center.y -= 100
                self.cardTwoImage.transform = .identity
            })
        })
        
        //Card3
        UIView.animate(withDuration: 0.4, delay: 0.3, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.cardThreeView.center.y += 100
            self.cardThreeImage.center.y += 150
            self.cardThreeImage.transform = .init(scaleX: 0.5, y: 0.5)
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.cardThreeView.isHidden = false
                self.cardThreeView.center.y -= 100
                self.cardThreeImage.center.y -= 150
                self.cardThreeImage.transform = .identity
            })
        })
        
        //Card4
        UIView.animate(withDuration: 0.4, delay: 0.4, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.cardFourView.center.y += 100
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.cardFourView.isHidden = false
                self.cardFourView.center.y -= 100
            })
        })
        
        UIView.animate(withDuration: 0.4, delay: 0.4, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.tabBtn1.transform = .init(scaleX: 0.3, y: 0.3)
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.tabBtn1.isHidden = false
                self.tabBtn1.transform = .identity
            })
        })
        
        UIView.animate(withDuration: 0.4, delay: 0.4, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.tabBtn2.transform = .init(scaleX: 0.3, y: 0.3)
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.tabBtn2.isHidden = false
                self.tabBtn2.transform = .identity
            })
        })
        
        UIView.animate(withDuration: 0.4, delay: 0.4, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.tabBtn3.transform = .init(scaleX: 0.3, y: 0.3)
        } ,completion:{ _ in
            UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                self.tabBtn3.isHidden = false
                self.tabBtn3.transform = .identity
            })
        })
        
    }
    
    @objc func menuBtn(){
        
    }
    
    @objc func searchBtn(){
        
    }
    
    @IBAction func nextViewBtnPressed(_ sender: Any) {
        performSegue(withIdentifier: "detail", sender: self)
    }
    
}
