//
//  LessonsCardCollectionViewCell.swift
//  just_design(online courses)
//
//  Created by Dheeraj Kumar Sharma on 12/04/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class LessonsCardCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var cardView:UIView!
    @IBOutlet weak var cardImage:UIView!
    @IBOutlet weak var cardTitle:UILabel!
    @IBOutlet weak var cardSubtitle:UILabel!
    @IBOutlet weak var startLessonBtn:UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        cardView.layer.cornerRadius = 20
        cardView.layer.masksToBounds = true
        cardTitle.text = "Document structure"
        cardSubtitle.text = "Let's prepare the layout out of the blog page. How do tags work?"
        startLessonBtn.layer.cornerRadius = startLessonBtn.frame.height / 2
        startLessonBtn.backgroundColor = CustomColors.AppOrange
        startLessonBtn.setTitle("Start Lesson", for: .normal)
        startLessonBtn.setTitleColor(.white, for: .normal)
        startLessonBtn.titleLabel?.font = UIFont(name: Fonts.avertaRegular, size: 15)
        cardSubtitle.font = UIFont(name: Fonts.avertaRegular, size: 15)
        cardSubtitle.textColor = CustomColors.AppGray
    }

}
