//
//  structure.swift
//  design_to_code14
//
//  Created by Dheeraj Kumar Sharma on 20/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import Foundation

struct MessageList{
    let userName:String!
    let lastMessage:String!
    let userImage:String!
    let date:String!
    let pending:Bool!
    let pendingCount:String!
}

struct Messages{
    var messageType:String!
    var sentBy:String!
    var time:String!
    var image:String!
    var message:String!
    var isIncoming:Bool!
}
