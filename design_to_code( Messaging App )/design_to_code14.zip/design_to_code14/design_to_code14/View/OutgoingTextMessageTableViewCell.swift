//
//  OutgoingTextMessageTableViewCell.swift
//  design_to_code14
//
//  Created by Dheeraj Kumar Sharma on 20/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class OutgoingTextMessageTableViewCell: UITableViewCell {

    var data:Messages?{
        didSet{
            manageData()
        }
    }
    
    let bubbleview:UIView = {
        let bv = UIView()
        bv.translatesAutoresizingMaskIntoConstraints = false
        bv.backgroundColor = CustomColor.appPurple
        bv.layer.cornerRadius = 20
        bv.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMinXMinYCorner , .layerMaxXMinYCorner]
        return bv
    }()
    
    let messageTextLabel:UILabel = {
        let l = UILabel()
        l.text = "The Heavy text is awesone.."
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .white
        l.font = UIFont(name: CustomFont.poppinsSemiBold, size: 14)
        return l
    }()
    
    let messageDetail:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
            addSubview(bubbleview)
            bubbleview.addSubview(messageTextLabel)
            addSubview(messageDetail)
            setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            bubbleview.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            bubbleview.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            bubbleview.bottomAnchor.constraint(equalTo: messageDetail.topAnchor, constant: -5),
            bubbleview.widthAnchor.constraint(lessThanOrEqualToConstant: 250),
            
            messageTextLabel.leadingAnchor.constraint(equalTo: bubbleview.leadingAnchor, constant: 15),
            messageTextLabel.topAnchor.constraint(equalTo: bubbleview.topAnchor, constant: 15),
            messageTextLabel.bottomAnchor.constraint(equalTo: bubbleview.bottomAnchor, constant: -15),
            messageTextLabel.trailingAnchor.constraint(equalTo: bubbleview.trailingAnchor, constant: -15),
            
            messageDetail.topAnchor.constraint(equalTo: bubbleview.bottomAnchor, constant: 5),
            messageDetail.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            messageDetail.heightAnchor.constraint(equalToConstant: 14),
            messageDetail.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -5)
        ])
    }
    
    func setMessageDetailAttributedText(){
        guard let data = data else {return}
        let attributedText = NSMutableAttributedString(string:"\(data.time ?? "")" , attributes:[NSAttributedString.Key.font: UIFont(name:CustomFont.poppinsMedium, size: 12)!,NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        messageDetail.attributedText = attributedText
    }
    
    func manageData(){
        guard let data = data else {return}
        messageTextLabel.text = data.message
        setMessageDetailAttributedText()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
