//
//  MessageImageTableViewCell.swift
//  design_to_code14
//
//  Created by Dheeraj Kumar Sharma on 20/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class MessageImageTableViewCell: UITableViewCell {

    let bubbleImageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "prof-img2")
        img.clipsToBounds = true
        img.layer.cornerRadius = 20
        img.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMinXMinYCorner , .layerMaxXMinYCorner]
        return img
    }()
    
    let messageDetail:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
            addSubview(bubbleImageView)
            addSubview(messageDetail)
            setMessageDetailAttributedText()
            setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            bubbleImageView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            bubbleImageView.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            bubbleImageView.bottomAnchor.constraint(equalTo: messageDetail.topAnchor, constant: -5),
            bubbleImageView.widthAnchor.constraint(equalToConstant: 250),
            messageDetail.topAnchor.constraint(equalTo: bubbleImageView.bottomAnchor, constant: 5),
            messageDetail.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            messageDetail.heightAnchor.constraint(equalToConstant: 14),
            messageDetail.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -5)
        ])
    }
    
    func setMessageDetailAttributedText(){
        let attributedText = NSMutableAttributedString(string:"10/08/2020" , attributes:[NSAttributedString.Key.font: UIFont(name:CustomFont.poppinsMedium, size: 12)!,NSAttributedString.Key.foregroundColor: UIColor.lightGray])
        messageDetail.attributedText = attributedText
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
