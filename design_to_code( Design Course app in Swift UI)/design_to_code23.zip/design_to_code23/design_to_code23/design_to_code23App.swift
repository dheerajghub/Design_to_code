//
//  design_to_code23App.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 22/11/20.
//

import SwiftUI

@main
struct design_to_code23App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
