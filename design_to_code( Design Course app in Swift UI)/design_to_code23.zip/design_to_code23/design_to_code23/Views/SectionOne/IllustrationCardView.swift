//
//  IllustrationCardView.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 22/11/20.
//

import SwiftUI

struct IllustrationCardView: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack {
                cardView(image:"demo1")
                cardView(image:"demo2")
                cardView(image:"demo3")
            }
            .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
        }
        
    }
}

struct IllustrationCardView_Previews: PreviewProvider {
    static var previews: some View {
        IllustrationCardView()
    }
}

struct cardView: View {
    
    let image:String
    
    var body: some View {
        Image(image)
            .resizable()
            .scaledToFill()
            .frame(width: 340, height: 200, alignment: .center)
            .cornerRadius(20)
    }
}
