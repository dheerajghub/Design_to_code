//
//  SectionOne.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 22/11/20.
//

import SwiftUI

struct SectionOne: View {
    var body: some View {
        VStack{
            HStack {
                Text("Illustration of the week")
                    .font(Font.custom("Avenir-Black", size: 18))
                Spacer()
                Text("See All")
                    .font(Font.custom("Avenir-Medium", size: 16))
                    .foregroundColor(.gray)
            }
            .padding(EdgeInsets(top: 10, leading: 20, bottom: 10, trailing: 20))
            IllustrationCardView()
        }
        .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
        
    }
}

struct SectionOne_Previews: PreviewProvider {
    static var previews: some View {
        SectionOne()
    }
}
