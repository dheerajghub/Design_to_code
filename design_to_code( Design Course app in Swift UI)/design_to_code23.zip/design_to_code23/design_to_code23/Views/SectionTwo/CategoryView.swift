//
//  CategoryView.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 23/11/20.
//

import SwiftUI

struct CategoryView: View {
    var body: some View {
        ScrollView(.horizontal, showsIndicators:false){
            HStack {
                cardCategoryView(image: "img1", title: "3D Illustration Course", author: "Leo Natsume")
                cardCategoryView(image: "img2", title: "3D Illustration Course", author: "Anna Kadja")
                cardCategoryView(image: "img3", title: "3D Illustration Course", author: "Arek Kadja")
                cardCategoryView(image: "img4", title: "3D Illustration Course", author: "Roman Klco")
            }
            .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 10))
        }
    }
}

struct CategoryView_Previews: PreviewProvider {
    static var previews: some View {
        CategoryView()
    }
}


struct cardCategoryView: View {
    
    let image:String
    let title:String
    let author:String
    
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Image(image)
                .resizable()
                .scaledToFill()
                .frame(width: 250, height: 270, alignment: .center)
                .cornerRadius(20)
                .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 10))
            VStack(alignment: .leading) {
                Text(title)
                    .font(Font.custom("Avenir-Black", size: 26))
                    .foregroundColor(.white)
                    .frame(width: 250, height: 90, alignment: .leading)
                    .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: -20))
                Text("By \(author)")
                    .font(Font.custom("Avenir", size: 18))
                    .padding(EdgeInsets(top: 0, leading: 20, bottom: 20, trailing: 20))
                    .foregroundColor(.white)
            }
            .background(LinearGradient(gradient: Gradient(colors: [.clear, .black]), startPoint: .top, endPoint: .bottom))
            .cornerRadius(20)
        }
    }
}
