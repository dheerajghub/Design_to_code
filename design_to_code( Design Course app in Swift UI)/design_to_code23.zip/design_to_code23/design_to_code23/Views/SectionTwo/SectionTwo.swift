//
//  SectionTwo.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 23/11/20.
//

import SwiftUI

struct SectionTwo: View {
    var body: some View {
        VStack{
            HStack {
                Text("3D Illustrations")
                    .font(Font.custom("Avenir-Black", size: 18))
                Spacer()
            }
            .padding(EdgeInsets(top: 10, leading: 20, bottom: 10, trailing: 20))
            CategoryView()
        }
        .padding(EdgeInsets(top: 10, leading: 0, bottom: 10, trailing: 0))
    }
}

struct SectionTwo_Previews: PreviewProvider {
    static var previews: some View {
        SectionTwo()
    }
}
