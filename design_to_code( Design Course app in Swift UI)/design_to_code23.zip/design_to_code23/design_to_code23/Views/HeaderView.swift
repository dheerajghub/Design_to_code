//
//  HeaderView.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 22/11/20.
//

import SwiftUI

struct HeaderView: View {
    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text("Welcome")
                    .foregroundColor(.gray)
                    .font(Font.custom("Avenir", size: 17))
                Text("Dheeraj.iosdev")
                    .font(Font.custom("Avenir-Black", size: 20))
            }
            Spacer()
            Image("demo")
                .resizable()
                .frame(width: 50, height: 50, alignment: .center)
                .cornerRadius(25)
        }.padding(EdgeInsets(top: 10, leading: 20, bottom: 10, trailing: 20))
    }
}

struct HeaderView_Previews: PreviewProvider {
    static var previews: some View {
        HeaderView()
    }
}
