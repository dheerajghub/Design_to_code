//
//  ContentView.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 22/11/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                HeaderView()
                SearchBarView()
                    .padding(EdgeInsets(top: 5, leading: 20, bottom: 5, trailing: 20))
                SectionOne()
                SectionTwo()
                Spacer()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
