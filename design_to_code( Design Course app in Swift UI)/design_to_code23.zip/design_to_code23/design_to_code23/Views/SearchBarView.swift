//
//  SearchBarView.swift
//  design_to_code23
//
//  Created by Dheeraj Kumar Sharma on 22/11/20.
//

import SwiftUI

struct SearchBarView: View {
    var body: some View {
        HStack {
            Image("Search")
                .resizable()
                .renderingMode(.template)
                .foregroundColor(Color(red: 31/255, green: 31/255, blue: 31/255))
                .frame(width: 24, height: 24, alignment: .center)
                
                
            Text("Search for design courses")
                .font(Font.custom("Avenir-Medium", size: 17))
                .foregroundColor(Color(red: 120/255, green: 120/255, blue: 120/255))
            Spacer()
            Image("Microphone")
                .resizable()
                .renderingMode(.template)
                .foregroundColor(Color(red: 31/255, green: 31/255, blue: 31/255))
                .frame(width: 24, height: 24, alignment: .center)
        }
        .padding(EdgeInsets(top: 18, leading: 20, bottom: 18, trailing: 20))
        .background(Color(red: 248/255, green: 248/255, blue: 248/255))
        .cornerRadius(10)
    }
}

struct SearchBarView_Previews: PreviewProvider {
    static var previews: some View {
        SearchBarView()
    }
}
