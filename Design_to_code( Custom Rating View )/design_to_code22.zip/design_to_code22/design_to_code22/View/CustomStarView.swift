//
//  CustomStarView.swift
//  design_to_code22
//
//  Created by Dheeraj Kumar Sharma on 14/11/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomStarView: UIView {
    
    let starImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(starImage)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            starImage.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 6),
            starImage.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -6),
            starImage.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -6),
            starImage.topAnchor.constraint(equalTo: topAnchor, constant: 6)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
