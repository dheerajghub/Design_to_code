//
//  CustomCourseCard.swift
//  design_to_code22
//
//  Created by Dheeraj Kumar Sharma on 14/11/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomCourseCard: UIView {

    var delegate:ViewController?{
        didSet{
            ratingBtn.addTarget(delegate, action: #selector(ViewController.ratingBtnPressed), for: .touchUpInside)
        }
    }
    
    let projectPreviewImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.clipsToBounds = true
        img.image = UIImage(named: "poster")
        img.layer.cornerRadius = 10
        img.layer.maskedCorners = [.layerMinXMinYCorner , .layerMaxXMinYCorner]
        return img
    }()
    
    let title:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .black
        l.font = UIFont(name: "Avenir-Black", size: 18)
        l.text = "Coolors - Utility app for designers"
        l.numberOfLines = 0
        return l
    }()
    
    lazy var ratingBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setAttributedTitle(setAttributes(withTitle: "5.0(12)", withImage: UIImage(named: "star"), withTextColor:.lightGray), for: .normal)
        return btn
    }()
    
    lazy var buyBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setAttributedTitle(setAttributes(withTitle: "Buy", withImage: UIImage(named: "shop"), withTextColor:.white, withImageSize: 18, withFont: UIFont(name: "Avenir-Black", size: 17)!), for: .normal)
        btn.backgroundColor = UIColor(red: 108/255, green: 163/255, blue: 42/255, alpha: 1)
        btn.layer.cornerRadius = 5
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        addSubview(projectPreviewImage)
        addSubview(title)
        addSubview(ratingBtn)
        addSubview(buyBtn)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            projectPreviewImage.leadingAnchor.constraint(equalTo: leadingAnchor),
            projectPreviewImage.topAnchor.constraint(equalTo: topAnchor),
            projectPreviewImage.trailingAnchor.constraint(equalTo: trailingAnchor),
            projectPreviewImage.heightAnchor.constraint(equalToConstant: 200),
            title.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
            title.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            title.topAnchor.constraint(equalTo: projectPreviewImage.bottomAnchor, constant: 10),
            
            ratingBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -15),
            ratingBtn.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -15),
            ratingBtn.heightAnchor.constraint(equalToConstant: 35),
            
            buyBtn.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
            buyBtn.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -15),
            buyBtn.widthAnchor.constraint(equalToConstant: 80),
            buyBtn.heightAnchor.constraint(equalToConstant: 35)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func setAttributes( withTitle title:String, withImage image:UIImage? , withTextColor textColor:UIColor , withImageSize size:CGFloat = 15, withFont font:UIFont = UIFont(name: "Avenir-Black", size: 15)!) -> NSAttributedString {
        
        let attributedText = NSMutableAttributedString(string:"")
        
        if let image = image {
            let font = font
            let img = image.withRenderingMode(.alwaysOriginal)
            let image = NSTextAttachment()
            image.image = img
            image.bounds = CGRect(x: 0, y: (font.capHeight - size).rounded() / 2, width: size, height: size)
            image.setImageHeight(height: size)
            let imgString = NSAttributedString(attachment: image)
            attributedText.append(imgString)
            
            if title != "" {
                attributedText.append(NSAttributedString(string: " "))
            }
        }
        
        attributedText.append(NSAttributedString(string: "\(title)" , attributes:[NSAttributedString.Key.font:font , NSAttributedString.Key.foregroundColor:textColor]))
        
        return attributedText
    }

}
