//
//  ViewController.swift
//  design_to_code22
//
//  Created by Dheeraj Kumar Sharma on 14/11/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    lazy var customCard:CustomCourseCard = {
        let v = CustomCourseCard()
        v.delegate = self
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.cornerRadius = 10
        v.layer.shadowColor = UIColor(white: 0, alpha: 0.1).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 3)
        v.layer.shadowRadius = 10
        v.layer.shadowOpacity = 1
        return v
    }()
    
    let overlayView:UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0, alpha: 0.5)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let star1 = CustomStarView()
    let star2 = CustomStarView()
    let star3 = CustomStarView()
    let star4 = CustomStarView()
    let star5 = CustomStarView()
    
    lazy var ratingContainerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        
        star1.starImage.image = UIImage(named: "empty")
        star2.starImage.image = UIImage(named: "empty")
        star3.starImage.image = UIImage(named: "empty")
        star4.starImage.image = UIImage(named: "empty")
        star5.starImage.image = UIImage(named: "empty")
        
        let arrangedSubViews = [star1 , star2 , star3 , star4 , star5]
        
        //Configuration constant setting
        let padding:CGFloat = 8
        let iconHeight:CGFloat = 55
        
        let stackView = UIStackView(arrangedSubviews: arrangedSubViews)
        stackView.distribution = .fillEqually
        
        stackView.spacing = padding
        stackView.layoutMargins = UIEdgeInsets(top: padding, left: padding + 5, bottom: padding, right: padding + 5)
        stackView.isLayoutMarginsRelativeArrangement = true
        
        v.addSubview(stackView)
        
        let numStars = CGFloat(arrangedSubViews.count)
        let width = numStars * iconHeight + (numStars + 1) * padding
        let height = iconHeight + 2 * padding
        
        v.frame = CGRect(x: 0, y: 0, width: width, height: height)
        stackView.frame = v.frame
        v.layer.cornerRadius = height / 2
        
        v.layer.shadowColor = UIColor(white: 0, alpha: 0.1).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 3)
        v.layer.shadowRadius = 10
        v.layer.shadowOpacity = 1
        
        return v
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1)
        view.addSubview(customCard)
        view.addSubview(overlayView)
        overlayView.isHidden = true
        overlayView.alpha = 0
        setUpConstraints()
    }

    func setUpConstraints(){
        NSLayoutConstraint.activate([
            customCard.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            customCard.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            customCard.widthAnchor.constraint(equalToConstant: 300),
            customCard.heightAnchor.constraint(equalToConstant: 330),
            
            overlayView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlayView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            overlayView.topAnchor.constraint(equalTo: view.topAnchor),
            overlayView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    @objc func ratingBtnPressed(){
        view.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(hangeLongPress)))
    }
    
    @objc func hangeLongPress(gesture: UILongPressGestureRecognizer){
        
        if gesture.state == .began {
            handleGestureBegan(gesture: gesture)
        } else if gesture.state == .ended {
            handleGestureEnded(gesture: gesture)
        } else if gesture.state == .changed {
            handleGestureChanges(gesture:gesture)
        }
        
    }
    
    func handleGestureBegan(gesture: UILongPressGestureRecognizer){
        view.addSubview(ratingContainerView)
        let centerX = (view.frame.width - ratingContainerView.frame.width) / 2
        let location = gesture.location(in: self.view)
        
        ratingContainerView.transform = CGAffineTransform(translationX: centerX, y: location.y)
        
        ratingContainerView.alpha = 0
        overlayView.isHidden = false
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.7, options: .curveEaseIn, animations: {
            self.ratingContainerView.alpha = 1
            self.ratingContainerView.transform = CGAffineTransform(translationX: centerX, y: location.y - self.ratingContainerView.frame.height)
            self.overlayView.alpha = 1
        }, completion: nil)
    }
    
    func handleGestureEnded(gesture: UILongPressGestureRecognizer){
        let centerX = (view.frame.width - ratingContainerView.frame.width) / 2
        let location = gesture.location(in: self.view)
        
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.7, options: .curveEaseIn, animations: {
            self.ratingContainerView.alpha = 0
            self.ratingContainerView.transform = CGAffineTransform(translationX: centerX, y: location.y)
            let stackView = self.ratingContainerView.subviews.first
            stackView?.subviews.forEach({ (CustomStarView) in
                CustomStarView.transform = .identity
            })
            self.overlayView.alpha = 0
        }, completion: { finished in
            self.ratingContainerView.removeFromSuperview()
            self.overlayView.isHidden = true
        })
    }
    
    func handleGestureChanges(gesture: UILongPressGestureRecognizer){
        let pressedLocation = gesture.location(in: self.ratingContainerView)
        let hitTestView = ratingContainerView.hitTest(pressedLocation, with: nil)
        if hitTestView is CustomStarView {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 0.7, options: .curveEaseIn, animations: {
                
                let stackView = self.ratingContainerView.subviews.first
                stackView?.subviews.forEach({ (CustomStarView) in
                    CustomStarView.transform = .identity
                })
                if hitTestView == self.star1 {
                    self.addRatingAnimation(self.star1)
                }
                else if hitTestView == self.star2 {
                    self.addRatingAnimation(self.star2)
                }
                else if hitTestView == self.star3 {
                    self.addRatingAnimation(self.star3)
                }
                else if hitTestView == self.star4 {
                    self.addRatingAnimation(self.star4)
                }
                else if hitTestView == self.star5 {
                    self.addRatingAnimation(self.star5)
                }
                
            }, completion: nil)
        }
    }
    
    func addRatingAnimation(_ v:CustomStarView){
        if v == star1{
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn, animations: {
                self.star1.starImage.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            }, completion: { finished in
                self.star1.starImage.transform = .identity
            })
            
            self.star1.starImage.image = UIImage(named: "angry")
            self.star2.starImage.image = UIImage(named: "empty")
            self.star3.starImage.image = UIImage(named: "empty")
            self.star4.starImage.image = UIImage(named: "empty")
            self.star5.starImage.image = UIImage(named: "empty")
        }
        if v == star2{
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn, animations: {
                self.star2.starImage.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            }, completion: { finished in
                self.star2.starImage.transform = .identity
            })
            
            self.star1.starImage.image = UIImage(named: "sad")
            self.star2.starImage.image = UIImage(named: "sad")
            self.star3.starImage.image = UIImage(named: "empty")
            self.star4.starImage.image = UIImage(named: "empty")
            self.star5.starImage.image = UIImage(named: "empty")
        }
        if v == star3{
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn, animations: {
                self.star3.starImage.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            }, completion: { finished in
                self.star3.starImage.transform = .identity
            })
            
            self.star1.starImage.image = UIImage(named: "neutral")
            self.star2.starImage.image = UIImage(named: "neutral")
            self.star3.starImage.image = UIImage(named: "neutral")
            self.star4.starImage.image = UIImage(named: "empty")
            self.star5.starImage.image = UIImage(named: "empty")
        }
        if v == star4{
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn, animations: {
                self.star4.starImage.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            }, completion: { finished in
                self.star4.starImage.transform = .identity
            })
            
            self.star1.starImage.image = UIImage(named: "smile")
            self.star2.starImage.image = UIImage(named: "smile")
            self.star3.starImage.image = UIImage(named: "smile")
            self.star4.starImage.image = UIImage(named: "smile")
            self.star5.starImage.image = UIImage(named: "empty")
        }
        if v == star5{
            UIView.animate(withDuration: 0.2, delay: 0, options: .curveEaseIn, animations: {
                self.star5.starImage.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            }, completion: { finished in
                self.star5.starImage.transform = .identity
            })
            
            self.star1.starImage.image = UIImage(named: "happy")
            self.star2.starImage.image = UIImage(named: "happy")
            self.star3.starImage.image = UIImage(named: "happy")
            self.star4.starImage.image = UIImage(named: "happy")
            self.star5.starImage.image = UIImage(named: "happy")
        }
    }

}

