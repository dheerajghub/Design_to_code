//
//  NewSongCollectionViewCell.swift
//  designToCode9
//
//  Created by Dheeraj Kumar Sharma on 01/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class NewSongCollectionViewCell: UICollectionViewCell {
    
    let artistImage:UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named:"img1")
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.cornerRadius = 30
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(artistImage)
        artistImage.pin(to: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
