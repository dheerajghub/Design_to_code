//
//  BottomMusicBar.swift
//  designToCode9
//
//  Created by Dheeraj Kumar Sharma on 01/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class BottomMusicBar: UIView {
    
    let overView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let songImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.layer.cornerRadius = 25
        img.image = UIImage(named: "img2")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let songDetails:UILabel = {
        let l = UILabel()
        l.textColor = .white
        l.numberOfLines = 0
        let attributedText = NSMutableAttributedString(string:"idk\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Black", size: 17)!])
        attributedText.append(NSAttributedString(string: "let you" , attributes:
            [NSAttributedString.Key.font: UIFont(name:"Avenir", size: 15)!, NSAttributedString.Key.foregroundColor: UIColor.lightGray]))
        l.attributedText = attributedText
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let stackView:UIStackView = {
        let v = UIStackView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.axis = .horizontal
        v.spacing = 0
        v.distribution = .fillEqually
        return v
    }()
    
    let playView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let playImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFit
        img.clipsToBounds = true
        img.image = UIImage(systemName: "pause")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let forwardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let forwardImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFit
        img.clipsToBounds = true
        img.image = UIImage(systemName: "forward")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let startTimer:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "01:20"
        l.textColor = .lightGray
        l.font = UIFont(name: "Avenir-Heavy", size: 12)
        return l
    }()
    
    let endTimer:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "03:45"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Heavy", size: 12)
        l.textAlignment = .right
        return l
    }()
    
    let progressView:UIProgressView = {
        let pv = UIProgressView()
        pv.translatesAutoresizingMaskIntoConstraints = false
        pv.progressTintColor = .white
        pv.trackTintColor = CustomColors.appBackDark
        pv.setProgress(0.5, animated: false)
        return pv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(overView)
        overView.addSubview(songImage)
        overView.addSubview(songDetails)
        overView.addSubview(stackView)
        stackView.addArrangedSubview(playView)
        stackView.addArrangedSubview(forwardView)
        playView.addSubview(playImage)
        forwardView.addSubview(forwardImage)
        overView.addSubview(startTimer)
        overView.addSubview(endTimer)
        overView.addSubview(progressView)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            overView.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor),
            overView.leadingAnchor.constraint(equalTo: leadingAnchor),
            overView.trailingAnchor.constraint(equalTo: trailingAnchor),
            overView.topAnchor.constraint(equalTo: topAnchor),
            
            songImage.topAnchor.constraint(equalTo: overView.topAnchor, constant: 20),
            songImage.leadingAnchor.constraint(equalTo: overView.leadingAnchor, constant: 25),
            songImage.widthAnchor.constraint(equalToConstant: 50),
            songImage.heightAnchor.constraint(equalToConstant: 50),
            
            songDetails.topAnchor.constraint(equalTo: overView.topAnchor, constant: 22),
            songDetails.leadingAnchor.constraint(equalTo: songImage.trailingAnchor, constant: 15),
            
            stackView.trailingAnchor.constraint(equalTo: overView.trailingAnchor, constant: -15),
            stackView.topAnchor.constraint(equalTo: overView.topAnchor, constant: 20),
            stackView.heightAnchor.constraint(equalToConstant: 50),
            stackView.widthAnchor.constraint(equalToConstant: 100),
            
            forwardImage.centerYAnchor.constraint(equalTo: forwardView.centerYAnchor),
            forwardImage.centerXAnchor.constraint(equalTo: forwardView.centerXAnchor),
            forwardImage.widthAnchor.constraint(equalToConstant: 30),
            forwardImage.heightAnchor.constraint(equalToConstant: 30),
            
            playImage.centerYAnchor.constraint(equalTo: playView.centerYAnchor),
            playImage.centerXAnchor.constraint(equalTo: playView.centerXAnchor),
            playImage.widthAnchor.constraint(equalToConstant: 35),
            playImage.heightAnchor.constraint(equalToConstant: 35),
            
            startTimer.leadingAnchor.constraint(equalTo: overView.leadingAnchor, constant: 28),
            startTimer.topAnchor.constraint(equalTo: songImage.bottomAnchor, constant: 7),
            startTimer.widthAnchor.constraint(equalToConstant: 40),
            
            endTimer.trailingAnchor.constraint(equalTo: overView.trailingAnchor, constant: -25),
            endTimer.topAnchor.constraint(equalTo: songImage.bottomAnchor, constant: 7),
            endTimer.widthAnchor.constraint(equalToConstant: 40),
            
            progressView.topAnchor.constraint(equalTo: songImage.bottomAnchor, constant: 15),
            progressView.leadingAnchor.constraint(equalTo: startTimer.trailingAnchor, constant: 12),
            progressView.trailingAnchor.constraint(equalTo: endTimer.leadingAnchor, constant: -12),
            progressView.heightAnchor.constraint(equalToConstant: 3)
            
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
