//
//  PopularPlaylistCollectionViewCell.swift
//  designToCode9
//
//  Created by Dheeraj Kumar Sharma on 01/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct PlaylistData {
    let img:String!
    let song:String!
    let artist:String!
    let selected:Bool!
    let shadowColor:UIColor!
}

protocol PlaylistProtocol {
    func playlistTapped()
}

class PopularPlaylistCollectionViewCell: UICollectionViewCell {
    
    var delegate:PlaylistProtocol?
    var playList:[PlaylistData] = [
        PlaylistData(img: "img1", song: "Like it doesn't hurt", artist: "Charlo cardin" , selected: false , shadowColor: CustomColors.appRed),
        PlaylistData(img: "img2", song: "Love on the brain", artist: "Tvorchi", selected: true , shadowColor: CustomColors.appRed)
    ]
    
    let title:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        let titleText = "most popular"
        let paragraphStyle = NSMutableParagraphStyle()
        //line height size
        paragraphStyle.lineSpacing = 1
        let attrString = NSMutableAttributedString(string: titleText)
        attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value:paragraphStyle, range:NSMakeRange(0, attrString.length))
        l.attributedText = attrString
        l.font = UIFont(name:"Avenir-Black", size: 40)
        l.numberOfLines = 0
        l.textColor = .white
        return l
    }()
    
    let subTitle:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "960 playlists"
        l.numberOfLines = 0
        l.font = UIFont(name: "Avenir", size: 18)
        l.textColor = .lightGray
        return l
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.setCollectionViewLayout(layout, animated: false)
        cv.register(PlayListCardCollectionViewCell.self, forCellWithReuseIdentifier: "PlayListCardCollectionViewCell")
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .clear
        cv.contentInset = UIEdgeInsets(top: 0, left: 17, bottom: 0, right: 17)
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(title)
        addSubview(subTitle)
        addSubview(collectionView)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            title.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 17),
            title.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            title.widthAnchor.constraint(equalToConstant: 180),
            
            subTitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 17),
            subTitle.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 15),
            
            collectionView.leadingAnchor.constraint(equalTo: leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: trailingAnchor),
            collectionView.topAnchor.constraint(equalTo: subTitle.bottomAnchor, constant: 10),
            collectionView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension PopularPlaylistCollectionViewCell:UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return playList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlayListCardCollectionViewCell", for: indexPath) as! PlayListCardCollectionViewCell
        cell.data = playList[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.playlistTapped()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 240, height: 300)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
}
