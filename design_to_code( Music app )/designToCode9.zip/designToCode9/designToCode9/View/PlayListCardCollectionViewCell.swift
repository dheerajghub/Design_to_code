//
//  PlayListCardCollectionViewCell.swift
//  designToCode9
//
//  Created by Dheeraj Kumar Sharma on 01/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class PlayListCardCollectionViewCell: UICollectionViewCell {
    
    var data:PlaylistData? {
        didSet{
            manageData()
        }
    }
    
    let playListCard:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .clear
        v.layer.cornerRadius = 15
        v.layer.shadowColor = UIColor.systemPink.cgColor
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let cardImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.layer.cornerRadius = 15
        img.clipsToBounds = true
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    let addButton:UIButton = {
        let btn = UIButton()
        btn.setImage(UIImage(named: "selected"), for: .normal)
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        btn.layer.shadowOpacity = 0.6
        btn.layer.shadowRadius = 8
        btn.layer.masksToBounds = false
        btn.layer.cornerRadius = 20
        return btn
    }()
    
    let cardDetails:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        l.textColor = .white
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(playListCard)
        playListCard.addSubview(cardImage)
        addSubview(addButton)
        playListCard.addSubview(cardDetails)
        cardImage.pin(to: playListCard)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            playListCard.leadingAnchor.constraint(equalTo: leadingAnchor),
            playListCard.trailingAnchor.constraint(equalTo: trailingAnchor,constant: -25),
            playListCard.topAnchor.constraint(equalTo: topAnchor),
            playListCard.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            addButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -4),
            addButton.widthAnchor.constraint(equalToConstant: 40),
            addButton.heightAnchor.constraint(equalToConstant: 40),
            addButton.topAnchor.constraint(equalTo: topAnchor, constant: 40),
            
            cardDetails.leadingAnchor.constraint(equalTo: playListCard.leadingAnchor, constant: 15),
            cardDetails.trailingAnchor.constraint(equalTo: playListCard.trailingAnchor, constant: -15),
            cardDetails.bottomAnchor.constraint(equalTo: playListCard.bottomAnchor, constant: -20)
        ])
    }
    
    func manageData(){
        guard let data = data else {return}
        cardImage.image = UIImage(named: data.img)
        if data.selected{
            addButton.setImage(UIImage(named: "selected"), for: .normal)
            addButton.layer.shadowColor = UIColor.black.cgColor
        } else {
            addButton.setImage(UIImage(named: "add"), for: .normal)
            addButton.layer.shadowColor = CustomColors.appRed.cgColor
        }
        setUpAttributeValue()
    }
    
    func setUpAttributeValue(){
        guard let data = data else { return }
        let attributedText = NSMutableAttributedString(string:"\(data.song ?? "")\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Black", size: 17)!])
        attributedText.append(NSAttributedString(string: "\(data.artist ?? "")" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir", size: 14)!, NSAttributedString.Key.foregroundColor: UIColor.white]))
        cardDetails.attributedText = attributedText
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
