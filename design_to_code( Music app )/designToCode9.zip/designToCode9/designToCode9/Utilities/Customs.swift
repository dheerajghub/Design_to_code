//
//  Customs.swift
//  designToCode9
//
//  Created by Dheeraj Kumar Sharma on 01/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColors {
    static let appRed:UIColor = UIColor(red: 255/255, green: 40/255, blue: 66/255, alpha: 1)
    static let appBackDark:UIColor = UIColor(red: 30/255, green: 31/255, blue: 49/255, alpha: 1)
    static let appBackLight:UIColor = UIColor(red: 41/255, green: 42/255, blue: 62/255, alpha: 1)
}
