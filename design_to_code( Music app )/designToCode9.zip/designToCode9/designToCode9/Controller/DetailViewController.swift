//
//  DetailViewController.swift
//  designToCode9
//
//  Created by Dheeraj Kumar Sharma on 01/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    let backImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "img1")
        img.clipsToBounds = true
        return img
    }()
    
    let controllView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 15
        v.layer.masksToBounds = true
        return v
    }()
    
    let controllUpperView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 15
        v.layer.masksToBounds = true
        return v
    }()
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.textColor = .white
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Avenir-Heavy", size: 26)
        l.text = "Like it doesn't hurt"
        return l
    }()
    
    let subTitleLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Avenir", size: 15)
        l.text = "Chris shelet"
        l.textColor = .white
        return l
    }()
    
    let addImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(systemName: "plus")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        img.contentMode = .scaleAspectFit
        img.clipsToBounds = true
        return img
    }()
    
    let startTimer:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "01:20"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Heavy", size: 12)
        return l
    }()
    
    let endTimer:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "-03:45"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Heavy", size: 12)
        l.textAlignment = .right
        return l
    }()
    
    let progressBar:UIProgressView = {
        let v = UIProgressView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.setProgress(0.4, animated: true)
        v.trackTintColor = .white
        v.progressTintColor = CustomColors.appRed
        return v
    }()
    
    let stackView:UIStackView = {
        let sv = UIStackView()
        sv.distribution = .fillEqually
        sv.axis = .horizontal
        sv.spacing = 20
        sv.translatesAutoresizingMaskIntoConstraints = false
        return sv
    }()
    
    let playAndPauseImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.image = UIImage(systemName: "pause")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let forwardImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFit
        img.image = UIImage(systemName: "forward")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let backwardImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFit
        img.image = UIImage(systemName: "backward")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let forwardStopImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.image = UIImage(systemName: "forward.end")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let backwardStopImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.image = UIImage(systemName: "backward.end")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    let shuffleImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(systemName: "shuffle")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let headphoneImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(systemName: "headphones")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(backImage)
        backImage.pin(to: view)
        view.addSubview(controllView)
        view.addSubview(controllUpperView)
        controllUpperView.addSubview(titleLabel)
        controllUpperView.addSubview(subTitleLabel)
        controllUpperView.addSubview(addImage)
        controllUpperView.addSubview(progressBar)
        controllUpperView.addSubview(startTimer)
        controllUpperView.addSubview(endTimer)
        controllUpperView.addSubview(stackView)
        stackView.addArrangedSubview(backwardStopImage)
        stackView.addArrangedSubview(backwardImage)
        stackView.addArrangedSubview(playAndPauseImage)
        stackView.addArrangedSubview(forwardImage)
        stackView.addArrangedSubview(forwardStopImage)
        controllUpperView.addSubview(shuffleImage)
        controllUpperView.addSubview(headphoneImage)
        setUpConstraints()
        setUpNavigationBar()

        let blurEffect = UIBlurEffect(style:.light)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = controllView.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        controllView.addSubview(blurEffectView)

    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            controllView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            controllView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            controllView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            controllView.heightAnchor.constraint(equalToConstant: 250),
            
            controllUpperView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            controllUpperView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            controllUpperView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            controllUpperView.heightAnchor.constraint(equalToConstant: 250),
            
            titleLabel.topAnchor.constraint(equalTo: controllView.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: controllView.leadingAnchor , constant: 20),
            
            subTitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor),
            subTitleLabel.leadingAnchor.constraint(equalTo: controllView.leadingAnchor , constant: 20),
            
            addImage.trailingAnchor.constraint(equalTo: controllUpperView.trailingAnchor , constant: -20),
            addImage.topAnchor.constraint(equalTo: controllUpperView.topAnchor, constant: 20),
            addImage.heightAnchor.constraint(equalToConstant: 25),
            addImage.widthAnchor.constraint(equalToConstant: 25),
            
            progressBar.leadingAnchor.constraint(equalTo: controllUpperView.leadingAnchor, constant: 20),
            progressBar.trailingAnchor.constraint(equalTo: controllUpperView.trailingAnchor, constant: -20),
            progressBar.topAnchor.constraint(equalTo: subTitleLabel.bottomAnchor, constant: 30),
            
            startTimer.leadingAnchor.constraint(equalTo: controllUpperView.leadingAnchor, constant: 20),
            startTimer.topAnchor.constraint(equalTo: progressBar.bottomAnchor, constant: 5),
            
            endTimer.trailingAnchor.constraint(equalTo: controllUpperView.trailingAnchor, constant: -20),
            endTimer.topAnchor.constraint(equalTo: progressBar.bottomAnchor, constant: 5),
            
            stackView.topAnchor.constraint(equalTo: progressBar.bottomAnchor, constant: 40),
            stackView.centerXAnchor.constraint(equalTo: controllUpperView.centerXAnchor),
            stackView.heightAnchor.constraint(equalToConstant: 28),
            stackView.widthAnchor.constraint(equalToConstant: 200),
            
            shuffleImage.trailingAnchor.constraint(equalTo: controllUpperView.trailingAnchor, constant: -20),
            shuffleImage.bottomAnchor.constraint(equalTo: controllUpperView.bottomAnchor, constant: -20),
            shuffleImage.widthAnchor.constraint(equalToConstant: 25),
            shuffleImage.heightAnchor.constraint(equalToConstant: 25),
            
            headphoneImage.leadingAnchor.constraint(equalTo: controllUpperView.leadingAnchor, constant: 20),
            headphoneImage.bottomAnchor.constraint(equalTo: controllUpperView.bottomAnchor, constant: -20),
            headphoneImage.widthAnchor.constraint(equalToConstant: 25),
            headphoneImage.heightAnchor.constraint(equalToConstant: 25)
            
        ])
    }
    
    func setUpNavigationBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.isTranslucent = true
        
        let titleLabel = UILabel()
        let attributedText = NSMutableAttributedString(string:"Hello, Yana\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Black", size: 16)!])
        attributedText.append(NSAttributedString(string: "New York" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir", size: 12)!, NSAttributedString.Key.foregroundColor: UIColor.white]))
        titleLabel.numberOfLines = 0
        titleLabel.attributedText = attributedText
        titleLabel.textColor = .white
        titleLabel.sizeToFit()
        let RightTitleItem = UIBarButtonItem(customView: titleLabel)
        self.navigationItem.rightBarButtonItem = RightTitleItem
        
        let notifButton = UIButton(type: .custom)
        notifButton.setImage(UIImage(named: "notification")?.withRenderingMode(.alwaysTemplate), for: .normal)
        notifButton.tintColor = .white
        notifButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: notifButton)
        let rightBarButtonItem = UIBarButtonItem()
        rightBarButtonItem.customView = notifButton

        navigationItem.setRightBarButtonItems([rightBarButtonItem , RightTitleItem], animated: true)
        
        let backButton = UIButton(type: .custom)
        backButton.setImage(UIImage(named: "back")?.withRenderingMode(.alwaysTemplate), for: .normal)
        backButton.tintColor = .white
        backButton.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButton)
        backButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = backButton

        navigationItem.setLeftBarButton(leftBarButtonItem, animated: true)
    }
    
    @objc func backButtonPressed(){
        navigationController?.popViewController(animated: true)
    }

}
