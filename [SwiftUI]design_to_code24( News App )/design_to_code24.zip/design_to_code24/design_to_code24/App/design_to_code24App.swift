//
//  design_to_code24App.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

@main
struct design_to_code24App: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
