//
//  HomeView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct HomeView: View {
    // MARK:- PROPERTIES
    
    var newsPostData:[NewsPostModel]
    
    init(){
        UINavigationBar.appearance().setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        UINavigationBar.appearance().shadowImage = UIImage()
        UINavigationBar.appearance().isTranslucent = false
        UINavigationBar.appearance().tintColor = .clear
        UINavigationBar.appearance().backgroundColor = .white
        
        //Assigning Data
        newsPostData = NewsPostData
    }
    
    var body: some View {
        NavigationView {
            ScrollView(.vertical, showsIndicators:false){
                VStack {
                    StoryView(storyData: StoryData)
                    ForEach(newsPostData) { item in
                        NewsPostView(newsPostData: item)
                    }//: LOOP
                }//: VSTACK
            }//: SCROLLVIEW
            .navigationBarTitle("" , displayMode: .inline)
            .navigationBarItems(
                    leading:
                        Text("Home")
                        .font(Font.custom("Times-Bold", size: 28))
                    ,
                    trailing:
                        Button(action:{
                            
                        }){
                            Image("search")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 30, height: 30, alignment: .center)
                        }
                )
        }//: NAVIGATIONVIEW
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
