//
//  MainView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct MainView: View {
    
    init() {
        UITabBar.appearance().barTintColor = .white
    }
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image("home")
                        .renderingMode(.template)
                        .foregroundColor(.gray)
                }
            
            MessageView()
                .tabItem {
                    Image("message")
                        .renderingMode(.template)
                        .foregroundColor(.gray)
                }
            
            ActivityView()
                .tabItem {
                    Image("activity")
                        .renderingMode(.template)
                        .foregroundColor(.gray)
                }
            
            UserView()
                .tabItem {
                    Image("user")
                        .renderingMode(.template)
                        .foregroundColor(.gray)
                }
        }//: TABVIEW
        .accentColor(.black)
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
