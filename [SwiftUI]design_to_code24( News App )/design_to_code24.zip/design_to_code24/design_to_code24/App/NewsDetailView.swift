//
//  NewsDetailView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct NewsDetailView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct NewsDetailView_Previews: PreviewProvider {
    static var previews: some View {
        NewsDetailView()
    }
}
