//
//  StoryData.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import Foundation

var StoryData:[StoryModel] = [
    StoryModel(id: UUID(), name: "Dheeraj", image: "demo"),
    StoryModel(id: UUID(), name: "John mikel", image: "img1"),
    StoryModel(id: UUID(), name: "Clark west", image: "img2"),
    StoryModel(id: UUID(), name: "July", image: "img3"),
    StoryModel(id: UUID(), name: "Joey", image: "img4"),
    StoryModel(id: UUID(), name: "Sammy", image: "img5")
]

