//
//  NewsPostData.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import Foundation

var NewsPostData:[NewsPostModel] = [
    NewsPostModel(id: UUID(), profileImage: "img1", name: "John mikel", channelImage: "channel1", channelName: "360 News", categoryName: "Technology", timeAgo: "22 mins ago", bannerImage: "banner1", headline: "Apple will announce iOS 14.3 in december end 2020", likes: "22", chats: "20", stars: "780"),
    NewsPostModel(id: UUID(), profileImage: "demo", name: "Dheeraj", channelImage: "channel3", channelName: "Indian express News", categoryName: "Weather", timeAgo: "1 hour ago", bannerImage: "banner2", headline: "Weather Today HIGHLIGHTS: Gujarat records 113.5 % average rainfall", likes: "40", chats: "14", stars: "623"),
    NewsPostModel(id: UUID(), profileImage: "img5", name: "Sammy", channelImage: "channel2", channelName: "BBC News", categoryName: "Technology", timeAgo: "12 hours ago", bannerImage: "banner3", headline: "Huawei ban: UK to impose early end to use of new 5G kit", likes: "70", chats: "54", stars: "1123")
]
