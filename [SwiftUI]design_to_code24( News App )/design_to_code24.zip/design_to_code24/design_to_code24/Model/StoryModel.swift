//
//  StoryData.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct StoryModel: Identifiable {
    let id: UUID
    let name: String
    let image: String
}
