//
//  NewsPostModel.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct NewsPostModel: Identifiable {
    let id: UUID
    let profileImage: String
    let name: String
    let channelImage: String
    let channelName: String
    let categoryName: String
    let timeAgo: String
    let bannerImage: String
    let headline: String
    let likes: String
    let chats: String
    let stars: String
}
