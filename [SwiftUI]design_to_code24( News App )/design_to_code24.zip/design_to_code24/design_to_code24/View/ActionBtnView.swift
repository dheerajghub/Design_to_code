//
//  ActionBtnView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct ActionBtnView: View {
    // MARK:- PROPERTIES
    
    var image: String
    var text: String
    
    // MARK:- BODY
    
    var body: some View {
        HStack(alignment: .center, spacing: 4){
            Image(image)
                .resizable()
                .renderingMode(.template)
                .foregroundColor(.gray)
                .frame(width: 20, height: 20, alignment: .center)
            
            Text(text)
                .font(Font.custom("Times-Regular", size: 13))
                .foregroundColor(.gray)
        }//: HSTACK
    }
}

// MARK:- PREVIEW

struct ActionBtnView_Previews: PreviewProvider {
    static var previews: some View {
        ActionBtnView(image: "like", text: "22")
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
