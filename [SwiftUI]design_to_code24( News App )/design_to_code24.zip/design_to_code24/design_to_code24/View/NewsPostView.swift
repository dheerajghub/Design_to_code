//
//  NewsPostView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct NewsPostView: View {
    // MARK:- PROPERTIES
    
    var newsPostData:NewsPostModel
    
    // MARK:- BODY
    
    var body: some View {
        VStack(alignment: .center, spacing: 10){
            PostHeaderView(newsPostData: newsPostData)
            VStack(alignment: .leading){
                HStack{
                    Text(newsPostData.categoryName)
                        .font(Font.system(size: 15))
                        .fontWeight(.semibold)
                    Spacer()
                    Text(newsPostData.timeAgo)
                        .font(Font.system(size: 13))
                        .fontWeight(.medium)
                        .foregroundColor(.gray)
                }//: HSTACK
                
                Image(newsPostData.bannerImage)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 180, alignment: .center)
                    .clipped()
                    .cornerRadius(10)
                    .padding(.vertical , 0)
                
                Text(newsPostData.headline)
                    .font(Font.custom("Times-Bold", size: 20))
                    .fixedSize(horizontal: false, vertical: true)
                
                Divider()
                
                HStack{
                    Button(action:{
                        
                    }){
                        ActionBtnView(image: "like", text: newsPostData.likes)
                    }
                    
                    Spacer()
                    
                    Button(action:{
                        
                    }){
                        ActionBtnView(image: "chat", text: newsPostData.chats)
                    }
                    
                    Spacer()
                    
                    Button(action:{
                        
                    }){
                        ActionBtnView(image: "star", text: newsPostData.stars)
                    }
                    
                    Spacer()
                    
                    Button(action:{
                        
                    }){
                        ActionBtnView(image: "share", text: "")
                    }
                }//: HSTACK
                .padding(.horizontal, 10)
                .padding(.vertical, 2)
            }//: VSTACK
            .padding(12)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(Color(red: 230/255, green: 230/255, blue: 230/255), lineWidth: 1)
            )
        }//: VSTACK
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
    }
}

// MARK:- PREVIEW

struct NewsPostView_Previews: PreviewProvider {
    static var previews: some View {
        NewsPostView(newsPostData: NewsPostData[0])
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
