//
//  SwiftUIView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct PostHeaderView: View {
    // MARK:- PROPERTIES
    
    var newsPostData: NewsPostModel
    
    // MARK:- BODY
    
    var body: some View {
        HStack(alignment: .center){
            Image(newsPostData.profileImage)
                .resizable()
                .scaledToFill()
                .frame(width: 45, height: 45, alignment: .center)
                .cornerRadius(22.5)
            VStack(alignment: .leading, spacing:3){
                Text(newsPostData.name)
                    .font(Font.system(size: 16))
                    .fontWeight(.semibold)
                HStack(alignment: .center, spacing:5){
                    Image(newsPostData.channelImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 17, height: 17, alignment: .center)
                        .cornerRadius(8.5)
                        .overlay(Circle().stroke(Color(red: 230/255, green: 230/255, blue: 230/255), lineWidth: 0.6))
                    Text(newsPostData.channelName)
                        .font(Font.system(size: 14))
                        .foregroundColor(.gray)
                }//: HSTACK
            }//: VSTACK
            
            Spacer()
            
            Button(action:{
                
            }){
               Image(systemName: "ellipsis")
                .resizable()
                .scaledToFit()
                .frame(width: 18, height: 18, alignment: .center)
                .foregroundColor(.gray)
            }//: BUTTON
        }//: HSTACK
    }
}

// MARK:- PREVIEW

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        PostHeaderView(newsPostData: NewsPostData[0])
            .previewLayout(.sizeThatFits)
    }
}
