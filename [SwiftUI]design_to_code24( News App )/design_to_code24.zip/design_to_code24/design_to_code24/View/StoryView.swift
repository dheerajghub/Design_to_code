//
//  StoryView.swift
//  design_to_code24
//
//  Created by Dheeraj Kumar Sharma on 30/11/20.
//

import SwiftUI

struct StoryView: View {
    // MARK:- PROPERTIES
    
    var storyData:[StoryModel]
    
    // MARK:- BODY
    
    var body: some View {
        ScrollView(.horizontal , showsIndicators: false){
            HStack(alignment: .center, spacing: 12) {
                ForEach(storyData) { item in
                    VStack {
                        Image(item.image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 70, height: 70, alignment: .center)
                            .cornerRadius(10)
                        Text(item.name)
                            .font(Font.system(size: 10))
                            .frame(width:65)
                            .lineLimit(1)
                    }//: VSTACK
                }//: LOOP
            }//: HSTACK
            .padding(.vertical, 10)
            .padding(.horizontal, 20)
        }//: SCROLLVIEW
    }
}

// MARK:- PREVIEW

struct StoryView_Previews: PreviewProvider {
    static var previews: some View {
        StoryView(storyData: StoryData)
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
