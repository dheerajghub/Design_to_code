//
//  ExploreViewController.swift
//  Design_to_code10
//
//  Created by Dheeraj Kumar Sharma on 04/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ExploreViewController: UIViewController, GridLayoutDelegate {

    let imgArr = ["img1" , "img2", "img3", "img4" , "img5", "img6", "img7" , "img8", "img9", "img10"]
    
    var arrInstaBigCells = [Int]()
    let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
    
    let headerView:CustomExplorerHeader = {
        let v = CustomExplorerHeader()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        return v
    }()
    
    lazy var collectionView: UICollectionView = {
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: GridLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsVerticalScrollIndicator = false
        cv.setCollectionViewLayout(layout, animated: false)
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .white
        cv.register(PostThumbnailCollectionViewCell.self, forCellWithReuseIdentifier: "PostThumbnailCollectionViewCell")
        let customLayout = GridLayout()
        cv.collectionViewLayout = customLayout
        customLayout.delegate = self
        customLayout.itemSpacing = 1
        customLayout.fixedDivisionCount = 3
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        layout.scrollDirection = .vertical
        if let layout = collectionView.collectionViewLayout as? GridLayout {
            layout.delegate = self
        }
        
        arrInstaBigCells.append(1)
        var tempStorage = false
        for _ in 1...21 {
            if(tempStorage){
                arrInstaBigCells.append(arrInstaBigCells.last! + 10)
            } else {
                arrInstaBigCells.append(arrInstaBigCells.last! + 8)
            }
            tempStorage = !tempStorage
        }
        collectionView.contentInset = UIEdgeInsets(top: 1, left: 10, bottom: 1, right: 10)
        collectionView.contentOffset = CGPoint(x: -1, y: -1)
        view.addSubview(headerView)
        view.addSubview(collectionView)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 110),
            
            collectionView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
}

extension ExploreViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PostThumbnailCollectionViewCell", for: indexPath) as! PostThumbnailCollectionViewCell
        cell.thumbNailImage.image = UIImage(named: imgArr[indexPath.row])
        return cell
    }

    func scaleForItem(inCollectionView collectionView: UICollectionView, withLayout layout: UICollectionViewLayout, atIndexPath indexPath: IndexPath) -> UInt {
        if(arrInstaBigCells.contains(indexPath.row) || (indexPath.row == 1)){
            return 2
        } else {
            return 1
        }
    }
    
    func itemFlexibleDimension(inCollectionView collectionView: UICollectionView, withLayout layout: UICollectionViewLayout, fixedDimension: CGFloat) -> CGFloat {
        return fixedDimension
    }
    
}
