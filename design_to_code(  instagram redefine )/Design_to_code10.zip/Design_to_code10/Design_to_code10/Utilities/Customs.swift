//
//  Customs.swift
//  Design_to_code10
//
//  Created by Dheeraj Kumar Sharma on 04/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomFont{
    static let logo = "Billabong"
}

struct CustomColor {
    static let appLightGray:UIColor = UIColor(red: 193/255, green: 193/255, blue: 193/255, alpha: 1)
}
