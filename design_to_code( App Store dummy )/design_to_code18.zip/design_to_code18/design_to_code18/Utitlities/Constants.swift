//
//  Constants.swift
//  design_to_code18
//
//  Created by Dheeraj Kumar Sharma on 09/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColors {
    static let lightGray = UIColor(red: 132/255, green: 132/255, blue: 132/255, alpha: 1)
}
