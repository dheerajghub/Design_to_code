//
//  StickerView.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class StickerView: UIView {

    let demoLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Do you like this design to code project? Then do like this post!"
        l.textColor = .white
        l.textAlignment = .center
        l.font = UIFont(name: "Avenir-Medium", size: 26)
        l.numberOfLines = 0
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        addSubview(demoLabel)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            demoLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
            demoLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -15),
            demoLabel.topAnchor.constraint(equalTo: topAnchor),
            demoLabel.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
