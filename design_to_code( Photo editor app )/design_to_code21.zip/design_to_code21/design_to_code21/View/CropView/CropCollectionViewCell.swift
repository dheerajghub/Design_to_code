//
//  CropCollectionViewCell.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CropCollectionViewCell: UICollectionViewCell {
    
    override var isSelected: Bool {
        didSet{
            image.tintColor = isSelected ? .white : .gray
        }
    }
    
    let image:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.translatesAutoresizingMaskIntoConstraints = false
        img.tintColor = .gray
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(image)
        image.pin(to: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
