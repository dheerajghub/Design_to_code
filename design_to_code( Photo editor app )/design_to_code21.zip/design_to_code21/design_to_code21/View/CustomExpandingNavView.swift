//
//  CustomExpandingNavView.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomExpandingNavView: UIView {

    var delegate:ViewController?

    lazy var tabView:EditorTabBarView = {
        let v = EditorTabBarView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.delegate = self
        return v
    }()
    
    /// Crop view
    let cropView:CropView = {
        let v = CropView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    /// Filter view
    let filterView:FilterView = {
        let v = FilterView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    /// adjust view
    let adjustView:FilterView = {
        let v = FilterView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    /// Effect view
    let effectView:StickerView = {
        let v = StickerView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    /// Saturation view
    let saturationView:DropView = {
        let v = DropView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tabView)
        addSubview(saturationView)
        addSubview(effectView)
        addSubview(adjustView)
        addSubview(filterView)
        addSubview(cropView)
        setUpConstraints()
        
        /// adjust up the initial state for the views
        filterView.isHidden = true
        filterView.alpha = 0
        adjustView.isHidden = true
        adjustView.alpha = 0
        effectView.isHidden = true
        effectView.alpha = 0
        saturationView.isHidden = true
        saturationView.alpha = 0
    }
    
    func setUpConstraints(){
        let estimatedHeight = (UIScreen.main.bounds.width - 190) / 4
        NSLayoutConstraint.activate([
            tabView.leadingAnchor.constraint(equalTo: leadingAnchor),
            tabView.trailingAnchor.constraint(equalTo: trailingAnchor),
            tabView.bottomAnchor.constraint(equalTo: self.safeAreaLayoutGuide.bottomAnchor),
            tabView.heightAnchor.constraint(equalToConstant: estimatedHeight + 10),
            
            cropView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            cropView.bottomAnchor.constraint(equalTo: tabView.topAnchor, constant: -15),
            cropView.leadingAnchor.constraint(equalTo: leadingAnchor),
            cropView.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            filterView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            filterView.bottomAnchor.constraint(equalTo: tabView.topAnchor, constant: -15),
            filterView.leadingAnchor.constraint(equalTo: leadingAnchor),
            filterView.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            adjustView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            adjustView.bottomAnchor.constraint(equalTo: tabView.topAnchor, constant: -15),
            adjustView.leadingAnchor.constraint(equalTo: leadingAnchor),
            adjustView.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            effectView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            effectView.bottomAnchor.constraint(equalTo: tabView.topAnchor, constant: -15),
            effectView.leadingAnchor.constraint(equalTo: leadingAnchor),
            effectView.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            saturationView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            saturationView.bottomAnchor.constraint(equalTo: tabView.topAnchor, constant: -15),
            saturationView.leadingAnchor.constraint(equalTo: leadingAnchor),
            saturationView.trailingAnchor.constraint(equalTo: trailingAnchor),
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


/// Extension for handling button actions
extension CustomExpandingNavView {
    @objc func btn1IsPressed(){
        /// Set Width Contraints of button to 100  if pressed otherwise to estimatedDimension
        let estimatedDimension = (UIScreen.main.bounds.width - 190) / 4
        tabView.btn1WidthContraints?.constant = 100
        tabView.btn2WidthContraints?.constant = estimatedDimension
        tabView.btn3WidthContraints?.constant = estimatedDimension
        tabView.btn4WidthContraints?.constant = estimatedDimension
        tabView.btn5WidthContraints?.constant = estimatedDimension
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.layoutIfNeeded()
        }, completion: nil)
        
        /// Set Attributes for btn for image with title and without
        tabView.btn1.setAttributedTitle(tabView.setAttributes(withTitle: "Crop", withImage: UIImage(named: "crop"), withTextColor: Colors.appBlack), for: .normal)
        tabView.btn2.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "filter"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn3.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "adjust"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn4.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "effects"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn5.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "saturation"), withTextColor: Colors.appGray, withImageSize:20), for: .normal)
        
        /// Seting button background
        tabView.btn1.backgroundColor = .white
        tabView.btn2.backgroundColor = .clear
        tabView.btn3.backgroundColor = .clear
        tabView.btn4.backgroundColor = .clear
        tabView.btn5.backgroundColor = .clear
        
        /// Show the crop view
        cropView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.filterView.alpha = 0
            self.adjustView.alpha = 0
            self.effectView.alpha = 0
            self.saturationView.alpha = 0
            self.cropView.alpha = 1
        }, completion: { finish in
            self.filterView.isHidden = true
            self.adjustView.isHidden = true
            self.effectView.isHidden = true
            self.saturationView.isHidden = true
        })
    }
    
    @objc func btn2IsPressed(){
        
        /// Set Width Contraints of button to 100  if pressed otherwise to estimatedDimension
        let estimatedDimension = (UIScreen.main.bounds.width - 190) / 4
        tabView.btn2WidthContraints?.constant = 100
        tabView.btn1WidthContraints?.constant = estimatedDimension
        tabView.btn3WidthContraints?.constant = estimatedDimension
        tabView.btn4WidthContraints?.constant = estimatedDimension
        tabView.btn5WidthContraints?.constant = estimatedDimension
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.layoutIfNeeded()
        }, completion: nil)
        
        /// Set Attributes for btn for image with title and without
        tabView.btn1.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "crop"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn2.setAttributedTitle(tabView.setAttributes(withTitle: "Filters", withImage: UIImage(named: "filter"), withTextColor: Colors.appBlack), for: .normal)
        tabView.btn3.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "adjust"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn4.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "effects"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn5.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "saturation"), withTextColor: Colors.appGray, withImageSize:20), for: .normal)
        
        /// Seting button background
        tabView.btn1.backgroundColor = .clear
        tabView.btn2.backgroundColor = .white
        tabView.btn3.backgroundColor = .clear
        tabView.btn4.backgroundColor = .clear
        tabView.btn5.backgroundColor = .clear
        
        /// Show the filter view
        filterView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.filterView.alpha = 1
            self.adjustView.alpha = 0
            self.effectView.alpha = 0
            self.saturationView.alpha = 0
            self.cropView.alpha = 0
        }, completion: { finish in
            self.cropView.isHidden = true
            self.adjustView.isHidden = true
            self.effectView.isHidden = true
            self.saturationView.isHidden = true
        })
    }
    
    @objc func btn3IsPressed(){
        
        /// Set Width Contraints of button to 100  if pressed otherwise to estimatedDimension
        let estimatedDimension = (UIScreen.main.bounds.width - 190) / 4
        tabView.btn3WidthContraints?.constant = 100
        tabView.btn1WidthContraints?.constant = estimatedDimension
        tabView.btn2WidthContraints?.constant = estimatedDimension
        tabView.btn4WidthContraints?.constant = estimatedDimension
        tabView.btn5WidthContraints?.constant = estimatedDimension
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.layoutIfNeeded()
        }, completion: nil)
        
        /// Set Attributes for btn for image with title and without
        tabView.btn1.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "crop"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn2.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "filter"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn3.setAttributedTitle(tabView.setAttributes(withTitle: "Adjust", withImage: UIImage(named: "adjust"), withTextColor: Colors.appBlack), for: .normal)
        tabView.btn4.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "effects"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn5.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "saturation"), withTextColor: Colors.appGray, withImageSize:20), for: .normal)
        
        /// Seting button background
        tabView.btn1.backgroundColor = .clear
        tabView.btn2.backgroundColor = .clear
        tabView.btn3.backgroundColor = .white
        tabView.btn4.backgroundColor = .clear
        tabView.btn5.backgroundColor = .clear
        
        /// Show the adjust view
        adjustView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.filterView.alpha = 0
            self.adjustView.alpha = 1
            self.effectView.alpha = 0
            self.saturationView.alpha = 0
            self.cropView.alpha = 0
        }, completion: { finish in
            self.cropView.isHidden = true
            self.filterView.isHidden = true
            self.effectView.isHidden = true
            self.saturationView.isHidden = true
        })
    }
    
    @objc func btn4IsPressed(){
        
        /// Set Width Contraints of button to 100  if pressed otherwise to estimatedDimension
        let estimatedDimension = (UIScreen.main.bounds.width - 190) / 4
        tabView.btn4WidthContraints?.constant = 100
        tabView.btn1WidthContraints?.constant = estimatedDimension
        tabView.btn2WidthContraints?.constant = estimatedDimension
        tabView.btn3WidthContraints?.constant = estimatedDimension
        tabView.btn5WidthContraints?.constant = estimatedDimension
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.layoutIfNeeded()
        }, completion: nil)
        
        tabView.btn1.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "crop"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn2.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "filter"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn3.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "adjust"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn4.setAttributedTitle(tabView.setAttributes(withTitle: "Stickers", withImage: UIImage(named: "effects"), withTextColor: Colors.appBlack), for: .normal)
        tabView.btn5.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "saturation"), withTextColor: Colors.appGray, withImageSize:20), for: .normal)
        
        /// Seting button background
        tabView.btn1.backgroundColor = .clear
        tabView.btn2.backgroundColor = .clear
        tabView.btn3.backgroundColor = .clear
        tabView.btn4.backgroundColor = .white
        tabView.btn5.backgroundColor = .clear
        
        /// Show the effects view
        effectView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.filterView.alpha = 0
            self.adjustView.alpha = 0
            self.effectView.alpha = 1
            self.saturationView.alpha = 0
            self.cropView.alpha = 0
        }, completion: { finish in
            self.cropView.isHidden = true
            self.filterView.isHidden = true
            self.adjustView.isHidden = true
            self.saturationView.isHidden = true
        })
    }
    
    @objc func btn5IsPressed(){
        
        /// Set Width Contraints of button to 100  if pressed otherwise to estimatedDimension
        let estimatedDimension = (UIScreen.main.bounds.width - 190) / 4
        tabView.btn5WidthContraints?.constant = 100
        tabView.btn1WidthContraints?.constant = estimatedDimension
        tabView.btn2WidthContraints?.constant = estimatedDimension
        tabView.btn3WidthContraints?.constant = estimatedDimension
        tabView.btn4WidthContraints?.constant = estimatedDimension
        UIView.animate(withDuration: 0.3, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.layoutIfNeeded()
        }, completion: nil)
        
        /// Set Attributes for btn for image with title and without
        tabView.btn1.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "crop"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn2.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "filter"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn3.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "adjust"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn4.setAttributedTitle(tabView.setAttributes(withTitle: "", withImage: UIImage(named: "effects"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        tabView.btn5.setAttributedTitle(tabView.setAttributes(withTitle: "Drop", withImage: UIImage(named: "saturation"), withTextColor: Colors.appBlack), for: .normal)
        
        /// Seting button background
        tabView.btn1.backgroundColor = .clear
        tabView.btn2.backgroundColor = .clear
        tabView.btn3.backgroundColor = .clear
        tabView.btn4.backgroundColor = .clear
        tabView.btn5.backgroundColor = .white
        
        /// Show the saturation view
        saturationView.isHidden = false
        UIView.animate(withDuration: 0.3, animations: {
            self.filterView.alpha = 0
            self.adjustView.alpha = 0
            self.effectView.alpha = 0
            self.saturationView.alpha = 1
            self.cropView.alpha = 0
        }, completion: { finish in
            self.cropView.isHidden = true
            self.filterView.isHidden = true
            self.adjustView.isHidden = true
            self.effectView.isHidden = true
        })
    }
}

