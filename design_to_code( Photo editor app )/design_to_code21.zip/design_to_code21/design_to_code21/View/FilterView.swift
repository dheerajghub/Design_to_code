//
//  FilterView.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct FilterData  {
    let overlayColor:UIColor!
    let effectName:String!
}

class FilterView: UIView {

    /// Demo data
    let data = [
        FilterData(overlayColor: UIColor(red: 255/255, green: 105/255, blue: 105/255, alpha: 0.37), effectName: "Effect1"),
        FilterData(overlayColor: UIColor(red: 70/255, green: 184/255, blue: 255/255, alpha: 0.36), effectName: "Effect2"),
        FilterData(overlayColor: UIColor(red: 134/255, green: 70/255, blue: 255/255, alpha: 0.36), effectName: "Effect3"),
        FilterData(overlayColor: UIColor(red: 128/255, green: 159/255, blue: 0, alpha: 0.38), effectName: "Effect4"),
        FilterData(overlayColor: UIColor(red: 255/255, green: 108/255, blue: 0, alpha: 0.38), effectName: "Effect5"),
        FilterData(overlayColor: UIColor(red: 204/255, green: 177/255, blue: 255/255, alpha: 0.47), effectName: "Effect6"),
        FilterData(overlayColor: UIColor(red: 0, green: 245/255, blue: 236/255, alpha: 0.6), effectName: "Effect7")
    ]
        
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.setCollectionViewLayout(layout, animated: false)
        cv.backgroundColor = .clear
        cv.showsHorizontalScrollIndicator = false
        cv.contentInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        cv.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: "FilterCollectionViewCell")
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        collectionView.pin(to: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension FilterView:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FilterCollectionViewCell", for: indexPath) as! FilterCollectionViewCell
        let d = data[indexPath.row]
        cell.filterName.text = d.effectName
        cell.overlayView.backgroundColor = d.overlayColor
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    
}
