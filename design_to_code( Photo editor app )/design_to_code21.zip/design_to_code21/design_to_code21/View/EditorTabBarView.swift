//
//  EditorTabBarView.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class EditorTabBarView: UIView {

    var estimatedDimension:CGFloat?
    var btn1WidthContraints:NSLayoutConstraint?
    var btn2WidthContraints:NSLayoutConstraint?
    var btn3WidthContraints:NSLayoutConstraint?
    var btn4WidthContraints:NSLayoutConstraint?
    var btn5WidthContraints:NSLayoutConstraint?
    
    var delegate:CustomExpandingNavView?{
        didSet{
            btn1.addTarget(delegate, action: #selector(CustomExpandingNavView.btn1IsPressed), for: .touchUpInside)
            btn2.addTarget(delegate, action: #selector(CustomExpandingNavView.btn2IsPressed), for: .touchUpInside)
            btn3.addTarget(delegate, action: #selector(CustomExpandingNavView.btn3IsPressed), for: .touchUpInside)
            btn4.addTarget(delegate, action: #selector(CustomExpandingNavView.btn4IsPressed), for: .touchUpInside)
            btn5.addTarget(delegate, action: #selector(CustomExpandingNavView.btn5IsPressed), for: .touchUpInside)
        }
    }
    
    let btn1:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = .white
        
        return btn
    }()
    
    let btn2:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    let btn3:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    let btn4:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    let btn5:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        estimatedDimension = (UIScreen.main.bounds.width - 190) / 4
        addSubview(btn1)
        addSubview(btn2)
        addSubview(btn3)
        addSubview(btn4)
        addSubview(btn5)
        setUpConstraints()
        
        btn1.setAttributedTitle(setAttributes(withTitle: "Crop", withImage: UIImage(named: "crop"), withTextColor: Colors.appBlack), for: .normal)
        btn2.setAttributedTitle(setAttributes(withTitle: "", withImage: UIImage(named: "filter"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        btn3.setAttributedTitle(setAttributes(withTitle: "", withImage: UIImage(named: "adjust"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        btn4.setAttributedTitle(setAttributes(withTitle: "", withImage: UIImage(named: "effects"), withTextColor: Colors.appGray, withImageSize:25), for: .normal)
        btn5.setAttributedTitle(setAttributes(withTitle: "", withImage: UIImage(named: "saturation"), withTextColor: Colors.appGray, withImageSize:20), for: .normal)
        
        /// set border of buttons as per estimated dimensions
        let radius = estimatedDimension! / 2
        btn1.layer.cornerRadius = radius
        btn2.layer.cornerRadius = radius
        btn3.layer.cornerRadius = radius
        btn4.layer.cornerRadius = radius
        btn5.layer.cornerRadius = radius
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            btn1.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 15),
            btn1.centerYAnchor.constraint(equalTo: centerYAnchor),
            btn1.heightAnchor.constraint(equalToConstant: estimatedDimension!),
            
            btn2.leadingAnchor.constraint(equalTo: btn1.trailingAnchor, constant: 15),
            btn2.centerYAnchor.constraint(equalTo: centerYAnchor),
            btn2.heightAnchor.constraint(equalToConstant: estimatedDimension!),
            
            btn3.leadingAnchor.constraint(equalTo: btn2.trailingAnchor, constant: 15),
            btn3.centerYAnchor.constraint(equalTo: centerYAnchor),
            btn3.heightAnchor.constraint(equalToConstant: estimatedDimension!),
            
            btn4.leadingAnchor.constraint(equalTo: btn3.trailingAnchor, constant: 15),
            btn4.centerYAnchor.constraint(equalTo: centerYAnchor),
            btn4.heightAnchor.constraint(equalToConstant: estimatedDimension!),
            
            btn5.leadingAnchor.constraint(equalTo: btn4.trailingAnchor, constant: 15),
            btn5.centerYAnchor.constraint(equalTo: centerYAnchor),
            btn5.heightAnchor.constraint(equalToConstant: estimatedDimension!),
        ])
        
        btn1WidthContraints = btn1.widthAnchor.constraint(equalToConstant: 100)
        btn1WidthContraints?.isActive = true
        
        btn2WidthContraints = btn2.widthAnchor.constraint(equalToConstant: estimatedDimension!)
        btn2WidthContraints?.isActive = true
        
        btn3WidthContraints = btn3.widthAnchor.constraint(equalToConstant: estimatedDimension!)
        btn3WidthContraints?.isActive = true
        
        btn4WidthContraints = btn4.widthAnchor.constraint(equalToConstant: estimatedDimension!)
        btn4WidthContraints?.isActive = true
        
        btn5WidthContraints = btn5.widthAnchor.constraint(equalToConstant: estimatedDimension!)
        btn5WidthContraints?.isActive = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
//    UIFont.systemFont(ofSize: 17, weight: .semibold)
    
    public func setAttributes( withTitle title:String, withImage image:UIImage? , withTextColor textColor:UIColor , withImageSize size:CGFloat = 17, withFont font:UIFont = UIFont(name: "Avenir-Medium", size: 17)!) -> NSAttributedString {
        
        let attributedText = NSMutableAttributedString(string:"")
        
        if let image = image {
            let font = font
            let img = image.withRenderingMode(.alwaysTemplate).withTintColor(textColor)
            let image = NSTextAttachment()
            image.image = img
            image.bounds = CGRect(x: 0, y: (font.capHeight - size).rounded() / 2, width: size, height: size)
            image.setImageHeight(height: size)
            let imgString = NSAttributedString(attachment: image)
            attributedText.append(imgString)
            
            if title != "" {
                attributedText.append(NSAttributedString(string: " "))
            }
        }
        
        attributedText.append(NSAttributedString(string: "\(title)" , attributes:[NSAttributedString.Key.font:font , NSAttributedString.Key.foregroundColor:textColor]))
        
        return attributedText
    }

}
