//
//  FilterCollectionViewCell.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    
    override var isSelected: Bool {
        didSet{
            overlayView.layer.borderColor = isSelected ? UIColor.white.cgColor : UIColor.clear.cgColor
            filterName.textColor = isSelected ? .white : .gray
            
        }
    }
    
    let image:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.translatesAutoresizingMaskIntoConstraints = false
        img.layer.cornerRadius = 5
        img.image = UIImage(named: "demo")
        img.clipsToBounds = true
        return img
    }()
    
    let overlayView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 5
        v.layer.borderWidth = 2
        v.layer.borderColor = UIColor.clear.cgColor
        return v
    }()
    
    let filterName:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Effect 1"
        l.textColor = .gray
        l.font = UIFont(name: "Avenir-Heavy", size: 14)
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(image)
        addSubview(overlayView)
        addSubview(filterName)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            image.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            image.widthAnchor.constraint(equalToConstant: 70),
            image.heightAnchor.constraint(equalToConstant: 70),
            image.centerXAnchor.constraint(equalTo: centerXAnchor),
            
            overlayView.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            overlayView.widthAnchor.constraint(equalToConstant: 70),
            overlayView.heightAnchor.constraint(equalToConstant: 70),
            overlayView.centerXAnchor.constraint(equalTo: centerXAnchor),
            
            filterName.topAnchor.constraint(equalTo: image.bottomAnchor, constant: 4),
            filterName.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
