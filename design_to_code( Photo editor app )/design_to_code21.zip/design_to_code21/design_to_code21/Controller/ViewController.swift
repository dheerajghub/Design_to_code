//
//  ViewController.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let backgroundImage:UIImageView = {
        let img = UIImageView()
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "demo")
        img.translatesAutoresizingMaskIntoConstraints = false
        return img
    }()
    
    lazy var expandingNavView:CustomExpandingNavView = {
        let v = CustomExpandingNavView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.delegate = self
        v.backgroundColor = UIColor(white: 0, alpha: 0.8)
        return v
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(backgroundImage)
        backgroundImage.pin(to: view)
        view.addSubview(expandingNavView)
        setUpConstraints()
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            expandingNavView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            expandingNavView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            expandingNavView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            expandingNavView.heightAnchor.constraint(equalToConstant: 260),
        ])
    }
}
