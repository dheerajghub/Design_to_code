//
//  Constants.swift
//  design_to_code21
//
//  Created by Dheeraj Kumar Sharma on 30/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct Colors {
    static let appBlack = UIColor(red: 54/255, green: 54/255, blue: 54/255, alpha: 1)
    static let appGray = UIColor(red: 180/255, green: 180/255, blue: 180/255, alpha: 1)
}
