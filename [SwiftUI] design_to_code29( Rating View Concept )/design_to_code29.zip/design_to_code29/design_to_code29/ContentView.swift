//
//  ContentView.swift
//  design_to_code29
//
//  Created by Dheeraj Kumar Sharma on 11/04/21.
//

import SwiftUI

struct ContentView: View {
    
    // MARK:- PROPERTIES
    @State var scaleEffect1: CGFloat = 0
    @State var scaleEffect2: CGFloat = 0
    
    // MARK:- BODY
    
    var body: some View {
        ZStack {
            Color.init(red: 238/255, green: 241/255, blue: 243/255)
                .ignoresSafeArea()
            RatingCardView(scaleEffect1: $scaleEffect1 , scaleEffect2: $scaleEffect2 )
                .padding(30)
                .frame(width: 370)
                .background(Color.white)
                .cornerRadius(20)
                .shadow(color: Color.init(red: 0, green: 0, blue: 0, opacity: 0.1) , radius: 20 , x: 10 , y: 20)
            Circle()
                .fill(Color.init(red: 236/255, green: 61/255, blue: 107/255))
                .frame(width: 45, height: 45)
                .scaleEffect(scaleEffect1)
            Circle()
                .fill(Color.init(red: 243/255, green: 163/255, blue: 186/255))
                .frame(width: 45, height: 45)
                .scaleEffect(scaleEffect2)
        } //: ZSTACK
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
