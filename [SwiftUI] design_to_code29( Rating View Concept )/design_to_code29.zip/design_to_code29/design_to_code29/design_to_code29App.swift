//
//  design_to_code29App.swift
//  design_to_code29
//
//  Created by Dheeraj Kumar Sharma on 11/04/21.
//

import SwiftUI

@main
struct design_to_code29App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
