//
//  emojiView.swift
//  design_to_code29
//
//  Created by Dheeraj Kumar Sharma on 11/04/21.
//

import SwiftUI

struct emojiView: View {
    
    // MARK:- PROPERTIES
    
    @Binding var selectedEmoji: String
    var emojiText: String
    
    // MARK:- BODY
    var body: some View {
        Button {
            withAnimation(.spring(response:0.3, dampingFraction: 0.5)){
                selectedEmoji = emojiText
            }
            
        } label:{
            Text(emojiText)
                .font(Font.custom("Avenir", size: 23))
        }
    }
}

//struct emojiView_Previews: PreviewProvider {
//    static var previews: some View {
//        emojiView(emojiText: "😗", selectedEmoji: "😖")
//    }
//}
