//
//  ListMonthHeaderCollectionReusableView.swift
//  justDesign5
//
//  Created by Dheeraj Kumar Sharma on 19/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ListMonthHeaderCollectionReusableView: UICollectionReusableView {
        
    let monthHeaderView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .red
        v.layer.cornerRadius = 30
        v.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner]
        return v
    }()
    
    let monthLabel:UILabel = {
        let l = UILabel()
        l.textColor = .white
        l.font = UIFont(name: "Avenir-black", size: 17)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let eventCount:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.font = UIFont(name: "Avenir-Medium", size: 17)
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(monthHeaderView)
        monthHeaderView.addSubview(monthLabel)
        addSubview(eventCount)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            monthHeaderView.widthAnchor.constraint(equalToConstant: 90),
            monthHeaderView.leadingAnchor.constraint(equalTo: leadingAnchor),
            monthHeaderView.heightAnchor.constraint(equalToConstant: 60),
            monthHeaderView.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            monthLabel.centerYAnchor.constraint(equalTo: monthHeaderView.centerYAnchor),
            monthLabel.centerXAnchor.constraint(equalTo: monthHeaderView.centerXAnchor),
            
            eventCount.centerYAnchor.constraint(equalTo: centerYAnchor),
            eventCount.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
