//
//  EventListCollectionViewCell.swift
//  justDesign5
//
//  Created by Dheeraj Kumar Sharma on 19/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class EventListCollectionViewCell: UICollectionViewCell {
    
    var data:EventList?{
        didSet{
            manageData()
        }
    }
    
    let dayLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        l.textAlignment = .center
        return l
    }()
    
    let eventImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.cornerRadius = 8
        return img
    }()
    
    let eventTitle:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Avenir-Black", size: 17)
        return l
    }()
    
    let beginningLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.text = "Beginning"
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let beginningTime:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .darkGray
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let endLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.text = "End"
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let endTime:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .darkGray
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let locationLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.text = "Location"
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let locationPlace:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .darkGray
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(dayLabel)
        addSubview(eventImage)
        addSubview(eventTitle)
        addSubview(beginningLabel)
        addSubview(endLabel)
        addSubview(locationLabel)
        addSubview(beginningTime)
        addSubview(endTime)
        addSubview(locationPlace)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            dayLabel.leadingAnchor.constraint(equalTo: leadingAnchor , constant: 35),
            dayLabel.topAnchor.constraint(equalTo: topAnchor, constant: 30),
            
            eventImage.leadingAnchor.constraint(equalTo: dayLabel.trailingAnchor, constant: 35),
            eventImage.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            eventImage.widthAnchor.constraint(equalToConstant: 100),
            eventImage.heightAnchor.constraint(equalToConstant: 150),
            
            eventTitle.leadingAnchor.constraint(equalTo: eventImage.trailingAnchor, constant: 20),
            eventTitle.topAnchor.constraint(equalTo: topAnchor, constant: 40),
            
            beginningLabel.leadingAnchor.constraint(equalTo: eventImage.trailingAnchor, constant: 20),
            beginningLabel.topAnchor.constraint(equalTo: eventTitle.bottomAnchor , constant: 3),
            beginningLabel.widthAnchor.constraint(equalToConstant: 80),
            
            beginningTime.leadingAnchor.constraint(equalTo: beginningLabel.trailingAnchor, constant: 20),
            beginningTime.topAnchor.constraint(equalTo: eventTitle.bottomAnchor, constant: 3),
            
            endLabel.leadingAnchor.constraint(equalTo: eventImage.trailingAnchor, constant: 20),
            endLabel.topAnchor.constraint(equalTo: beginningLabel.bottomAnchor , constant: 3),
            endLabel.widthAnchor.constraint(equalToConstant: 80),
            
            endTime.leadingAnchor.constraint(equalTo: endLabel.trailingAnchor, constant: 20),
            endTime.topAnchor.constraint(equalTo: beginningTime.bottomAnchor, constant: 3),
            
            locationLabel.leadingAnchor.constraint(equalTo: eventImage.trailingAnchor, constant: 20),
            locationLabel.topAnchor.constraint(equalTo: endLabel.bottomAnchor , constant: 3),
            locationLabel.widthAnchor.constraint(equalToConstant: 80),
            
            locationPlace.leadingAnchor.constraint(equalTo: locationLabel.trailingAnchor, constant: 20),
            locationPlace.topAnchor.constraint(equalTo: endLabel.bottomAnchor, constant: 3)
        ])
    }
    
    func setUpDayLabel(_ date:Int, _ day:String){
        let attributedText = NSMutableAttributedString(string:"\(date)\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 15)!])
        attributedText.append(NSAttributedString(string: "\(day)" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 15)!, NSAttributedString.Key.foregroundColor: UIColor.lightGray]))
        dayLabel.attributedText = attributedText
    }
    
    func manageData(){
        guard let data = data else { return }
        setUpDayLabel(data.date, data.day)
        beginningTime.text = data.beginning
        endTime.text = data.end
        locationPlace.text = data.location
        eventImage.image = UIImage(named: data.image)
        eventTitle.text = data.title
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
