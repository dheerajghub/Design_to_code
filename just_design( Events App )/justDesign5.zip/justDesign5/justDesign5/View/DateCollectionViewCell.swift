//
//  DateCollectionViewCell.swift
//  justDesign5
//
//  Created by Dheeraj Kumar Sharma on 19/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    override var isSelected: Bool {
        didSet{
            cardView.backgroundColor = isSelected ? UIColor(white: 0, alpha: 0.03) : .clear
        }
    }
    
    let cardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 4
        return v
    }()
    
    let dateLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "6"
        l.font = UIFont(name: "Avenir-Medium", size: 19)
        return l
    }()
    
    let dayLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Sun"
        l.textColor = UIColor(white: 0, alpha: 0.4)
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        return l
    }()
    
    let presentLabel:UIView = {
        let v = UIView()
        v.backgroundColor = .red
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 2.5
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        addSubview(cardView)
        cardView.addSubview(dateLabel)
        cardView.addSubview(dayLabel)
        cardView.addSubview(presentLabel)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 5),
            cardView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -2),
            cardView.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            cardView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -5),
            
            dateLabel.centerXAnchor.constraint(equalTo: cardView.centerXAnchor),
            dateLabel.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 13),
            dayLabel.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 0),
            dayLabel.centerXAnchor.constraint(equalTo: cardView.centerXAnchor),
            
            presentLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -18),
            presentLabel.topAnchor.constraint(equalTo: cardView.topAnchor , constant: 10),
            presentLabel.heightAnchor.constraint(equalToConstant: 5),
            presentLabel.widthAnchor.constraint(equalToConstant: 5)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
