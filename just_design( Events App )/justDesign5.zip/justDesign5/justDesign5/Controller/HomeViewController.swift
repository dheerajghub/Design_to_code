//
//  HomeViewController.swift
//  justDesign5
//
//  Created by Dheeraj Kumar Sharma on 19/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct eventScroll {
    let row:Int!
    let section:Int!
}

enum State {
    case column
    case list
}

class HomeViewController: UIViewController {

    var currState:State!
    let toggleButton = UIButton(type: .system)
    
    var event:[eventScroll] = [
        eventScroll(row: 6, section: 0),
        eventScroll(row: 8, section: 0),
        eventScroll(row: 11, section: 1)
    ]
    
    let eventPoster = ["img1" , "img2", "img3"]
    
    let listView: ListView = {
        let v = ListView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        return v
    }()
    
    lazy var calendarView:CalendarView = {
        let v = CalendarView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.homeViewController = self
        return v
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.backgroundColor = .clear
        cv.setCollectionViewLayout(layout, animated: false)
        cv.register(EventCollectionViewCell.self, forCellWithReuseIdentifier: "EventCollectionViewCell")
        cv.delegate = self
        cv.dataSource = self
        cv.isPagingEnabled = true
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(calendarView)
        view.addSubview(collectionView)
        view.addSubview(listView)
        listView.pin(to: view)
        setUpConstraints()
        setUpCustomNavBar()
        currState = .column
        listView.isHidden = true
    }
    
    func setUpCustomNavBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.tintColor = UIColor.black
        
        let titleLabel = UILabel()
        titleLabel.text = "Upcoming Events"
        titleLabel.font = UIFont(name: "Avenir-Heavy", size: 23)
        titleLabel.sizeToFit()

        let leftItem = UIBarButtonItem(customView: titleLabel)
        self.navigationItem.leftBarButtonItem = leftItem
        
        toggleButton.setImage(UIImage(named: "list"), for: .normal)
        toggleButton.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: toggleButton)
        toggleButton.addTarget(self, action: #selector(toggleButtonPressed), for: .touchUpInside)
        
        let rightBarButtonItem = UIBarButtonItem()
        rightBarButtonItem.customView = toggleButton
        navigationItem.setRightBarButton(rightBarButtonItem, animated: false)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            calendarView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            calendarView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            calendarView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            calendarView.heightAnchor.constraint(equalToConstant: 80),
            
            collectionView.topAnchor.constraint(equalTo: calendarView.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    
    @objc func toggleButtonPressed(){
        if currState == .column {
            self.toggleButton.setImage(UIImage(named: "column"), for: .normal)
            self.listView.isHidden = false
            currState = .list
        } else if currState == .list {
            self.toggleButton.setImage(UIImage(named: "list"), for: .normal)
            self.listView.isHidden = true
            currState = .column
        }
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        let x = Int(targetContentOffset.pointee.x / collectionView.frame.width)
        let index = IndexPath(row: event[x].row, section: event[x].section)
        calendarView.collectionView.selectItem(at: index, animated: true, scrollPosition: .centeredHorizontally)
    }

}

extension HomeViewController:UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return eventPoster.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "EventCollectionViewCell", for: indexPath) as! EventCollectionViewCell
        cell.cardImage.image = UIImage(named: eventPoster[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

}
