//
//  HomeViewController.swift
//  design_to_code17
//
//  Created by Dheeraj Kumar Sharma on 03/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct ExpenseData {
    let img:String!
    let title:String!
    let date:String!
    let price:String!
}

class HomeViewController: UIViewController {
    
    var data:[ExpenseData]?
    
    let headerView:CustomHeaderView = {
        let v = CustomHeaderView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    lazy var bottomView:CustomBottomView = {
        let v = CustomBottomView()
        v.controller = self
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .clear
        return v
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsVerticalScrollIndicator = false
        cv.register(ExpensesCollectionViewCell.self, forCellWithReuseIdentifier: "ExpensesCollectionViewCell")
        cv.backgroundColor = .clear
        cv.setCollectionViewLayout(layout, animated: false)
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for family in UIFont.familyNames {
            let sName: String = family as String
            print("family: \(sName)")
                    
            for name in UIFont.fontNames(forFamilyName: sName) {
                print("name: \(name as String)")
            }
        }
        view.backgroundColor = CustomColor.appBackground
        view.addSubview(headerView)
        view.addSubview(bottomView)
        view.addSubview(collectionView)
        setUpConstraints()
        
        data = [
            ExpenseData(img: "img1", title: "Spotify", date: "Sep 4 - 12:30 PM", price: "- $ 11,99"),
            ExpenseData(img: "img2", title: "Spotify", date: "Sep 4 - 12:30 PM", price: "- $ 11,99"),
            ExpenseData(img: "img3", title: "Spotify", date: "Sep 4 - 12:30 PM", price: "- $ 11,99"),
            ExpenseData(img: "img4", title: "Spotify", date: "Sep 4 - 12:30 PM", price: "- $ 11,99"),
        ]
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 380),
            
            bottomView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bottomView.heightAnchor.constraint(equalToConstant: 100),
            bottomView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            collectionView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            collectionView.bottomAnchor.constraint(equalTo: bottomView.topAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    @objc func transferButtonPressed(){
        let VC = TransferViewController()
        VC.modalTransitionStyle = .crossDissolve
        VC.modalPresentationStyle = .fullScreen
        present(VC, animated: true, completion: nil)
    }

}

extension HomeViewController:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data!.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ExpensesCollectionViewCell", for: indexPath) as! ExpensesCollectionViewCell
        cell.data = data![indexPath.row]
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 70)
    }

}
