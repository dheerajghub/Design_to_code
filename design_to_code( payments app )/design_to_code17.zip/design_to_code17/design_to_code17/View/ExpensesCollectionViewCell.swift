//
//  ExpensesCollectionViewCell.swift
//  design_to_code17
//
//  Created by Dheeraj Kumar Sharma on 05/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ExpensesCollectionViewCell: UICollectionViewCell {
    
    var data:ExpenseData?{
        didSet{
            manageData()
        }
    }
    
    let imageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.backgroundColor = .white
        img.layer.cornerRadius = 20
        return img
    }()
    
    let descLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = CustomColor.customBlack
        l.numberOfLines = 0
        return l
    }()
    
    let priceLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Poppins-Medium", size: 17)
        l.textColor = CustomColor.customBlack
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imageView)
        addSubview(descLabel)
        addSubview(priceLabel)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            imageView.centerYAnchor.constraint(equalTo: centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 60),
            imageView.heightAnchor.constraint(equalToConstant: 60),
            
            descLabel.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 15),
            descLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            priceLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30),
            priceLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    func setAttributedText(_ title:String , _ date:String) -> NSAttributedString {
        let attributedText = NSMutableAttributedString(string:"\(title)\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Poppins-Medium", size: 15)!])
        attributedText.append(NSAttributedString(string: "\(date)" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Poppins-Medium", size: 13)!, NSAttributedString.Key.foregroundColor: UIColor.lightGray]))
        return attributedText
    }
    
    func manageData(){
        guard let data = data else {return}
        descLabel.attributedText = setAttributedText(data.title, data.date)
        priceLabel.text = data.price
        imageView.image = UIImage(named: data.img)?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = CustomColor.customBlack
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
