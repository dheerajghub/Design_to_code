//
//  Constants.swift
//  design_to_code17
//
//  Created by Dheeraj Kumar Sharma on 03/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomFont {
    static let anodinaExtraBold = "Anodina-ExtraBold"
}

struct CustomColor {
    static let customBlack = UIColor(red: 32/255, green: 30/255, blue: 42/255, alpha: 1)
    static let appBackground = UIColor(red: 239/255, green: 240/255, blue: 242/255, alpha: 1)
    
    static let gd1_1 = UIColor(red: 47/255, green: 128/255, blue: 237/255, alpha: 1)
    static let gd1_2 = UIColor(red: 86/255, green: 204/255, blue: 242/255, alpha: 1)
    
    static let gd2_1 = UIColor(red: 249/255, green: 212/255, blue: 35/255, alpha: 1)
    static let gd2_2 = UIColor(red: 230/255, green: 92/255, blue: 0/255, alpha: 1)
    
    static let gd3_1 = UIColor(red: 52/255, green: 148/255, blue: 230/255, alpha: 1)
    static let gd3_2 = UIColor(red: 236/255, green: 110/255, blue: 173/255, alpha: 1)
}
