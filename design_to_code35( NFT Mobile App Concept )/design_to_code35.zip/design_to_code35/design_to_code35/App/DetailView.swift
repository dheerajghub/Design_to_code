//
//  DetailView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct DetailView: View {
    
    // MARK: PROPERTIES -
    
    @Environment(\.presentationMode) var presentationMode
    @State private var showingSheet = false
    
    // MARK: BODY -
    
    var body: some View {
        ZStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading){
                    ZStack(alignment: .topLeading){
                        Image("card1")
                            .resizable()
                            .scaledToFill()
                            .frame(width: UIScreen.main.bounds.width, height: 430)
                            .clipped()
                        VStack {
                            Spacer()
                            CoverActionView()
                                .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
                                .offset(x: 0, y: 25)
                        } //: VSTACK
                        .frame(width: UIScreen.main.bounds.width, height: 430)
                    } //: ZSTACK
                    Text("The Treasure Keeper.")
                        .font(.system(size: 27, weight: .bold))
                        .foregroundColor(Colors.appText)
                        .padding(EdgeInsets(top: 50, leading: 25, bottom: 0, trailing: 25))
                    DescriptionView()
                    CurrentBid()
                    Spacer()
                } //: VSTACK
            } //: SCROLL
            .edgesIgnoringSafeArea(.all)
            VStack(alignment: .leading){
                HStack {
                    Button {
                        presentationMode.wrappedValue.dismiss()
                    } label: {
                        ZStack {
                            Rectangle()
                                .fill(Color.white)
                                .frame(width: 45, height: 45)
                                .cornerRadius(22.5)
                                .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 7)
                            Image("back")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 45, height: 45)
                        } //: ZSTACK
                    }
                    Spacer()
                } //: HSTACK
                .padding(EdgeInsets(top: 10, leading: 20, bottom: 0, trailing: 20))
                Spacer()
                
                ZStack {
                    Rectangle()
                        .fill(LinearGradient(gradient: Gradient(colors: [Color.white, Color.white.opacity(0)]), startPoint: .bottom, endPoint: .top))
                        .frame(height:120)
                    
                    Button {
                        self.showingSheet.toggle()
                    } label: {
                        ZStack {
                            Rectangle()
                                .fill(Color.black)
                                .frame(width: 160, height: 60)
                                .cornerRadius(30)
                                .shadow(color: .black.opacity(0.1), radius: 10, x: 0, y: 7)
                            Text("Place a Bid")
                                .foregroundColor(.white)
                                .font(.system(size: 15, weight: .bold))
                        }
                    }
                    .fullScreenCover(isPresented: $showingSheet, content: {
                        PlaceBidView()
                    })
                }
                
            } //: VSTACK
            .edgesIgnoringSafeArea(.bottom)
        } //: ZSTACK
    }
}

// MARK: PREVIEW -

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView()
    }
}
