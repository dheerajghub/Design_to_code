//
//  PlaceBidView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct PlaceBidView: View {
    
    // MARK: PROPERTIES -
    
    @Environment(\.presentationMode) var presentationMode
    
    // MARK: BODY -
    
    var body: some View {
        ZStack {
            ScrollView(.vertical, showsIndicators: false){
                VStack {
                    PlaceBidHeaderView()
                        .padding(EdgeInsets(top: 100, leading: 0, bottom: 0, trailing: 0))
                    PlaceBidHistoryView()
                    PlaceBidNoteView()
                }
            } //: SCROLL
            VStack {
                ZStack {
                    HStack {
                        Button {
                            presentationMode.wrappedValue.dismiss()
                        } label: {
                            ZStack {
                                Rectangle()
                                    .fill(Color.white)
                                    .frame(width: 45, height: 45)
                                    .cornerRadius(22.5)
                                    .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 7)
                                Image("back")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 45, height: 45)
                            } //: ZSTACK
                        }
                        Spacer()
                    } //: HSTACK
                    Text("Place a Bid")
                        .foregroundColor(Colors.appText)
                        .font(.system(size: 16, weight: .heavy))
                }
                .padding(EdgeInsets(top: 10, leading: 20, bottom: 0, trailing: 20))
                Spacer()
            }
        } //: ZSTACK
    }
}

struct PlaceBidView_Previews: PreviewProvider {
    static var previews: some View {
        PlaceBidView()
    }
}
