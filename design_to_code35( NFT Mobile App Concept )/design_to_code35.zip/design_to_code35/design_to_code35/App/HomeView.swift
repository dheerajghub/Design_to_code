//
//  HomeView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct HomeData: Hashable {
    let image: String
    let profile: String
}

struct HomeView: View {
    
    // MARK: PROPERTIES -
    
    @State private var showingSheet = false
    
    let data = [
        HomeData(image: "card1", profile: "pic1"),
        HomeData(image: "card2", profile: "pic2")
    ]
    
    // MARK: BODY -
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.04)
                .edgesIgnoringSafeArea(.all)
            ScrollView(.vertical, showsIndicators: false) {
                ForEach(data, id: \.self) { item in
                    Button {
                        self.showingSheet.toggle()
                    } label: {
                        CustomCardView(image: item.image, profile: item.profile)
                            .padding(EdgeInsets(top: 0, leading: 25, bottom: 0, trailing: 25))
                    }
                    .fullScreenCover(isPresented: $showingSheet, content: {
                        DetailView()
                    })
                }
                .padding(.top , 70)
            } //: SCROLL
            VStack {
                CustomNavBar()
                    .frame(height: 60)
                Spacer()
            } //: VSTACK
        } //: ZSTACK
    }
}

// MARK: PREVIEW -

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
