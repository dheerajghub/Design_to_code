//
//  DescriptionView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct DescriptionView: View {
    var body: some View {
        VStack(alignment: .leading){
            Text("description".uppercased())
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.gray.opacity(0.7))
            Text("Treasure Keeper is a series of 3 digital artsculptures from Freaky Feeder first audiovisual project \"Crowd of Reality\", first release in 2018")
                .foregroundColor(Colors.appText)
                .font(.system(size: 15, weight: .regular))
                .padding(.top , 10)
        }
        .padding(EdgeInsets(top: 20, leading: 25, bottom: 20, trailing: 25))
    }
}

struct DescriptionView_Previews: PreviewProvider {
    static var previews: some View {
        DescriptionView()
    }
}
