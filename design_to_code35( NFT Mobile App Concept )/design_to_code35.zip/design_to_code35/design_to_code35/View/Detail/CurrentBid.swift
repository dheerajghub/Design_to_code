//
//  CurrentBid.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct BidData: Hashable {
    let profile: String
    let name: String
    let value: String
}

struct CurrentBid: View {
    
    let data = BidData(profile: "pic1", name: "hypnopizza", value: "1.280")
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20){
            Text("current bid".uppercased())
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.gray.opacity(0.7))
            BidView(profile: data.profile, name: data.name, value: data.value)
        }
        .padding(EdgeInsets(top: 0, leading: 25, bottom: 20, trailing: 25))
    }
}

struct CurrentBid_Previews: PreviewProvider {
    static var previews: some View {
        CurrentBid()
    }
}
