//
//  BidView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct BidView: View {
    
    // MARK: PROPERTIES -
    
    var profile: String = ""
    var name: String = ""
    var value: String = ""
        
    // MARK: BODY -
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Colors.appBlue.opacity(0.06))
                .frame(height:75)
                .cornerRadius(8)
            HStack {
                ZStack {
                    Rectangle()
                        .fill(Color.black.opacity(0.03))
                        .frame(width: 40, height: 40)
                        .cornerRadius(20)
                    Image(profile)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 30, height: 30)
                        .clipped()
                        .cornerRadius(15)
                        .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 2)
                }
                
                VStack(alignment: .leading, spacing:6){
                    Text("Bid placed by")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(Colors.appText)
                    + Text(" \(name)")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(Colors.appBlue)
                    Text("April 25, 2021 at 10:08 am")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.gray.opacity(0.8))
                }
                .padding(.leading , 10)
                
                Spacer()
                Text("\(value) ETH")
                    .foregroundColor(Colors.appText)
                    .font(.system(size: 15, weight: .bold))
            } //: HSTACK
            .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
        } //: ZSTACK
    }
}

// MARK: PREVIEW -

struct BidView_Previews: PreviewProvider {
    static var previews: some View {
        BidView()
            .previewLayout(.sizeThatFits)
    }
}
