//
//  CoverActionView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct CoverActionView: View {
    var body: some View {
        HStack{
            HStack(alignment: .center, spacing: 7){
                ZStack {
                    Rectangle()
                        .fill(Color.white)
                        .frame(width: 40, height: 40)
                        .cornerRadius(20)
                        .shadow(color: .black.opacity(0.04), radius: 7, x: 0, y: 3)
                    Image("pic1")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 30, height: 30)
                        .clipped()
                        .cornerRadius(15)
                        .shadow(color: .black.opacity(0.04), radius: 7, x: 0, y: 3)
                } //: ZSTACK
                Text("Helloyola")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundColor(Colors.appText)
                
            } //: HSTACK
            .padding(EdgeInsets(top: 0, leading: 10, bottom: 0, trailing: 17))
            .frame(height: 50)
            .background(Color.white)
            .cornerRadius(25)
            .shadow(color: .black.opacity(0.1), radius: 15, x: 0, y: 4)
            Spacer()
            ZStack {
                Rectangle()
                    .fill(Color.white)
                    .frame(width: 50, height: 50)
                    .cornerRadius(25)
                    .shadow(color: .black.opacity(0.1), radius: 15, x: 0, y: 4)
                Image("share")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
            }
            
        } //: HSTACK
    }
}

struct CoverActionView_Previews: PreviewProvider {
    static var previews: some View {
        CoverActionView()
    }
}
