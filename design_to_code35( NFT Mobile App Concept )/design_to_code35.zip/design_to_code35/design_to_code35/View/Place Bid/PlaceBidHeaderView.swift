//
//  PlaceBidHeaderView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct PlaceBidHeaderView: View {
    var body: some View {
        VStack {
            HStack(spacing: 17){
                Image("card1")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 90, height: 90)
                    .cornerRadius(8)
                    .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 7)
                VStack(alignment: .leading , spacing: 8){
                    Text("The Treasure Keeper.")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundColor(Colors.appText)
                    Text("Complete all steps to confirm your identity as well as increase Paydila limits.")
                        .font(.system(size: 12, weight: .regular))
                        .foregroundColor(.gray.opacity(0.7))
                    Text("Created by Helloyola")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(Colors.appBlue)
                } //: VSTACK
            } //: HSTACK
            .padding(EdgeInsets(top: 0, leading: 25, bottom: 0, trailing: 25))
            
            ZStack {
                Rectangle()
                    .fill(Color.white)
                    .frame(height: 70)
                    .overlay(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.3), lineWidth: 0.6))
                HStack {
                    ZStack {
                        Rectangle()
                            .fill(Color.black.opacity(0.05))
                            .frame(width: 30, height: 30)
                            .cornerRadius(4)
                        Image("minus")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                    }
                    Spacer()
                    ZStack {
                        Rectangle()
                            .fill(Color.black.opacity(0.05))
                            .frame(width: 30, height: 30)
                            .cornerRadius(4)
                        Image("plus")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                    }
                }
                .padding(EdgeInsets(top: 0, leading: 25, bottom: 0, trailing: 25))
                
                HStack(alignment: .center, spacing: 15){
                    ZStack {
                        Rectangle()
                            .fill(Colors.appBlue.opacity(0.1))
                            .frame(width: 30, height: 30)
                            .cornerRadius(15)
                        Image("etherum")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                    }
                    Text("1.281 ETH")
                        .foregroundColor(Colors.appText)
                        .font(.system(size: 15, weight: .bold))
                }
            } //: ZSTACK
            .padding(EdgeInsets(top: 30, leading: 25, bottom: 0, trailing: 25))
            Text("You must bid at least 1.281 ETH 🔥")
                .foregroundColor(.gray.opacity(0.7))
                .font(.system(size: 12, weight: .regular))
        } //: VSTACK
    }
}

struct PlaceBidHeaderView_Previews: PreviewProvider {
    static var previews: some View {
        PlaceBidHeaderView()
    }
}
