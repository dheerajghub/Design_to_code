//
//  PlaceBidNoteView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct PlaceBidNoteView: View {
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.white)
                .frame(height: 80)
                .overlay(RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 0.6))
            HStack(alignment: .top, spacing: 10){
                Image("notes")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 25, height: 25)
                    .clipped()
                    .cornerRadius(12.5)
                VStack(alignment: .leading, spacing: 5){
                    Text("Notes...")
                        .foregroundColor(Colors.appText)
                        .font(.system(size: 13, weight: .bold))
                    Text("Placing this bid will start a 24 hour auction for the artwork. ")
                        .foregroundColor(.gray.opacity(0.7))
                        .font(.system(size: 11, weight: .medium))
                    + Text("Learn how out auction work.")
                        .foregroundColor(Colors.appBlue)
                        .font(.system(size: 11, weight: .bold))
                } //: VSTACK
                Spacer()
            } //: HSTACK
            .padding(EdgeInsets(top: 0, leading: 15, bottom: 0, trailing: 15))
        } //: ZSTACK
        .padding(EdgeInsets(top: 0, leading: 25, bottom: 0, trailing: 25))
    }
}

struct PlaceBidNoteView_Previews: PreviewProvider {
    static var previews: some View {
        PlaceBidNoteView()
    }
}
