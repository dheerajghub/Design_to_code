//
//  PlaceBidHistoryView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 06/06/21.
//

import SwiftUI

struct PlaceBidHistoryView: View {
    
    let data = [
        BidData(profile: "pic1", name: "hypnopizza", value: "1.280"),
        BidData(profile: "pic2", name: "persia", value: "1.180"),
        BidData(profile: "pic3", name: "stephenhut", value: "1.045")
    ]
    
    var body: some View {
        VStack(alignment: .leading){
            Text("history of bid".uppercased())
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.gray.opacity(0.7))
                .padding(.leading , 25)
            ForEach(data , id: \.self) { item in
                BidView(profile: item.profile, name: item.name, value: item.value)
            }
            .padding(EdgeInsets(top: 10, leading: 25, bottom: 0, trailing: 25))
        } //: VSTACK
        .padding(EdgeInsets(top: 20, leading: 0, bottom: 20, trailing: 0))
    }
}

struct PlaceBidHistoryView_Previews: PreviewProvider {
    static var previews: some View {
        PlaceBidHistoryView()
    }
}
