//
//  CreatorView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct CardInfoView: View {
    
    var title: String = ""
    var subTitle: String = ""
    var image: String = ""
    
    var body: some View {
        HStack(alignment: .center, spacing: 7){
            ZStack {
                Rectangle()
                    .fill(Color.white)
                    .frame(width: 40, height: 40)
                    .cornerRadius(20)
                    .shadow(color: .black.opacity(0.06), radius: 4, x: 0, y: 5)
                Image(image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30)
                    .cornerRadius(15)
                    .shadow(color: .black.opacity(0.1), radius: 4, x: 0, y: 5)
            } //: ZSTACK
            
            VStack(alignment: .leading , spacing: 2){
                Text(title)
                    .font(.system(size: 11, weight: .medium))
                    .foregroundColor(Color.gray)
                Text(subTitle)
                    .font(.system(size: 14, weight: .heavy))
                    .foregroundColor(Colors.appText)
            } //: VSTACK
            
        } //: HSTACK
    }
}

struct CreatorView_Previews: PreviewProvider {
    static var previews: some View {
        CardInfoView(title: "Creator", subTitle: "Helloyolaa", image: "demo")
            .previewLayout(.sizeThatFits)
    }
}
