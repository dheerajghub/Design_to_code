//
//  CustomNavBar.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct CustomNavBar: View {
    var body: some View {
        HStack {
            ZStack {
                Rectangle()
                    .fill(Color.white)
                    .frame(width: 45, height: 45)
                    .cornerRadius(22.5)
                    .shadow(color: .black.opacity(0.02), radius: 4, x: 0, y: 2)
                Image("menu")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 45, height: 45)
            }
            Spacer()
            ZStack {
                Rectangle()
                    .fill(Color.white)
                    .frame(width: 45, height: 45)
                    .cornerRadius(22.5)
                    .shadow(color: .black.opacity(0.02), radius: 4, x: 0, y: 2)
                Image("pic3")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 35, height: 35)
                    .cornerRadius(17.5)
                    .shadow(color: .black.opacity(0.02), radius: 3, x: 0, y: 1)
            }
        }
        .background(Color.clear)
        .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 20))
    }
}

struct CustomNavBar_Previews: PreviewProvider {
    static var previews: some View {
        CustomNavBar()
            .previewLayout(.sizeThatFits)
    }
}
