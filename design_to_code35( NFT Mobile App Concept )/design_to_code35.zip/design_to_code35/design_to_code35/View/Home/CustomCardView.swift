//
//  CustomCardView.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct CustomCardView: View {
    
    var image: String = "card1"
    var profile: String = "pic1"
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.white)
                .frame(width: UIScreen.main.bounds.width - 50, height: 440, alignment: .center)
                .cornerRadius(10)
                .shadow(color: Color.black.opacity(0.07), radius: 15, x: 0, y: 7)
            VStack(alignment: .center){
                Image(image)
                    .resizable()
                    .scaledToFill()
                    .frame(width: UIScreen.main.bounds.width - 80, height: 250, alignment: .center)
                    .clipped()
                    .cornerRadius(10)
                    .shadow(color: Color.black.opacity(0.1), radius: 20, x: 0, y: 20)
                Text("The Treasure Keeper.")
                    .font(.title2.weight(.heavy))
                    .foregroundColor(Colors.appText)
                    .frame(width: UIScreen.main.bounds.width - 100, alignment: .leading)
                    .padding(EdgeInsets(top: 15, leading: 0, bottom: 12, trailing: 0))
                HStack(alignment: .center){
                    CardInfoView(title: "Creator", subTitle: "Helloyolaa", image: profile)
                    Spacer()
                    CardInfoView(title: "Current bid", subTitle: "1.280 ETH", image: "etherum")
                }
                .padding(EdgeInsets(top: 0, leading: 25, bottom: 0, trailing: 25))
                ZStack {
                    Rectangle()
                        .fill(Color.black.opacity(0.02))
                        .frame(width: UIScreen.main.bounds.width - 50, height: 75, alignment: .center)
                        .padding(.top , 15)
                        .cornerRadius(10)
                    Text("Place a Bid")
                        .foregroundColor(Colors.appText)
                        .font(.system(size: 18, weight: .bold))
                        .padding(.top , 16)
                }
                Spacer()
            }
            .frame(width: UIScreen.main.bounds.width - 50, height: 480, alignment: .center)
        }
    }
}

struct CustomCardView_Previews: PreviewProvider {
    static var previews: some View {
        CustomCardView()
            .previewLayout(.sizeThatFits)
    }
}
