//
//  Constants.swift
//  design_to_code35
//
//  Created by Dheeraj Kumar Sharma on 05/06/21.
//

import SwiftUI

struct Colors {
    static var appBlue = Color.init(red: 10/255, green: 132/255, blue: 1)
    static var appText = Color.init(red: 5/255, green: 30/255, blue: 71/255)
}
