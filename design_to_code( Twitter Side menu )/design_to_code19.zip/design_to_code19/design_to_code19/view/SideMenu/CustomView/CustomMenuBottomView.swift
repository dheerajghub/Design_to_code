//
//  CustomMenuBottomView.swift
//  design_to_code19
//
//  Created by Dheeraj Kumar Sharma on 11/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomMenuBottomView: UIView {

    var delegate:MenuBarCollectionViewCell?
    
    let darkToggleBtn:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "dark")
        return img
    }()
    
    let qrCodeBtn:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "qrcode")
        return img
    }()
    
    let dividerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = CustomColors.appExtraLightGray
        v.alpha = 0
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(darkToggleBtn)
        addSubview(qrCodeBtn)
        addSubview(dividerView)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            darkToggleBtn.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 25),
            darkToggleBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            darkToggleBtn.widthAnchor.constraint(equalToConstant: 30),
            darkToggleBtn.heightAnchor.constraint(equalToConstant: 30),
            
            qrCodeBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -25),
            qrCodeBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            qrCodeBtn.widthAnchor.constraint(equalToConstant: 30),
            qrCodeBtn.heightAnchor.constraint(equalToConstant: 30),
            
            dividerView.topAnchor.constraint(equalTo: topAnchor),
            dividerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            dividerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            dividerView.heightAnchor.constraint(equalToConstant: 1)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
