//
//  CustomMenuHeaderView.swift
//  design_to_code19
//
//  Created by Dheeraj Kumar Sharma on 11/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomMenuHeaderView: UIView {

    var delegate:MenuBarCollectionViewCell?
    
    let imageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.image = UIImage(named: "demo")
        img.layer.cornerRadius = 30
        return img
    }()
    
    let userDetail:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        l.textColor = CustomColors.appBlack
        return l
    }()
    
    let moreBtn:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "more")
        return img
    }()
    
    let dividerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = CustomColors.appExtraLightGray
        v.alpha = 0
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imageView)
        addSubview(userDetail)
        addSubview(moreBtn)
        addSubview(dividerView)
        setUpConstraints()
        setUpAttributes()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 25),
            imageView.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            imageView.widthAnchor.constraint(equalToConstant: 60),
            imageView.heightAnchor.constraint(equalToConstant: 60),
            
            userDetail.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 25),
            userDetail.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 10),
            userDetail.trailingAnchor.constraint(equalTo: trailingAnchor, constant: 15),
            
            moreBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -25),
            moreBtn.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            moreBtn.widthAnchor.constraint(equalToConstant: 35),
            moreBtn.heightAnchor.constraint(equalToConstant: 35),
            
            dividerView.bottomAnchor.constraint(equalTo: bottomAnchor),
            dividerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            dividerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            dividerView.heightAnchor.constraint(equalToConstant: 1)
        ])
    }
    
    func setUpAttributes(){
        let attributedText = NSMutableAttributedString(string:"Dheeraj\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "HelveticaNeue-Bold", size: 23)!])
        
        attributedText.append(NSAttributedString(string: "@dheerajdev_twit\n\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "HelveticaNeue", size: 18)! , NSAttributedString.Key.foregroundColor: CustomColors.appDarkGray]))
        
        attributedText.append(NSAttributedString(string: "41" , attributes:[NSAttributedString.Key.font: UIFont(name: "HelveticaNeue", size: 18)!, NSAttributedString.Key.foregroundColor: UIColor.black]))
        
        attributedText.append(NSAttributedString(string: " Following  " , attributes:[NSAttributedString.Key.font: UIFont(name: "HelveticaNeue", size: 18)! , NSAttributedString.Key.foregroundColor: CustomColors.appDarkGray]))
        
        attributedText.append(NSAttributedString(string: "15" , attributes:[NSAttributedString.Key.font: UIFont(name: "HelveticaNeue", size: 18)!, NSAttributedString.Key.foregroundColor: UIColor.black]))
        
        attributedText.append(NSAttributedString(string: " Followers" , attributes:[NSAttributedString.Key.font: UIFont(name: "HelveticaNeue", size: 18)! , NSAttributedString.Key.foregroundColor: CustomColors.appDarkGray]))
        
        userDetail.attributedText = attributedText
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
