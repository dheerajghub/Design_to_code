//
//  MenuSimpleTableViewCell.swift
//  design_to_code19
//
//  Created by Dheeraj Kumar Sharma on 12/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class MenuSimpleTableViewCell: UITableViewCell {

    var data:SideMenuData?{
        didSet {
            manageData()
        }
    }
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.font = UIFont(name: "HelveticaNeue", size: 20)
        l.textColor = CustomColors.appBlack
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(titleLabel)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 25),
            titleLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
    }
    
    func manageData(){
        guard let data = data else {return}
        titleLabel.text = data.label
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
