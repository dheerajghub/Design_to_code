//
//  CustomNavHeaderView.swift
//  design_to_code19
//
//  Created by Dheeraj Kumar Sharma on 12/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomNavHeaderView: UIView {

    var delegate:HomeCollectionViewCell?{
        didSet{
            tapGes.addTarget(delegate, action: #selector(HomeCollectionViewCell.didImageTapped))
        }
    }
    
    let tapGes = UITapGestureRecognizer()
    
    let cardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let navTitle:UILabel = {
        let l = UILabel()
        l.text = "Home"
        l.font = UIFont(name: "HelveticaNeue-Bold", size: 19)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let userImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named:"demo")
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 15
        img.clipsToBounds = true
        img.isUserInteractionEnabled = true
        return img
    }()
    
    let dividerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = CustomColors.appExtraLightGray
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(cardView)
        cardView.addSubview(userImage)
        cardView.addSubview(navTitle)
        addSubview(dividerView)
        setUpConstraints()
        userImage.addGestureRecognizer(tapGes)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardView.leadingAnchor.constraint(equalTo: leadingAnchor),
            cardView.trailingAnchor.constraint(equalTo: trailingAnchor),
            cardView.topAnchor.constraint(equalTo: self.safeAreaLayoutGuide.topAnchor),
            cardView.bottomAnchor.constraint(equalTo:bottomAnchor),
            
            userImage.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20),
            userImage.centerYAnchor.constraint(equalTo: cardView.centerYAnchor), 
            userImage.widthAnchor.constraint(equalToConstant: 30),
            userImage.heightAnchor.constraint(equalToConstant: 30),
            
            dividerView.bottomAnchor.constraint(equalTo: bottomAnchor),
            dividerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            dividerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            dividerView.heightAnchor.constraint(equalToConstant: 0.7),
            
            navTitle.centerYAnchor.constraint(equalTo: cardView.centerYAnchor),
            navTitle.centerXAnchor.constraint(equalTo: cardView.centerXAnchor),
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
