//
//  Protocols.swift
//  design_to_code19
//
//  Created by Dheeraj Kumar Sharma on 12/09/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//


protocol SideMenuToggle {
    func sideMenu()
}
