//
//  CardDetailsCollectionViewCell.swift
//  justDesign7
//
//  Created by Dheeraj Kumar Sharma on 26/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CardDetailsCollectionViewCell: UICollectionViewCell {
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Card details"
        l.textColor = .white
        l.font = UIFont(name: "Avenir-Medium", size: 24)
        return l
    }()
    
    let stackView:UIStackView = {
        let sv = UIStackView()
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.distribution = .fillEqually
        sv.spacing = 10
        sv.axis = .horizontal
        return sv
    }()
    
    let incomeView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let incomeImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.layer.cornerRadius = 15
        img.contentMode = .scaleAspectFill
        img.backgroundColor = CustomColors.stoneGray
        img.image = UIImage(named: "arrowDown")
        img.clipsToBounds = true
        return img
    }()
    
    let incomeLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.numberOfLines = 0
        let attributedText = NSMutableAttributedString(string:"Income\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 12)!])
        attributedText.append(NSAttributedString(string: "$5,600" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 19)!, NSAttributedString.Key.foregroundColor: UIColor.white]))
        l.attributedText = attributedText
        return l
    }()
    
    let expenseView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let expenseImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.layer.cornerRadius = 15
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "arrowUp")
        img.backgroundColor = CustomColors.stoneGray
        img.clipsToBounds = true
        return img
    }()
    
    let expenseLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.numberOfLines = 0
        let attributedText = NSMutableAttributedString(string:"Expense\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 12)!])
        attributedText.append(NSAttributedString(string: "$1,200" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 19)!, NSAttributedString.Key.foregroundColor: UIColor.white]))
        l.attributedText = attributedText
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        addSubview(stackView)
        stackView.addArrangedSubview(incomeView)
        stackView.addArrangedSubview(expenseView)
        incomeView.addSubview(incomeImage)
        incomeView.addSubview(incomeLabel)
        expenseView.addSubview(expenseImage)
        expenseView.addSubview(expenseLabel)
        setUpConstraints()
        
        self.titleLabel.alpha = 0
        self.titleLabel.center.x += 50
        
        self.incomeImage.alpha = 0
        self.incomeImage.center.x += 50
        self.incomeLabel.alpha = 0
        self.incomeLabel.center.x += 80
        
        self.expenseImage.alpha = 0
        self.expenseImage.center.x += 50
        self.expenseLabel.alpha = 0
        self.expenseLabel.center.x += 80
        
        setUpAnimation()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            titleLabel.topAnchor.constraint(equalTo: topAnchor, constant: 10),
            stackView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            stackView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30),
            stackView.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 20),
            stackView.heightAnchor.constraint(equalToConstant: 60),
            
            incomeImage.leadingAnchor.constraint(equalTo: incomeView.leadingAnchor),
            incomeImage.widthAnchor.constraint(equalToConstant: 60),
            incomeImage.heightAnchor.constraint(equalToConstant: 60),
            incomeImage.centerYAnchor.constraint(equalTo: incomeView.centerYAnchor),
            
            incomeLabel.leadingAnchor.constraint(equalTo: incomeImage.trailingAnchor, constant: 20),
            incomeLabel.trailingAnchor.constraint(equalTo: incomeView.trailingAnchor, constant: -20),
            incomeLabel.centerYAnchor.constraint(equalTo: incomeView.centerYAnchor),
            
            expenseImage.leadingAnchor.constraint(equalTo: expenseView.leadingAnchor),
            expenseImage.widthAnchor.constraint(equalToConstant: 60),
            expenseImage.heightAnchor.constraint(equalToConstant: 60),
            expenseImage.centerYAnchor.constraint(equalTo: expenseView.centerYAnchor),
            
            expenseLabel.leadingAnchor.constraint(equalTo: expenseImage.trailingAnchor, constant: 20),
            expenseLabel.trailingAnchor.constraint(equalTo: expenseView.trailingAnchor, constant: -20),
            expenseLabel.centerYAnchor.constraint(equalTo: expenseView.centerYAnchor)
        ])
    }
    
    func setUpAnimation(){
        UIView.animate(withDuration: 1, delay: 0.2, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            
            self.titleLabel.alpha = 1
            self.titleLabel.center.x -= 50
            
            self.incomeImage.alpha = 1
            self.incomeImage.center.x -= 50
            self.incomeLabel.alpha = 1
            self.incomeLabel.center.x -= 80
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.3, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.expenseImage.alpha = 1
            self.expenseImage.center.x -= 50
            self.expenseLabel.alpha = 1
            self.expenseLabel.center.x -= 80
        }, completion: nil)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
