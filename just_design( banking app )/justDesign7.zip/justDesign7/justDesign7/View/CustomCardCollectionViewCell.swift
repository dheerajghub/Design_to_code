//
//  CustomCardCollectionViewCell.swift
//  justDesign7
//
//  Created by Dheeraj Kumar Sharma on 26/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomCardCollectionViewCell: UICollectionViewCell {
    
    var data:CustomCards?{
        didSet {
            manageData()
        }
    }
    
    let cardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .red
        v.layer.cornerRadius = 30
        return v
    }()
    
    let expView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 20
        v.backgroundColor = .white
        return v
    }()
    
    let cardLogoImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.layer.cornerRadius = 10
        img.image = UIImage(named: "img4")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let expLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        let attributedText = NSMutableAttributedString(string:"Month / year\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 12)!])
        attributedText.append(NSAttributedString(string: "06 / 20" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 16)!, NSAttributedString.Key.foregroundColor: CustomColors.appBackground]))
        l.attributedText = attributedText
        return l
    }()
    
    let amountLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Futura-Medium", size: 35)
        l.textColor = .white
        return l
    }()
    
    let accountNumberLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Avenir-Heavy", size: 17)
        l.textColor = .white
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(cardView)
        cardView.addSubview(expView)
        expView.addSubview(cardLogoImage)
        expView.addSubview(expLabel)
        cardView.addSubview(accountNumberLabel)
        cardView.addSubview(amountLabel)
        cardView.pin(to: self)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            expView.topAnchor.constraint(equalTo: cardView.topAnchor, constant: 30),
            expView.centerXAnchor.constraint(equalTo: cardView.centerXAnchor),
            expView.widthAnchor.constraint(equalToConstant: 160),
            expView.heightAnchor.constraint(equalToConstant: 70),
            
            cardLogoImage.leadingAnchor.constraint(equalTo: expView.leadingAnchor, constant: 15),
            cardLogoImage.heightAnchor.constraint(equalToConstant: 40),
            cardLogoImage.widthAnchor.constraint(equalToConstant: 40),
            cardLogoImage.centerYAnchor.constraint(equalTo: expView.centerYAnchor),
            
            expLabel.leadingAnchor.constraint(equalTo: cardLogoImage.trailingAnchor, constant: 10),
            expLabel.centerYAnchor.constraint(equalTo: expView.centerYAnchor),
            expLabel.trailingAnchor.constraint(equalTo: expView.trailingAnchor, constant: -10),
            
            accountNumberLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 30),
            accountNumberLabel.bottomAnchor.constraint(equalTo: amountLabel.topAnchor, constant: -5),
            amountLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 30),
            amountLabel.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -60)
        ])
    }
    
    func manageData(){
        guard let data = data else {return}
        cardView.backgroundColor = data.cardBackground
        cardLogoImage.image = UIImage(named: data.img)
        accountNumberLabel.text = data.cardNumber
        amountLabel.text = data.amount
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
