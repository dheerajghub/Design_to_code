//
//  FriendCollectionViewCell.swift
//  justDesign7
//
//  Created by Dheeraj Kumar Sharma on 26/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class FriendCollectionViewCell: UICollectionViewCell {
    
    let imageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img3")
        img.layer.cornerRadius = 20
        img.clipsToBounds = true
        return img
    }()
    
    let addView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = CustomColors.stoneGray
        v.layer.cornerRadius = 18
        return v
    }()
    
    let addImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(systemName: "plus")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = .white
        return img
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imageView)
        addSubview(addView)
        addView.addSubview(addImage)
        imageView.pin(to: self)
        addView.pin(to: self)
        NSLayoutConstraint.activate([
            addImage.centerYAnchor.constraint(equalTo: addView.centerYAnchor),
            addImage.centerXAnchor.constraint(equalTo: addView.centerXAnchor),
            addImage.widthAnchor.constraint(equalToConstant: 30),
            addImage.heightAnchor.constraint(equalToConstant: 30)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
