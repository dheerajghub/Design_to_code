//
//  OnboardingViewController.swift
//  justDesign7
//
//  Created by Dheeraj Kumar Sharma on 25/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class OnboardingViewController: UIViewController, UIViewControllerTransitioningDelegate {

    let transition = CircularTransition()
    
    let coloredLogoImage:UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "coloredLogo")
        img.translatesAutoresizingMaskIntoConstraints = false
        img.clipsToBounds = true
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    let stoneImage:UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "bottomStone")
        img.translatesAutoresizingMaskIntoConstraints = false
        img.clipsToBounds = true
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    let logoImage:UIImageView = {
        let img = UIImageView()
        img.image = UIImage(named: "logo")
        img.translatesAutoresizingMaskIntoConstraints = false
        img.clipsToBounds = true
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    let bankingLabel:UILabel = {
        let l = UILabel()
        l.text = "banking"
        l.textColor = .white
        l.font = UIFont(name: "AvenirNext-Medium", size: 35)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let descriptionLabel:UILabel = {
        let l = UILabel()
        l.text = "Get your daily banking process with in your mobile easily and safely."
        l.numberOfLines = 0
        l.textColor = .white
        l.font = UIFont(name: "AvenirNext-Medium", size: 20)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let getStartedBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.layer.borderColor = CustomColors.stoneGray.cgColor
        btn.layer.borderWidth = 1.5
        btn.layer.cornerRadius = 20
        btn.setImage(UIImage(named: "arrow")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.imageView?.tintColor = .white
        btn.addTarget(self, action: #selector(getStartedBtnPressed), for: .touchUpInside)
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = CustomColors.appBackground
        view.addSubview(coloredLogoImage)
        view.addSubview(stoneImage)
        view.addSubview(logoImage)
        view.addSubview(bankingLabel)
        view.addSubview(descriptionLabel)
        view.addSubview(getStartedBtn)
        setUpConstraints()
        
        coloredLogoImage.alpha = 0
        self.coloredLogoImage.transform = self.coloredLogoImage.transform.rotated(by: .pi / 3)
        
        self.stoneImage.alpha = 0
        self.stoneImage.transform = .init(scaleX: 0.5, y: 0.5)
        
        logoImage.alpha = 0
        logoImage.transform = logoImage.transform.rotated(by: -.pi / 3)
        
        descriptionLabel.alpha = 0
        descriptionLabel.center.y += 50
        
        bankingLabel.alpha = 0
        bankingLabel.center.y += 50
        
        self.getStartedBtn.alpha = 0
        
        setUpAnimations()
        
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return .lightContent
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            coloredLogoImage.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 100),
            coloredLogoImage.heightAnchor.constraint(equalToConstant: 450),
            coloredLogoImage.widthAnchor.constraint(equalToConstant: 450),
            coloredLogoImage.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            
            stoneImage.bottomAnchor.constraint(equalTo: view.bottomAnchor , constant: 15),
            stoneImage.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 130),
            stoneImage.heightAnchor.constraint(equalToConstant: 280),
            stoneImage.widthAnchor.constraint(equalToConstant: 280),
            
            logoImage.heightAnchor.constraint(equalToConstant: 70),
            logoImage.widthAnchor.constraint(equalToConstant: 70),
            logoImage.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            logoImage.bottomAnchor.constraint(equalTo: bankingLabel.topAnchor, constant: -20),
            
            bankingLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            bankingLabel.bottomAnchor.constraint(equalTo: descriptionLabel.topAnchor, constant: -15),
            
            descriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            descriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -50),
            descriptionLabel.bottomAnchor.constraint(equalTo: getStartedBtn.topAnchor, constant: -50),
            
            getStartedBtn.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 50),
            getStartedBtn.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -70),
            getStartedBtn.widthAnchor.constraint(equalToConstant: 65),
            getStartedBtn.heightAnchor.constraint(equalToConstant: 65)
        ])
    }
    
    func setUpAnimations(){
        
        UIView.animate(withDuration: 1.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.coloredLogoImage.alpha = 1
            self.coloredLogoImage.center.x -= 300
            self.coloredLogoImage.transform = self.coloredLogoImage.transform.rotated(by: -.pi / 3)
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.3, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.stoneImage.alpha = 1
            self.stoneImage.transform = .identity
        }, completion: nil)
        
        
        UIView.animate(withDuration: 0.8, delay: 0.5, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.logoImage.alpha = 1
            self.logoImage.center.y -= 50
            self.logoImage.transform = self.logoImage.transform.rotated(by: +.pi / 3)
        }, completion: nil)
        
        UIView.animate(withDuration: 0.8, delay: 0.6, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.bankingLabel.alpha = 1
            self.bankingLabel.center.y -= 50
        }, completion: nil)
        
        UIView.animate(withDuration: 0.8, delay: 0.64, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.descriptionLabel.alpha = 1
            self.descriptionLabel.center.y -= 50
        }, completion: nil)
        
        UIView.animate(withDuration: 0.8, delay: 0.7, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.getStartedBtn.alpha = 1
        }, completion: nil)
    }
    
    @objc func getStartedBtnPressed(){
        
        UIView.animate(withDuration: 1.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.coloredLogoImage.alpha = 0
            self.coloredLogoImage.center.x -= 400
            self.coloredLogoImage.transform = self.coloredLogoImage.transform.rotated(by: -.pi / 3)
        }, completion: nil)
        
        let VC = HomeViewController()
        let navVC = UINavigationController(rootViewController: VC)
        navVC.modalPresentationStyle = .custom
        navVC.transitioningDelegate = self
        self.present(navVC, animated: true, completion: nil)
    }
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .present
        transition.startingPoint = getStartedBtn.center
        transition.circleColor = .black
        
        return transition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .dismiss
        transition.startingPoint = getStartedBtn.center
        transition.circleColor = .black
        
        return transition
    }

    
}
