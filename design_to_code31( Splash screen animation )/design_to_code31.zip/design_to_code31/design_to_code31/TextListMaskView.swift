//
//  TextListMaskView.swift
//  design_to_code31
//
//  Created by Dheeraj Kumar Sharma on 01/05/21.
//

import SwiftUI

struct TextListMaskView: View {
    let arr = ["Just" , "Do" , "it." , ""]
    var body: some View {
        VStack(alignment: .center, spacing: 0){
            ForEach(arr, id: \.self) { item in
                if item != "" {
                    Text("\(item)".uppercased())
                        .font(.custom("Futura-CondensedExtraBold", size: 37))
                        .frame(width: 200, height: 60)
                        .multilineTextAlignment(.center)
                } else {
                    Image("nike")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 200, height: 60)
                        
                }
            }
        }
    }
}

struct TextListMaskView_Previews: PreviewProvider {
    static var previews: some View {
        TextListMaskView()
    }
}
