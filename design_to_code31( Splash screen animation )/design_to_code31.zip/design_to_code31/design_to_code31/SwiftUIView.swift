//
//  SwiftUIView.swift
//  design_to_code31
//
//  Created by Dheeraj Kumar Sharma on 01/05/21.
//

import SwiftUI

struct SwiftUIView: View {
    let gridLayout:[GridItem] =  Array(repeating: .init(.flexible(), spacing:10), count: 2)
    var body: some View {
        LazyVGrid(columns: gridLayout, spacing:10){
            ForEach((0...5) ,  id: \.self) { item in
                Rectangle()
                    .fill(Color.black.opacity(0.1))
                    .frame(height: (UIScreen.main.bounds.width - 30) / 2)
            }
        }
    }
}

struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}
