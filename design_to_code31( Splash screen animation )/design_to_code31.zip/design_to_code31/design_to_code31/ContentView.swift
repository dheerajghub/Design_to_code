//
//  ContentView.swift
//  design_to_code31
//
//  Created by Dheeraj Kumar Sharma on 01/05/21.
//

import SwiftUI


struct ContentView: View {
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var currOffset: CGFloat = 90
    @State var scale: CGFloat = 1
    @State var recWidth: CGFloat = 0
    @State var homeOpacity: Double = 0
    var body: some View {
        ZStack{
            Rectangle()
                .frame(width: 200, height: 60)
                .mask(
                    TextListMaskView()
                        .offset(y:currOffset)
                        .scaleEffect(scale)
                )
                .clipped()
                .onReceive(timer) { _ in
                    if currOffset != -90 {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                            currOffset -= 60
                        }
                    } else {
                        withAnimation(.spring(response:0.5 , dampingFraction:0.7)){
                            scale = 2
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                            recWidth = .infinity
                            homeOpacity = 1
                        }
                        self.timer.upstream.connect().cancel()
                    }
                }
            Rectangle()
                .fill(Color.black.opacity(0.8))
                .frame(width: recWidth)
                .animation(Animation.spring().delay(0.3))
            Rectangle()
                .fill(Color.black.opacity(1))
                .frame(width: recWidth)
                .animation(Animation.spring().delay(0.5))
            Rectangle()
                .fill(Color.white)
                .frame(width: recWidth)
                .animation(Animation.spring().delay(0.7))
            Rectangle()
                .frame(width: recWidth)
                .mask(
                    SwiftUIView()
                        .padding()
                )
                .opacity(homeOpacity)
                .animation(Animation.spring().delay(0.5))
        }
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
