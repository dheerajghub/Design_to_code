//
//  ContentView.swift
//  design_to_code33
//
//  Created by Dheeraj Kumar Sharma on 16/05/21.
//

import SwiftUI

struct OnboardData {
    let title: String
    let subTitle: String
    let img: String
}

struct ContentView: View {
    
    @State private var rotation: Double = -45
    @State private var viewOpacity: Double = 1
    @State private var titleOpacity: Double = 1
    @State private var titleOffset: CGFloat = 0
    @State private var subtitleOpacity: Double = 1
    @State private var subtitleOffset: CGFloat = 0
    @State private var index: Int = 0
    @State private var imageOpacity: Double = 1
    @State private var imageYOffset: CGFloat = 0
    @State private var imageXOffset: CGFloat = 0
    
    let data = [
        OnboardData(title: "Book Luxury Flights", subTitle: "Flights at your comfort, book 12\ntypes of flight from just one app.", img: "img1"),
        OnboardData(title: "Fast Procedure", subTitle: "Your Visa, Passport, Ticket, Hostels,\neverything in just one click.", img: "img2"),
        OnboardData(title: "Travel the world", subTitle: "", img: "img3")
    ]
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Colors.appPurple)
            Rectangle()
                .fill(Color.white)
                .frame(width: 900, height: 900)
                .cornerRadius(90)
                .rotationEffect(.degrees(rotation) , anchor: .bottomLeading)
                .offset(x: 900 / 2, y: -160)
                .opacity(viewOpacity)
                .animation(.spring(response: 1, dampingFraction: 0.85))
                .shadow(color: Color.black.opacity(0.1), radius: 35)
            VStack {
                Image(data[index].img)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 400, height: 350)
                    .offset(x: imageXOffset , y: imageYOffset)
                    .opacity(imageOpacity)
                Text(data[index].title)
                    .multilineTextAlignment(.center)
                    .font(Font.custom("Avenir-Black", size: 33))
                    .offset(y: titleOffset)
                    .opacity(titleOpacity)
                Text(data[index].subTitle)
                    .multilineTextAlignment(.center)
                    .font(Font.custom("Avenir-Roman", size: 18))
                    .padding(EdgeInsets(top: 10, leading: 0, bottom: 20, trailing: 0))
                    .offset(y: subtitleOffset)
                    .opacity(subtitleOpacity)
                Spacer()
                Button {
                    rotation += -360
                    withAnimation(.easeInOut(duration: 0.2)) {
                        viewOpacity = 0
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2, execute: {
                            self.viewOpacity = 1
                        })
                    }
                    
                    titleOffset = 30
                    titleOpacity = 0
                    subtitleOffset = 30
                    subtitleOpacity = 0
                    imageXOffset = 70
                    imageYOffset = 20
                    imageOpacity = 0
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: {
                        
                        withAnimation(Animation.easeInOut(duration:0.3).delay(0)) {
                            titleOffset = 0
                            titleOpacity = 1
                        }
                        withAnimation(Animation.easeInOut(duration:0.3).delay(0.3)) {
                            subtitleOffset = 0
                            subtitleOpacity = 1
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
                            withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                                imageYOffset = 0
                                imageXOffset = 0
                                imageOpacity = 1
                            }
                        })
                        
                        // Change the title as btn is being pressed
                        if index == (data.count - 1) {
                            index = 0
                        } else {
                            index += 1
                        }
                        
                    })
                    
                } label: {
                    ZStack {
                        Rectangle()
                            .fill(Colors.appRed)
                            .frame(width: 100, height: 100)
                            .cornerRadius(50)
                        Image("forward")
                            .resizable()
                            .renderingMode(.template)
                            .scaledToFill()
                            .frame(width: 25, height: 25)
                            .foregroundColor(.white)
                    }
                    .shadow(color: Color.black.opacity(0.1), radius: 35)
                }
            }
            .frame(width: 350 , height: 630)
//            .offset(y: -90.0)
            .padding(.bottom , 180)
            Text("Skip to login".uppercased())
                .font(Font.custom("Avenir-Roman", size: 15))
                .foregroundColor(.white)
                .offset(y: 350)
            
        }
        .edgesIgnoringSafeArea(.all)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
