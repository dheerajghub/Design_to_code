//
//  Constants.swift
//  design_to_code33
//
//  Created by Dheeraj Kumar Sharma on 16/05/21.
//

import SwiftUI

struct Colors {
    static let appPurple = Color(red: 107/255, green: 133/255, blue: 247/255)
    static let appRed = Color(red: 241/255, green: 129/255, blue: 90/255)
}
