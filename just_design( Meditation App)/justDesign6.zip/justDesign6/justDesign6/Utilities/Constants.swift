//
//  Constants.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 22/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColors {
    static let appGreen:UIColor = UIColor(red: 22/255, green: 78/255, blue: 89/255, alpha: 1)
    static let appYellow:UIColor = UIColor(red: 255/255, green: 209/255, blue: 0, alpha: 1)
    static let gridLightGray:UIColor = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
    static let appLightGray:UIColor = UIColor(red: 209/255, green: 209/255, blue: 209/255, alpha: 1)
    static let appCreamy:UIColor = UIColor(red: 232/255, green: 191/255, blue: 168/255, alpha: 1)
    static let appOrange:UIColor = UIColor(red: 194/255, green: 126/255, blue: 87/255, alpha: 1)
}
