//
//  StatisticsCollectionViewCell.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 23/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct StatsData{
    let img:String!
    let title:String!
    let subTitle:String!
}

class StatisticsCollectionViewCell: UICollectionViewCell {
    
    var statData:[StatsData] = [
        StatsData(img: "tvimg2", title: "Stress Level", subTitle: "45 % deacrease"),
        StatsData(img: "tvimg1", title: "Achieving goals", subTitle: "12 % increase")
    ]
    
    let statsLabel:UILabel = {
        let l = UILabel()
        l.text = "Statistics"
        l.font = UIFont(name: "AvenirNext-Bold", size: 28)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    lazy var tableView:UITableView = {
        let tv = UITableView()
        tv.delegate = self
        tv.dataSource = self
        tv.tableFooterView = UIView()
        tv.separatorStyle = .none
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.register(StatisticsTableViewCell.self, forCellReuseIdentifier: "StatisticsTableViewCell")
        return tv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(statsLabel)
        addSubview(tableView)
        setUpConstraints()
        
        self.statsLabel.alpha = 0
        self.statsLabel.center.y = +20
        self.tableView.alpha = 0
        self.tableView.center.y = +20
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            statsLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            statsLabel.topAnchor.constraint(equalTo: topAnchor, constant: 30),
            
            tableView.topAnchor.constraint(equalTo: statsLabel.bottomAnchor, constant: 15),
            tableView.leadingAnchor.constraint(equalTo: leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
    }
    
    func setUpAnimation(){
        UIView.animate(withDuration: 0.7, delay: 0.5, options: .curveEaseIn, animations: {
            self.statsLabel.alpha = 1
            self.statsLabel.center.y = -20
        }, completion:nil)
        
        UIView.animate(withDuration: 0.8, delay: 0.7, options: .curveEaseIn, animations: {
            self.tableView.alpha = 1
            self.tableView.center.y = -20
        }, completion:nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension StatisticsCollectionViewCell:UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return statData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StatisticsTableViewCell", for: indexPath) as! StatisticsTableViewCell
        cell.data = statData[indexPath.row]
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
}
