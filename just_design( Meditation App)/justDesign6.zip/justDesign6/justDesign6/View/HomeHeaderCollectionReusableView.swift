//
//  HomeHeaderCollectionReusableView.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 23/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class HomeHeaderCollectionReusableView: UICollectionReusableView {
        
    let headerBackImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "header")
        img.contentMode = .scaleAspectFill
        img.layer.maskedCorners = [.layerMinXMaxYCorner , .layerMaxXMaxYCorner]
        img.clipsToBounds = true
        return img
    }()
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.text = "Hi, Julia!"
        l.font = UIFont(name:"AvenirNext-Bold" , size: 35)
        l.textColor = .white
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let subtitleLabel:UILabel = {
        let l = UILabel()
        l.text = "Continue to work on your mental \nhealth and control all the sides of \nyour life"
        l.font = UIFont(name:"AvenirNext-Medium" , size: 18)
        l.textColor = UIColor(white: 1, alpha: 0.9)
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        addSubview(headerBackImage)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        setUpConstraints()
        
        self.headerBackImage.transform = .init(scaleX: 1.4, y: 1.4)
        self.titleLabel.center.y = +40
        self.subtitleLabel.center.y = +40
        self.titleLabel.alpha = 0
        self.subtitleLabel.alpha = 0
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            headerBackImage.leadingAnchor.constraint(equalTo: leadingAnchor),
            headerBackImage.trailingAnchor.constraint(equalTo: trailingAnchor),
            headerBackImage.topAnchor.constraint(equalTo: topAnchor),
            headerBackImage.bottomAnchor.constraint(equalTo: bottomAnchor),
            
            titleLabel.leadingAnchor.constraint(equalTo: leadingAnchor , constant: 30),
            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 15),
            subtitleLabel.leadingAnchor.constraint(equalTo: leadingAnchor , constant: 30),
            subtitleLabel.trailingAnchor.constraint(equalTo: trailingAnchor,constant: -30),
            subtitleLabel.bottomAnchor.constraint(equalTo: bottomAnchor,constant: -50)
            
        ])
    }
    
    func setUpAnimation(){
        
        UIView.animate(withDuration: 1.5, delay: 0.2, options:.curveEaseInOut, animations: {
            self.headerBackImage.transform = .init(scaleX: 1, y: 1)
            self.headerBackImage.layer.cornerRadius = 40
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.2, options:.curveEaseInOut, animations: {
            self.titleLabel.center.y = -40
            self.titleLabel.alpha = 1
        }, completion: nil)
        
        UIView.animate(withDuration: 1, delay: 0.4 , options:.curveEaseInOut, animations: {
            self.subtitleLabel.center.y = -40
            self.subtitleLabel.alpha = 1
        }, completion: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
