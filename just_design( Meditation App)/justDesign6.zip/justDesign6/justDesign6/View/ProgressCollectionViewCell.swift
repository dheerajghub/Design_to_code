//
//  ProgressCollectionViewCell.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 23/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit
import Charts

class ProgressCollectionViewCell: UICollectionViewCell, ChartViewDelegate {
    
    var weeks: [String]!
    var progress = [Double]()
    weak var axisFormatDelegate: IAxisValueFormatter?
    
    lazy var progressChart: BarChartView = {
        let chartView = BarChartView()
        chartView.animate(xAxisDuration: 1, easingOption: .easeInExpo)
        chartView.animate(yAxisDuration: 4, easingOption: .easeOutQuint)
        chartView.translatesAutoresizingMaskIntoConstraints = false
        chartView.leftAxis.enabled = false
        chartView.chartDescription?.enabled = false
        chartView.legend.enabled = false
        
        let yAxis = chartView.rightAxis
        yAxis.labelFont = UIFont(name: "AvenirNext-Bold", size: 13)!
        yAxis.setLabelCount(4, force: true)
        yAxis.labelTextColor = CustomColors.appLightGray
        yAxis.gridColor = CustomColors.gridLightGray
        yAxis.axisLineColor = CustomColors.gridLightGray
        yAxis.labelPosition = .outsideChart
        
        chartView.xAxis.labelPosition = .bottom
        chartView.xAxis.labelFont = UIFont(name: "AvenirNext-Bold", size: 13)!
        chartView.xAxis.setLabelCount(7, force: false)
        chartView.xAxis.labelTextColor = CustomColors.appLightGray
        chartView.xAxis.axisLineColor = CustomColors.gridLightGray
        chartView.xAxis.drawGridLinesEnabled = false
        chartView.xAxis.drawAxisLineEnabled = false
        
        chartView.delegate = self
        return chartView
    }()
    
    let progressLabel:UILabel = {
        let l = UILabel()
        l.text = "Your progress"
        l.font = UIFont(name: "AvenirNext-Bold", size: 28)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let weekLabel:UILabel = {
        let l = UILabel()
        l.text = "This Week"
        l.textColor = CustomColors.appOrange
        l.font = UIFont(name: "AvenirNext-DemiBold", size: 18)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(progressChart)
        addSubview(progressLabel)
        addSubview(weekLabel)
        setUpConstraints()
        
        axisFormatDelegate = self
        weeks = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]
        progress = [20.0, 15.0 ,15.0 ,20.0 ,25.0 ,18.0 ,5.0]
        setChart(dataEntryX: weeks, dataEntryY: progress)
        
        self.progressLabel.alpha = 0
        self.progressLabel.center.y = +20
        self.weekLabel.alpha = 0
        self.weekLabel.center.y = +20

    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            progressChart.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            progressChart.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            progressChart.topAnchor.constraint(equalTo: progressLabel.bottomAnchor, constant: 30),
            progressChart.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -10),
            
            progressLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            progressLabel.topAnchor.constraint(equalTo: topAnchor, constant: 40),
            
            weekLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30),
            weekLabel.topAnchor.constraint(equalTo: topAnchor, constant: 50)
        ])
    }
    
    func chartValueSelected(_ chartView: ChartViewBase, entry: ChartDataEntry, highlight: Highlight) {
        print(entry)
    }
    
    func setChart(dataEntryX forX:[String],dataEntryY forY: [Double]) {
        var dataEntries:[BarChartDataEntry] = []
        for i in 0..<forX.count{
            let dataEntry = BarChartDataEntry(x: Double(i), y: Double(forY[i]) , data: weeks as AnyObject?)
            dataEntries.append(dataEntry)
        }
        let chartDataSet = BarChartDataSet(entries: dataEntries, label: "")
        chartDataSet.colors = [CustomColors.appYellow, CustomColors.appCreamy, CustomColors.appGreen, CustomColors.appCreamy, CustomColors.appOrange, CustomColors.appYellow, CustomColors.appGreen]
        let chartData = BarChartData(dataSet: chartDataSet)
        chartData.setDrawValues(false)
        chartData.barWidth = 0.35
        progressChart.data = chartData
        let xAxisValue = progressChart.xAxis
        xAxisValue.valueFormatter = axisFormatDelegate

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpAnimation(){
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseIn, animations: {
            self.progressLabel.alpha = 1
            self.progressLabel.center.y = -20
            self.weekLabel.alpha = 1
            self.weekLabel.center.y = -20
        }, completion:nil)
    }
    
}

extension ProgressCollectionViewCell: IAxisValueFormatter {
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        return weeks[Int(value)]
    }
}
