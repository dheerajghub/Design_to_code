//
//  StatisticsTableViewCell.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 23/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class StatisticsTableViewCell: UITableViewCell {

    var data:StatsData?{
        didSet{
            manageData()
        }
    }
    
    let cellImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.backgroundColor = .lightGray
        img.layer.cornerRadius = 15
        img.clipsToBounds = true
        return img
    }()
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let arrowImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "arrow")?.withRenderingMode(.alwaysTemplate)
        img.tintColor = CustomColors.appLightGray
        img.layer.cornerRadius = 20
        return img
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        addSubview(cellImage)
        addSubview(titleLabel)
        addSubview(arrowImage)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cellImage.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            cellImage.centerYAnchor.constraint(equalTo: centerYAnchor),
            cellImage.heightAnchor.constraint(equalToConstant: 60),
            cellImage.widthAnchor.constraint(equalToConstant: 60),
            
            titleLabel.leadingAnchor.constraint(equalTo: cellImage.trailingAnchor, constant: 20),
            titleLabel.centerYAnchor.constraint(equalTo: centerYAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30),
            
            arrowImage.trailingAnchor.constraint(equalTo: trailingAnchor , constant: -30),
            arrowImage.centerYAnchor.constraint(equalTo: centerYAnchor),
            arrowImage.heightAnchor.constraint(equalToConstant: 30),
            arrowImage.widthAnchor.constraint(equalToConstant: 30)
        ])
    }
    
    func manageData(){
        guard let data = data else { return }
        cellImage.image = UIImage(named: data.img)
        setUpAttribute(data.title, data.subTitle)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpAttribute(_ title:String, _ subtitle:String){
        let attributedText = NSMutableAttributedString(string:"\(title)\n" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Heavy", size: 20)!])
        attributedText.append(NSAttributedString(string: "\(subtitle)" , attributes:
            [NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 15)!, NSAttributedString.Key.foregroundColor: UIColor.lightGray]))
        titleLabel.attributedText = attributedText
    }
    
}
