//
//  PracticeCollectionViewCell.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 23/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class PracticeCollectionViewCell: UICollectionViewCell {
    
    var data:PracticeData?{
        didSet{
            manageData()
        }
    }
    
    let cellImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.layer.cornerRadius = 17
        img.clipsToBounds = true
        return img
    }()
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.font = UIFont(name: "AvenirNext-Bold", size: 22)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let subtitleLabel:UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.textColor = .lightGray
        l.font = UIFont(name: "AvenirNext-Medium", size: 16)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let startNow:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("Start now ", for: .normal)
        btn.setImage(UIImage(systemName: "arrow.left")?.withRenderingMode(.alwaysTemplate), for: .normal)
        btn.imageView?.tintColor = CustomColors.appGreen
        btn.titleLabel?.font = UIFont(name: "AvenirNext-Medium", size: 18)
        btn.setTitleColor(CustomColors.appGreen, for: .normal)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame:frame)
        addSubview(cellImage)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(startNow)
        setUpConstraints()
        startNow.semanticContentAttribute = UIApplication.shared
        .userInterfaceLayoutDirection == .rightToLeft ? .forceLeftToRight : .forceRightToLeft
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cellImage.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            cellImage.heightAnchor.constraint(equalToConstant: 120),
            cellImage.widthAnchor.constraint(equalToConstant: 100),
            cellImage.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            titleLabel.leadingAnchor.constraint(equalTo: cellImage.trailingAnchor, constant: 25),
            titleLabel.topAnchor.constraint(equalTo: topAnchor, constant: 18),
            titleLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30),
            
            subtitleLabel.leadingAnchor.constraint(equalTo: cellImage.trailingAnchor, constant: 25),
            subtitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor),
            subtitleLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -30),
            
            startNow.leadingAnchor.constraint(equalTo: cellImage.trailingAnchor, constant: 25),
            startNow.topAnchor.constraint(equalTo: subtitleLabel.bottomAnchor, constant: 10)
        ])
    }
    
    func manageData(){
        guard let data = data else {return}
        cellImage.image = UIImage(named: data.img)
        titleLabel.text = data.title
        subtitleLabel.text = data.subTitle
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
