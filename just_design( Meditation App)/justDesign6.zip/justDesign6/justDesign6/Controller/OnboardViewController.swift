//
//  OnboardViewController.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 22/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class OnboardViewController: UIViewController, UIViewControllerTransitioningDelegate {

    let transition = CircularTransition()
    
    let backgroundImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img1")
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.text = "Every indivisual \nis unique."
        l.textColor = .black
        l.numberOfLines = 0
        l.font = UIFont(name: "AvenirNext-Bold", size: 50)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let subtitleLabel:UILabel = {
        let l = UILabel()
        l.text = "Start meditate to enhance objectivity and achieve the bravest goals"
        l.textColor = .black
        l.numberOfLines = 0
        l.font = UIFont(name: "AvenirNext-Medium", size: 24)
        l.translatesAutoresizingMaskIntoConstraints = false
        return l
    }()
    
    let getStartedBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = CustomColors.appGreen
        btn.layer.cornerRadius = 7
        btn.setTitle("Get Started", for: .normal)
        btn.titleLabel?.font = UIFont(name: "AvenirNext-Medium", size: 20)
        btn.setTitleColor(.white, for: .normal)
        btn.addTarget(self, action: #selector(getStartedPressed), for: .touchUpInside)
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(backgroundImage)
        view.addSubview(titleLabel)
        view.addSubview(subtitleLabel)
        view.addSubview(getStartedBtn)
        backgroundImage.pin(to: view)
        setUpConstraints()
        self.backgroundImage.transform = .init(scaleX: 1.4, y: 1.4)
        self.titleLabel.center.y = +50
        self.subtitleLabel.center.y = +50
        self.titleLabel.alpha = 0
        self.subtitleLabel.alpha = 0
        self.getStartedBtn.center.y = +30
        self.getStartedBtn.alpha = 0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        bringAnimation()
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            titleLabel.bottomAnchor.constraint(equalTo: subtitleLabel.topAnchor, constant: -15),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant:40),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            subtitleLabel.bottomAnchor.constraint(equalTo: getStartedBtn.topAnchor, constant: -50),
            subtitleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            subtitleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor , constant: -20),
            
            getStartedBtn.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            getStartedBtn.widthAnchor.constraint(equalToConstant: 200),
            getStartedBtn.heightAnchor.constraint(equalToConstant: 65),
            getStartedBtn.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -70),
        ])
    }
    
    func bringAnimation(){
        UIView.animate(withDuration: 1, delay: 0, options: .curveEaseInOut, animations: {
            self.backgroundImage.transform = .init(scaleX: 1, y: 1)
        }, completion: nil)
        
        UIView.animate(withDuration: 0.4, delay: 0.7, options: .curveEaseIn, animations: {
            self.titleLabel.alpha = 1
            self.titleLabel.center.y = -50
        }, completion: nil)
        
        UIView.animate(withDuration: 0.4, delay: 1, options: .curveEaseIn, animations: {
            self.subtitleLabel.alpha = 1
            self.subtitleLabel.center.y = -50
        }, completion: nil)
        
        UIView.animate(withDuration: 0.4, delay: 1.2, options:.curveEaseInOut, animations: {
            self.getStartedBtn.center.y = -30
            self.getStartedBtn.alpha = 1
        }, completion: nil)
        
        UIView.animate(withDuration: 0.4, delay: 0 , options:.curveEaseInOut, animations: {
            self.getStartedBtn.center.y = -30
            self.getStartedBtn.alpha = 1
        }, completion: nil)
    }
    
    @objc func getStartedPressed(){
        let VC = HomeViewController()
        let navVC = UINavigationController(rootViewController: VC)
        navVC.modalPresentationStyle = .custom
        navVC.transitioningDelegate = self
        present(navVC, animated: true, completion: nil)
    }
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .present
        transition.startingPoint = getStartedBtn.center
        transition.circleColor = .white
        
        return transition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .dismiss
        transition.startingPoint = getStartedBtn.center
        transition.circleColor = .white
        
        return transition
    }

}
