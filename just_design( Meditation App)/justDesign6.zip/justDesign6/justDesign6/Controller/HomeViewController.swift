//
//  HomeViewController.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 22/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UIViewControllerTransitioningDelegate {

    let transition = CircularTransition()
    let homeBtn = UIButton(type: .system)
    
    var animationCompleted:Bool = false
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.setCollectionViewLayout(layout, animated: false)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsVerticalScrollIndicator = false
        cv.backgroundColor = CustomColors.appGreen
        cv.delegate = self
        cv.dataSource = self
        cv.register(HomeHeaderCollectionReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HomeHeaderCollectionReusableView")
        cv.register(ProgressCollectionViewCell.self, forCellWithReuseIdentifier: "ProgressCollectionViewCell")
        cv.register(StatisticsCollectionViewCell.self, forCellWithReuseIdentifier: "StatisticsCollectionViewCell")
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = CustomColors.appGreen
        view.addSubview(collectionView)
        setUpNavigationBar()
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor)
        ])
    }
    
    func setUpNavigationBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.backgroundColor = CustomColors.appGreen
        
        homeBtn.setImage(UIImage(named: "home")?.withRenderingMode(.alwaysTemplate), for: .normal)
        homeBtn.tintColor = CustomColors.appYellow
        homeBtn.frame = CGRect(x: 0, y: 0, width: 50, height: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: homeBtn)
        homeBtn.addTarget(self, action: #selector(homeBtnPressed), for: .touchUpInside)
        
        let searchBtn = UIButton(type: .system)
        searchBtn.setImage(UIImage(named: "search")?.withRenderingMode(.alwaysTemplate), for: .normal)
        searchBtn.tintColor = .white
        searchBtn.frame = CGRect(x: 0, y: 0, width: 40, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchBtn)
        
        let saveBtn = UIButton(type: .system)
        saveBtn.setImage(UIImage(named: "bookmark")?.withRenderingMode(.alwaysTemplate), for: .normal)
        saveBtn.tintColor = .white
        saveBtn.frame = CGRect(x: 0, y: 0, width: 40, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: saveBtn)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = homeBtn
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
        
        let rightBarButtonItem1 = UIBarButtonItem()
        rightBarButtonItem1.customView = saveBtn
        let rightBarButtonItem2 = UIBarButtonItem()
        rightBarButtonItem2.customView = searchBtn
        navigationItem.setRightBarButtonItems([rightBarButtonItem1 , rightBarButtonItem2], animated: true)
        
    }
    
    @objc func homeBtnPressed(){
        let VC = DailyPracticeViewController()
        let navVC = UINavigationController(rootViewController: VC)
        navVC.modalPresentationStyle = .custom
        navVC.transitioningDelegate = self
        present(navVC, animated: true, completion: nil)
    }

    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .present
        transition.startingPoint = homeBtn.center
        transition.circleColor = .white
        
        return transition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        transition.transitionMode = .dismiss
        transition.startingPoint = homeBtn.center
        transition.circleColor = .white
        
        return transition
    }
    
}

extension HomeViewController:UICollectionViewDelegateFlowLayout , UICollectionViewDelegate , UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        switch kind {
            case UICollectionView.elementKindSectionHeader:
                let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HomeHeaderCollectionReusableView", for: indexPath) as! HomeHeaderCollectionReusableView
                if !animationCompleted {
                    header.setUpAnimation()
                }
                animationCompleted = true
                return header
            default:
                return UICollectionReusableView()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProgressCollectionViewCell", for: indexPath) as! ProgressCollectionViewCell
            cell.setUpAnimation()
            cell.backgroundColor = .white
            return cell
        }
        if indexPath.row == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StatisticsCollectionViewCell", for: indexPath) as! StatisticsCollectionViewCell
            cell.setUpAnimation()
            cell.backgroundColor = .white
            return cell
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 300)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 250)
    }
    
}
