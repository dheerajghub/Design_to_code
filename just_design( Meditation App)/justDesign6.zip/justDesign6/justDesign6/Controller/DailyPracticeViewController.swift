//
//  DailyPracticeViewController.swift
//  justDesign6
//
//  Created by Dheeraj Kumar Sharma on 23/07/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct PracticeData {
    let title:String!
    let subTitle:String!
    let img:String!
}

class DailyPracticeViewController: UIViewController {

    var practiceData:[PracticeData] = [
        PracticeData(title: "Morning Intention", subTitle: "Tune your mind body and soul and let them work together.", img: "img2"),
        PracticeData(title: "Find a confidence", subTitle: "Reduce fear, anxiety, stress and neagtive thoughts.", img: "img3"),
        PracticeData(title: "Unwind after work", subTitle: "Decreases in the brain cell volume in amygdala.", img: "img4"),
        PracticeData(title: "Always say \"Yes\"", subTitle: "Decreases in the brain cell volume in amygdala.", img: "img5")
    ]
    
    let headerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let headerLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Daily practices"
        l.font = UIFont(name: "AvenirNext-Bold", size: 35)
        return l
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .vertical
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.setCollectionViewLayout(layout, animated: false)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsVerticalScrollIndicator = false
        cv.backgroundColor = .white
        cv.delegate = self
        cv.dataSource = self
        cv.register(PracticeCollectionViewCell.self, forCellWithReuseIdentifier: "PracticeCollectionViewCell")
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(headerView)
        headerView.addSubview(headerLabel)
        view.addSubview(collectionView)
        setUpConstraints()
        setUpNavigationBar()
    }
    
    func setUpNavigationBar(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.backgroundColor = .white
        
        let backBtn = UIButton(type: .system)
        backBtn.setImage(UIImage(named: "navArrow")?.withRenderingMode(.alwaysTemplate), for: .normal)
        backBtn.tintColor = .black
        backBtn.frame = CGRect(x: 0, y: 0, width: 50, height: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backBtn)
        backBtn.addTarget(self, action: #selector(backBtnPressed), for: .touchUpInside)
        
        let searchBtn = UIButton(type: .system)
        searchBtn.setImage(UIImage(named: "search")?.withRenderingMode(.alwaysTemplate), for: .normal)
        searchBtn.tintColor = .black
        searchBtn.frame = CGRect(x: 0, y: 0, width: 40, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchBtn)
        
        let saveBtn = UIButton(type: .system)
        saveBtn.setImage(UIImage(named: "bookmark")?.withRenderingMode(.alwaysTemplate), for: .normal)
        saveBtn.tintColor = .black
        saveBtn.frame = CGRect(x: 0, y: 0, width: 40, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: saveBtn)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = backBtn
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
        
        let rightBarButtonItem1 = UIBarButtonItem()
        rightBarButtonItem1.customView = saveBtn
        let rightBarButtonItem2 = UIBarButtonItem()
        rightBarButtonItem2.customView = searchBtn
        navigationItem.setRightBarButtonItems([rightBarButtonItem1 , rightBarButtonItem2], animated: true)
        
    }
    
    @objc func backBtnPressed(){
        dismiss(animated: true, completion: nil)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            headerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            headerView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 70),
            
            headerLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            headerLabel.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 30),
            
            collectionView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

}

extension DailyPracticeViewController:UICollectionViewDelegate, UICollectionViewDataSource , UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return practiceData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PracticeCollectionViewCell", for: indexPath) as! PracticeCollectionViewCell
        cell.data = practiceData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, 0, 50, 0)
        cell.layer.transform = rotationTransform
        cell.alpha = 0
        UIView.animate(withDuration: 0.75, delay: 0, options: .curveEaseIn, animations: {
            cell.layer.transform = CATransform3DIdentity
            cell.alpha = 1.0
        }, completion: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 150)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
}
