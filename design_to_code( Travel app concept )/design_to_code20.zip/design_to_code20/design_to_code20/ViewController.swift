//
//  ViewController.swift
//  design_to_code20
//
//  Created by Dheeraj Kumar Sharma on 21/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemRed
    }

}

