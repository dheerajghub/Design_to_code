//
//  CardCollectionViewCell.swift
//  design_to_code20
//
//  Created by Dheeraj Kumar Sharma on 21/10/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CardCollectionViewCell: UICollectionViewCell {
    
    let cardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 20
        v.backgroundColor = .white
        v.layer.masksToBounds = true
        return v
    }()
    
    let imageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "demo")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let placeLabel:UILabel = {
        let l = UILabel()
        l.text = "DOMINICIAN REPUBLIC"
        l.textColor = .white
        l.font = UIFont.systemFont(ofSize: 40, weight: .bold)
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        return l
    }()
    
    let timeLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "1.12.2020 - 26.12.2020"
        l.font = UIFont.systemFont(ofSize: 17, weight: .semibold)
        l.textColor = .white
        return l
    }()
    
    let overlayCard:UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 0, alpha: 0.3)
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let bottomCardView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        return v
    }()
    
    let userImage1:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "demo")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.borderColor = UIColor.white.cgColor
        img.layer.borderWidth = 3
        img.layer.cornerRadius = 17.5
        return img
    }()
    
    let userImage2:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "demo")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        img.layer.borderColor = UIColor.white.cgColor
        img.layer.borderWidth = 3
        img.layer.cornerRadius = 17.5
        return img
    }()
    
    let statusLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "1 day until departure"
        l.textColor = .darkGray
        l.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(cardView)
        cardView.addSubview(imageView)
        cardView.addSubview(overlayCard)
        cardView.addSubview(bottomCardView)
        
        bottomCardView.addSubview(userImage1)
        bottomCardView.addSubview(userImage2)
        bottomCardView.addSubview(statusLabel)
        
        cardView.addSubview(placeLabel)
        cardView.addSubview(timeLabel)
        cardView.pin(to: self)
        overlayCard.pin(to: cardView)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            
            imageView.topAnchor.constraint(equalTo: cardView.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: bottomCardView.topAnchor),
            imageView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor),
            
            bottomCardView.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
            bottomCardView.bottomAnchor.constraint(equalTo: cardView.bottomAnchor),
            bottomCardView.trailingAnchor.constraint(equalTo: cardView.trailingAnchor),
            bottomCardView.heightAnchor.constraint(equalToConstant: 70),
            
            placeLabel.bottomAnchor.constraint(equalTo: timeLabel.topAnchor, constant: -5),
            placeLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20),
            placeLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -20),
            
            timeLabel.bottomAnchor.constraint(equalTo: bottomCardView.topAnchor,constant: -10),
            timeLabel.leadingAnchor.constraint(equalTo: cardView.leadingAnchor, constant: 20),
            
            userImage1.trailingAnchor.constraint(equalTo: bottomCardView.trailingAnchor, constant: -15),
            userImage1.heightAnchor.constraint(equalToConstant: 35),
            userImage1.widthAnchor.constraint(equalToConstant: 35),
            userImage1.centerYAnchor.constraint(equalTo: bottomCardView.centerYAnchor),
            
            userImage2.trailingAnchor.constraint(equalTo: userImage1.trailingAnchor, constant: -20),
            userImage2.heightAnchor.constraint(equalToConstant: 35),
            userImage2.widthAnchor.constraint(equalToConstant: 35),
            userImage2.centerYAnchor.constraint(equalTo: bottomCardView.centerYAnchor),
            
            statusLabel.centerYAnchor.constraint(equalTo: bottomCardView.centerYAnchor),
            statusLabel.leadingAnchor.constraint(equalTo: bottomCardView.leadingAnchor, constant: 20)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
