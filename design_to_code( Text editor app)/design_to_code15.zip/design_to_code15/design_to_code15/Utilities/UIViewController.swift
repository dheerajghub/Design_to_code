//
//  UIViewController.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

extension UIViewController {
    
    func createGradientLayer(colors:[CGColor], view:UIView) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.bounds
        gradientLayer.colors = colors
        view.layer.addSublayer(gradientLayer)
    }
    
}
