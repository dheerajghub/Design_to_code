//
//  Constant.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct CustomColors {
    static let gd1_color1 = UIColor(red: 33/255, green: 147/255, blue: 176/255, alpha: 1)
    static let gd1_color2 = UIColor(red: 109/255, green: 213/255, blue: 237/255, alpha: 1)
    static let gd2_color1 = UIColor(red: 195/255, green: 55/255, blue: 100/255, alpha: 1)
    static let gd2_color2 = UIColor(red: 29/255, green: 38/255, blue: 113/255, alpha: 1)
    static let gd3_color1 = UIColor(red: 67/255, green: 198/255, blue: 172/255, alpha: 1)
    static let gd3_color2 = UIColor(red: 248/255, green: 255/255, blue: 174/255, alpha: 1)
    static let gd4_color1 = UIColor(red: 52/255, green: 148/255, blue: 230/255, alpha: 1)
    static let gd4_color2 = UIColor(red: 236/255, green: 110/255, blue: 173/255, alpha: 1)
    static let lightBlue = UIColor(red: 78/255, green: 174/255, blue: 255/255, alpha: 1)
    
}

struct CustomFont {
    static let font1 = "BeautifulPeoplePersonalUse"
    static let font2 = "Edge-of-the-Galaxy-Poster"
    static let font3 = "LinoleoScript"
    static let font4 = "TypoGraphica"
    static let font5 = "MoongladeDEMO-Bold"
    static let font6 = "StarJediOutline"
    static let font7 = "DeadpoolOutline"
}
