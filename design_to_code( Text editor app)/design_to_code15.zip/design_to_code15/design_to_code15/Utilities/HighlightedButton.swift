//
//  HighlightedButton.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class HighlightedButton: UIButton {

    override var isHighlighted: Bool {
        didSet {
            isHighlighted ? doGlowAnimation(withColor: UIColor.white) : doGlowAnimation(withColor: UIColor.clear)
        }
    }
}
