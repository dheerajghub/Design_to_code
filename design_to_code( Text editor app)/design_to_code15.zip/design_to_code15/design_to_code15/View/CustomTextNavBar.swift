//
//  CustomTextNavBar.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomTextNavBar: UIView {
    
    var controller:TextFontViewController?{
        didSet {
            doneBtn.addTarget(controller, action: #selector(TextFontViewController.donePressed), for: .touchUpInside)
            positionBtn.addTarget(controller, action: #selector(TextFontViewController.positionBtnPressed), for: .touchUpInside)
            bottomBarToggle.addTarget(controller, action: #selector(TextFontViewController.bottomBarTogglePressed), for: .touchUpInside)
        }
    }
    
    let doneBtn:HighlightedButton = {
        let btn = HighlightedButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("Done", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .bold)
        return btn
    }()
    
    let stackView:UIStackView = {
        let v = UIStackView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.distribution = .fillEqually
        v.spacing = 20
        v.axis = .horizontal
        return v
    }()
    
    let positionBtn:HighlightedButton = {
        let btn = HighlightedButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "align-left"), for: .normal)
        return btn
    }()
    
    let bottomBarToggle:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "color"), for: .normal)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(doneBtn)
        addSubview(stackView)
        stackView.addArrangedSubview(positionBtn)
        stackView.addArrangedSubview(bottomBarToggle)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            doneBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            doneBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            doneBtn.widthAnchor.constraint(equalToConstant: 60),
            doneBtn.heightAnchor.constraint(equalToConstant: 40),
            
            stackView.centerYAnchor.constraint(equalTo: centerYAnchor),
            stackView.widthAnchor.constraint(equalToConstant: 80),
            stackView.heightAnchor.constraint(equalToConstant: 30),
            stackView.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
