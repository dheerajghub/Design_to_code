//
//  CustomFontView.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 24/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

protocol FontSelectionDelegate {
    func didSelectFont(_ fontName:String)
}

class CustomFontView: UIView {

    var delegate:FontSelectionDelegate?
    var controller:TextFontViewController?
    
    let fonts:[UIFont] = [
        UIFont(name: CustomFont.font1, size: 14)!,
        UIFont(name: CustomFont.font2, size: 19)!,
        UIFont(name: CustomFont.font3, size: 30)!,
        UIFont(name: CustomFont.font4, size: 18)!,
        UIFont(name: CustomFont.font5, size: 18)!,
        UIFont(name: CustomFont.font6, size: 20)!,
        UIFont(name: CustomFont.font7, size: 20)!
    ]
    
    let fontName = [ CustomFont.font1, CustomFont.font2, CustomFont.font3, CustomFont.font4, CustomFont.font5, CustomFont.font6, CustomFont.font7 ]
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.register(FontCollectionViewCell.self, forCellWithReuseIdentifier: "FontCollectionViewCell")
        cv.backgroundColor = .clear
        cv.setCollectionViewLayout(layout, animated: false)
        cv.delegate = self
        cv.dataSource = self
        cv.delaysContentTouches = false
        let insets = ((UIScreen.main.bounds.width/2) - 25)
        cv.contentInset = UIEdgeInsets(top: 0, left:insets , bottom: 0, right: insets)
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        collectionView.pin(to: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension CustomFontView:UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return fonts.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FontCollectionViewCell", for: indexPath) as! FontCollectionViewCell
        cell.fontText.font = fonts[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 45, height: 45)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.selectItem(at: indexPath, animated: true, scrollPosition: .centeredHorizontally)
        delegate?.didSelectFont(fontName[indexPath.row])
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
}
