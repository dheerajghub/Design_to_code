//
//  ColorCollectionViewCell.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 24/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class ColorCollectionViewCell: UICollectionViewCell {
    
    let colorView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .black
        v.layer.borderColor = UIColor.white.cgColor
        v.layer.borderWidth = 2
        v.layer.cornerRadius = 15
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(colorView)
        colorView.pin(to: self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
