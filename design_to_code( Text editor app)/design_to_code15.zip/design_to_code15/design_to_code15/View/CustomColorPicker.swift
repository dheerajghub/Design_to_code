//
//  CustomColorPicker.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 24/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

protocol SelectedColor {
    func didColorSelected(_ color: UIColor)
}

class CustomColorPicker: UIView {

    var delegate:SelectedColor?
    let colorSet = [UIColor.white, UIColor.black, UIColor.blue, UIColor.green, UIColor.yellow, UIColor.orange, UIColor.red, UIColor.systemPink, UIColor.purple,UIColor.brown, UIColor.gray, UIColor.lightGray, UIColor.darkGray]
    
    let selectedColor:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.layer.borderColor = UIColor.white.cgColor
        v.layer.borderWidth = 2
        v.layer.cornerRadius = 20
        return v
    }()
    
    let pickerImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "dropper")
        return img
    }()
    
    lazy var collectionView:UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.showsHorizontalScrollIndicator = false
        cv.register(ColorCollectionViewCell.self, forCellWithReuseIdentifier: "ColorCollectionViewCell")
        cv.backgroundColor = .clear
        cv.setCollectionViewLayout(layout, animated: false)
        cv.delegate = self
        cv.dataSource = self
        cv.delaysContentTouches = false
        cv.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(selectedColor)
        selectedColor.addSubview(pickerImage)
        addSubview(collectionView)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            selectedColor.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            selectedColor.centerYAnchor.constraint(equalTo: centerYAnchor),
            selectedColor.widthAnchor.constraint(equalToConstant: 40),
            selectedColor.heightAnchor.constraint(equalToConstant: 40),
            
            collectionView.leadingAnchor.constraint(equalTo: selectedColor.trailingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: trailingAnchor),
            collectionView.heightAnchor.constraint(equalToConstant: 40),
            collectionView.centerYAnchor.constraint(equalTo: centerYAnchor),
            
            pickerImage.widthAnchor.constraint(equalToConstant: 25),
            pickerImage.heightAnchor.constraint(equalToConstant: 25),
            pickerImage.centerYAnchor.constraint(equalTo: selectedColor.centerYAnchor),
            pickerImage.centerXAnchor.constraint(equalTo: selectedColor.centerXAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension CustomColorPicker:UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return colorSet.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ColorCollectionViewCell", for: indexPath) as! ColorCollectionViewCell
        cell.colorView.backgroundColor = colorSet[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 30, height: 30)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.didColorSelected(colorSet[indexPath.row])
        if indexPath.row == 0 {
            pickerImage.image = UIImage(named: "dropper")?.withRenderingMode(.alwaysTemplate)
            pickerImage.tintColor = .black
        } else {
            pickerImage.image = UIImage(named: "dropper")?.withRenderingMode(.alwaysTemplate)
            pickerImage.tintColor = .white
        }
        selectedColor.backgroundColor = colorSet[indexPath.row]
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
}
