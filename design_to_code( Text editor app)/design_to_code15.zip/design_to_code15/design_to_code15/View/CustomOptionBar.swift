//
//  CustomOptionBar.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomOptionBar: UIView {
    
    let colorSet:[[CGColor]] = [
        [UIColor.lightGray.cgColor , UIColor.lightGray.cgColor],
        [UIColor.darkGray.cgColor , UIColor.darkGray.cgColor],
        [CustomColors.gd1_color1.cgColor , CustomColors.gd1_color2.cgColor],
        [CustomColors.gd2_color1.cgColor , CustomColors.gd2_color2.cgColor],
        [CustomColors.gd3_color1.cgColor , CustomColors.gd3_color2.cgColor],
        [CustomColors.gd4_color1.cgColor , CustomColors.gd4_color2.cgColor]
    ]
    var colorCode = 0
    var controller:CreateViewController? {
        didSet{
            fontButton.addTarget(controller, action: #selector(CreateViewController.AddTextPressed), for: .touchUpInside)
            saveBtn.addTarget(controller, action: #selector(CreateViewController.saveBtnPressed), for: .touchUpInside)
        }
    }
    
    lazy var changeBackgroundBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.layer.borderColor = UIColor.white.cgColor
        btn.layer.borderWidth = 2.5
        btn.layer.cornerRadius = 15
        btn.layer.masksToBounds = true
        btn.backgroundColor = .lightGray
        btn.addTarget(self, action: #selector(changeBackPressed), for: .touchUpInside)
        btn.doGlowAnimation(withColor: UIColor.white)
        return btn
    }()

    let fontButton:HighlightedButton = {
        let btn = HighlightedButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("Aa", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 25, weight: .bold)
        btn.setTitleColor(.white, for: .normal)
        return btn
    }()
    
    let saveBtn:HighlightedButton = {
        let btn = HighlightedButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "download"), for: .normal)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(changeBackgroundBtn)
        addSubview(fontButton)
        addSubview(saveBtn)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            
            saveBtn.trailingAnchor.constraint(equalTo: changeBackgroundBtn.leadingAnchor, constant: -15),
            saveBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            saveBtn.heightAnchor.constraint(equalToConstant: 30),
            saveBtn.widthAnchor.constraint(equalToConstant: 30),
            
            changeBackgroundBtn.trailingAnchor.constraint(equalTo: fontButton.leadingAnchor, constant: -15),
            changeBackgroundBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            changeBackgroundBtn.heightAnchor.constraint(equalToConstant: 30),
            changeBackgroundBtn.widthAnchor.constraint(equalToConstant: 30),
            
            fontButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            fontButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            fontButton.heightAnchor.constraint(equalToConstant: 30),
            fontButton.widthAnchor.constraint(equalToConstant: 35)
        ])
    }
    
    @objc func changeBackPressed(){
        
        if colorSet.count > colorCode + 1 {
            colorCode += 1
        } else {
            colorCode = 0
        }
        createGradientLayer(colors: colorSet[colorCode], view: changeBackgroundBtn)
        createGradientLayer(colors: colorSet[colorCode], view: controller!.createView)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
