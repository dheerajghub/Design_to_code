//
//  CreateViewController.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

struct textViewProperties {
    let font:UIFont!
    let fontColor:UIColor!
    let text:String!
    let height:CGFloat!
    let alignment:NSTextAlignment!
    let width:CGFloat!
}

class CreateViewController: UIViewController {
    
    var textViewData:[textViewProperties]?
    
    let createView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .lightGray
        return v
    }()
    
    lazy var optionsBar:CustomOptionBar = {
        let v = CustomOptionBar()
        v.controller = self
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let deletebox:UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(white: 1, alpha: 0.2)
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 22.5
        v.layer.shadowColor = UIColor(white: 0, alpha: 0.4).cgColor
        v.layer.shadowOffset = CGSize(width: 0, height: 6)
        v.layer.shadowRadius = 10
        v.layer.shadowOpacity = 1
        return v
    }()
    
    let deleteImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "delete")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(createView)
        view.addSubview(optionsBar)
        view.addSubview(deletebox)
        deletebox.addSubview(deleteImage)
        deleteImage.pin(to: deletebox)
        setUpConstraints()
        deletebox.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        createGradientLayer(colors: optionsBar.colorSet[0], view: createView)
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            createView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            createView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            createView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            createView.topAnchor.constraint(equalTo: view.topAnchor),
            
            optionsBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            optionsBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            optionsBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            optionsBar.heightAnchor.constraint(equalToConstant: 60),
            
            deletebox.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            deletebox.widthAnchor.constraint(equalToConstant: 45),
            deletebox.heightAnchor.constraint(equalToConstant: 45),
            deletebox.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }
    
    func dynamicTextViews(_ data:[textViewProperties]?){
        guard let data = data else {return}
        for i in 0..<data.count {
            let customTextView:UITextView = {
                let v = UITextView()
                v.translatesAutoresizingMaskIntoConstraints = false
                v.text = data[i].text
                v.delegate = self
                v.font = data[i].font
                v.textColor = data[i].fontColor
                v.textAlignment = data[i].alignment
                v.isEditable = false
                v.backgroundColor = .clear
                v.autocorrectionType = .no
                v.isScrollEnabled = false
                v.isSelectable = false
                return v
            }()
            
            view.addSubview(customTextView)
            customTextView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
            customTextView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
            customTextView.widthAnchor.constraint(equalToConstant: data[i].width).isActive = true
            customTextView.heightAnchor.constraint(equalToConstant: data[i].height).isActive = true
            
            //add pan gesture
            let gestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(handlePan))
            gestureRecognizer.delegate = self
            customTextView.addGestureRecognizer(gestureRecognizer)

            //Enable multiple touch and user interaction for textfield
            customTextView.isUserInteractionEnabled = true
            customTextView.isMultipleTouchEnabled = true

            //add pinch gesture
            let pinchGesture = UIPinchGestureRecognizer(target: self, action:#selector(pinchRecognized(pinch:)))
            pinchGesture.delegate = self
            customTextView.addGestureRecognizer(pinchGesture)

            //add rotate gesture.
            let rotate = UIRotationGestureRecognizer.init(target: self, action: #selector(handleRotate(recognizer:)))
            rotate.delegate = self
            customTextView.addGestureRecognizer(rotate)
        }
        
    }
    
    @objc func AddTextPressed(_ sender:UIButton){
        let VC = TextFontViewController()
        VC.modalPresentationStyle = .overFullScreen
        VC.modalTransitionStyle = .crossDissolve
        VC.delegate = self
        present(VC, animated: true, completion: nil)
    }
    
    @objc func saveBtnPressed(){
        self.optionsBar.isHidden = true
        let image = view.takeScreenshot()
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(self.image(_:didFinishSavingWithError:contextInfo:)), nil)
        self.optionsBar.isHidden = false
    }
    
    @objc func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // we got back an error!
            let ac = UIAlertController(title: "Save error", message: error.localizedDescription, preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default))
            present(ac, animated: true)
        } else {
            let ac = UIAlertController(title: "Saved!", message: "Your story has been saved to your photos.", preferredStyle: .alert)
            ac.addAction(UIAlertAction(title: "OK", style: .default , handler: {
                (UIAlertAction) -> Void in
            }))
            present(ac, animated: true)
        }
    }
}

extension CreateViewController:UITextViewDelegate, UIGestureRecognizerDelegate,TextFontDelegate {
    
    func didDataSent(_ data: textViewProperties) {
        self.textViewData?.append(data)
        var textViewD = [textViewProperties]()
        let d = textViewProperties(font: data.font, fontColor: data.fontColor, text: data.text, height: data.height, alignment: data.alignment, width: data.width)
        textViewD.append(d)
        dynamicTextViews(textViewD)
    }
    
    @objc func handlePan(_ gestureRecognizer: UIPanGestureRecognizer) {
        if gestureRecognizer.state == .began || gestureRecognizer.state == .changed {
            deletebox.isHidden = false
            let translation = gestureRecognizer.translation(in: self.view)
            // note: 'view' is optional and need to be unwrapped
            gestureRecognizer.view!.center = CGPoint(x: gestureRecognizer.view!.center.x + translation.x, y: gestureRecognizer.view!.center.y + translation.y)
            gestureRecognizer.setTranslation(CGPoint.zero, in: self.view)
            if gestureRecognizer.view!.frame.intersects(deletebox.frame) {
                UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                    gestureRecognizer.view!.transform = .init(scaleX: 0.6, y: 0.6)
                    self.deletebox.transform = .init(scaleX: 1.2, y: 1.2)
                }, completion: nil)
            } else {
                gestureRecognizer.view!.setNeedsDisplay()
                gestureRecognizer.setTranslation(.zero, in: self.view)
                UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                    self.deletebox.transform = .identity
                    gestureRecognizer.view!.transform = .identity
                }, completion: nil)
            }
        }
        
        if gestureRecognizer.state == .ended {
            if gestureRecognizer.view!.frame.intersects(deletebox.frame) {
                gestureRecognizer.view!.isHidden = true
            } else {
                gestureRecognizer.view!.setNeedsDisplay()
                gestureRecognizer.setTranslation(.zero, in: self.view)
                gestureRecognizer.view!.transform = .identity
            }
            deletebox.isHidden = true
        }

    }

    @objc func pinchRecognized(pinch: UIPinchGestureRecognizer) {

        if let view = pinch.view {
            view.transform = view.transform.scaledBy(x: pinch.scale, y: pinch.scale)
            pinch.scale = 1
        }
    }

    @objc func handleRotate(recognizer : UIRotationGestureRecognizer) {
        if let view = recognizer.view {
            view.transform = view.transform.rotated(by: recognizer.rotation)
            recognizer.rotation = 0
        }
    }

    //MARK:- UIGestureRecognizerDelegate Methods
    func gestureRecognizer(_: UIGestureRecognizer,
        shouldRecognizeSimultaneouslyWith shouldRecognizeSimultaneouslyWithGestureRecognizer:UIGestureRecognizer) -> Bool {
        return true
    }
    
}
