//
//  TextFontViewController.swift
//  design_to_code15
//
//  Created by Dheeraj Kumar Sharma on 23/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

enum BottomBarStates{
    case color
    case font
}

protocol TextFontDelegate {
    func didDataSent(_ data:textViewProperties)
}

class TextFontViewController: UIViewController{
    
    var delegate:TextFontDelegate?
    var state:BottomBarStates?
    var count = 0
    let position = ["align-left" , "align-center" , "align-right"]
    var bottomConstraint: NSLayoutConstraint?
    
    lazy var navBar:CustomTextNavBar = {
        let v = CustomTextNavBar()
        v.controller = self
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let customTextViewBox:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .clear
        return v
    }()
    
    let sliderView:UISlider = {
        let s = UISlider()
        s.translatesAutoresizingMaskIntoConstraints = false
        s.minimumValue = 30
        s.value = 30
        s.maximumValue = 50
        s.tintColor = .white
        s.addTarget(self, action: #selector(fontChange), for: UIControl.Event.valueChanged)
        return s
    }()
    
    lazy var customTextView:UITextView = {
        let tf = UITextView()
        tf.translatesAutoresizingMaskIntoConstraints = false
        tf.tintColor = CustomColors.lightBlue
        tf.font = UIFont.systemFont(ofSize: 30)
        tf.textColor = .white
        tf.backgroundColor = .clear
        tf.delegate = self
        tf.isScrollEnabled = false
        tf.adjustsFontForContentSizeCategory = true
        tf.textAlignment = .left
        tf.autocorrectionType = .no
        return tf
    }()
    
    let bottomBar:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    lazy var fontView:CustomFontView = {
        let v = CustomFontView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.delegate = self
        v.controller = self
        return v
    }()
    
    lazy var colorPicker:CustomColorPicker = {
        let v = CustomColorPicker()
        v.delegate = self
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0, alpha: 0.7)
        view.addSubview(navBar)
        view.addSubview(customTextViewBox)
        customTextViewBox.addSubview(customTextView)
        view.addSubview(bottomBar)
        bottomBar.addSubview(fontView)
        bottomBar.addSubview(colorPicker)
        fontView.pin(to: bottomBar)
        colorPicker.pin(to: bottomBar)
        customTextViewBox.addSubview(sliderView)
        setUpConstraints()
        customTextView.becomeFirstResponder()
        sliderView.transform = CGAffineTransform(rotationAngle: CGFloat(-Double.pi / 2))
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleKeyboardNotification) , name: UIResponder.keyboardWillShowNotification , object: nil)

        NotificationCenter.default.addObserver(self, selector: #selector(handleKeyboardNotification) , name: UIResponder.keyboardWillHideNotification , object: nil)

        //bottomconstraints
        bottomConstraint = NSLayoutConstraint(item: bottomBar, attribute: .bottom, relatedBy: .equal, toItem: view, attribute: .bottom, multiplier: 1, constant: 0)
        view.addConstraint(bottomConstraint!)
        textViewDidChange(customTextView)
        
        state = .font
        self.colorPicker.isHidden = true
        self.colorPicker.alpha = 0
        
        for family in UIFont.familyNames {

            let sName: String = family as String
            print("family: \(sName)")
                    
            for name in UIFont.fontNames(forFamilyName: sName) {
                print("name: \(name as String)")
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let index = IndexPath(item: 0, section: 0)
        fontView.collectionView.selectItem(at: index, animated: true, scrollPosition: .centeredHorizontally)
        customTextView.font = UIFont(name: fontView.fontName[0], size: 30)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            navBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            navBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navBar.heightAnchor.constraint(equalToConstant: 60),
            
            customTextViewBox.topAnchor.constraint(equalTo: navBar.bottomAnchor),
            customTextViewBox.bottomAnchor.constraint(equalTo: fontView.topAnchor),
            customTextViewBox.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            customTextViewBox.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            customTextView.centerXAnchor.constraint(equalTo: customTextViewBox.centerXAnchor),
            customTextView.centerYAnchor.constraint(equalTo: customTextViewBox.centerYAnchor),
            customTextView.widthAnchor.constraint(equalToConstant: view.frame.width - 80),
            customTextView.heightAnchor.constraint(equalToConstant: 100),
            
            bottomBar.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bottomBar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomBar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomBar.heightAnchor.constraint(equalToConstant: 70),
            
            sliderView.widthAnchor.constraint(equalToConstant: 230),
            sliderView.leadingAnchor.constraint(equalTo: customTextViewBox.leadingAnchor, constant: -90),
            sliderView.centerYAnchor.constraint(equalTo: customTextViewBox.centerYAnchor)
        ])
    }
    
    @objc func donePressed(){
        let font = customTextView.font
        let alignment = customTextView.textAlignment
        let height = customTextView.frame.height
        let width = customTextView.frame.width
        let text = customTextView.text
        let fontColor = customTextView.textColor
        
        let dataToBeSent = textViewProperties(font: font, fontColor: fontColor, text: text, height: height, alignment: alignment, width: width)
        delegate?.didDataSent(dataToBeSent)
        dismiss(animated: true, completion: nil)
    }
    
    @objc func fontChange(){
        customTextView.font =
            customTextView.font?.withSize(CGFloat(Int(sliderView.value)))
        textViewDidChange(customTextView)
    }
    
    @objc func positionBtnPressed(){
        if count == 2 {
            count = 0
        } else {
            count += 1
        }
        navBar.positionBtn.setBackgroundImage(UIImage(named: position[count]), for: .normal)
        if position[count] == "align-left" {
            self.customTextView.textAlignment = .left
        } else if position[count] == "align-center" {
            self.customTextView.textAlignment = .center
        } else if position[count] == "align-right" {
            self.customTextView.textAlignment = .right
        }
    }
    
    @objc func bottomBarTogglePressed(){
        if state == .font {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                self.colorPicker.isHidden = false
                self.colorPicker.alpha = 1
                self.fontView.alpha = 0
            }, completion: { finished in
                self.fontView.isHidden = true
            })
            state = .color
            self.navBar.bottomBarToggle.setBackgroundImage(UIImage(named: "font"), for: .normal)
        } else if state == .color {
            UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut, animations: {
                self.fontView.isHidden = false
                self.fontView.alpha = 1
                self.colorPicker.alpha = 0
            }, completion: { finished in
                self.colorPicker.isHidden = true
            })
            state = .font
            self.navBar.bottomBarToggle.setBackgroundImage(UIImage(named: "color"), for: .normal)
        }
    }
    
    @objc func handleKeyboardNotification(notification: NSNotification){
        
        if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            let keyboardHeight = keyboardRectangle.height
            
            let isKeyboardShowing = notification.name == UIResponder.keyboardWillShowNotification
            
            bottomConstraint?.constant = isKeyboardShowing ? -keyboardHeight : 0
            
            UIView.animate(withDuration:0.1, delay: 0 , options: .curveEaseOut , animations: {
                self.view.layoutIfNeeded()
            } , completion: {(completed) in
            })
        }
    }

}

extension TextFontViewController:UITextViewDelegate, FontSelectionDelegate, SelectedColor{
    
    func didColorSelected(_ color: UIColor) {
        customTextView.textColor = color
    }
    
    func didSelectFont(_ fontName: String) {
        if sliderView.value == 30 {
            customTextView.font = UIFont(name: fontName, size: 30)
        }
        else {
            customTextView.font = UIFont(name: fontName, size: CGFloat(sliderView.value))
        }
        textViewDidChange(customTextView)
        
    }
    
    func textViewDidChange(_ textView:
        UITextView) {
        let size = CGSize(width: view.frame.width - 60, height: 300)
        let estimatedSize = textView.sizeThatFits(size)
        
        textView.constraints.forEach { (contraint) in
            if contraint.firstAttribute == .height {
                contraint.constant = estimatedSize.height
            }
            if contraint.firstAttribute == .width {
                contraint.constant = estimatedSize.width
            }
        }
    }
    
}
