//
//  CategoryCollectionViewCell.swift
//  design_to_code11
//
//  Created by Dheeraj Kumar Sharma on 07/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CategoryCollectionViewCell: UICollectionViewCell {
    
    override var isSelected: Bool {
        didSet {
            indicatorView.isHidden = isSelected ? false : true
            categoryLabel.textColor = isSelected ? UIColor.dynamicColor(.textColor) : .lightGray
        }
    }
    
    let categoryLabel:UILabel = {
        let l = UILabel()
        l.font = UIFont(name: "Avenir-Heavy", size: 14)
        l.translatesAutoresizingMaskIntoConstraints = false
        l.textColor = .lightGray
        l.textAlignment = .center
        return l
    }()
    
    let indicatorView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 3
        v.backgroundColor = UIColor.dynamicColor(.textColor)
        return v
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(categoryLabel)
        addSubview(indicatorView)
        indicatorView.isHidden = true
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            categoryLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 5),
            categoryLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -5),
            categoryLabel.topAnchor.constraint(equalTo: topAnchor, constant: 5),
            
            indicatorView.topAnchor.constraint(equalTo: categoryLabel.bottomAnchor, constant: 3),
            indicatorView.widthAnchor.constraint(equalToConstant: 6),
            indicatorView.heightAnchor.constraint(equalToConstant: 6),
            indicatorView.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
