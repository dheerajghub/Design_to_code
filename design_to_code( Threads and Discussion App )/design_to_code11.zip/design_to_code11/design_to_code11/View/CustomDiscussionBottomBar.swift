//
//  CustomDiscussionBottomBar.swift
//  design_to_code11
//
//  Created by Dheeraj Kumar Sharma on 08/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class CustomDiscussionBottomBar: UIView {

    let dividerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0, alpha: 0.1)
        return v
    }()
    
    let attachmentBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = UIColor(red: 100/255, green: 162/255, blue: 53/255, alpha: 1)
        btn.setImage(UIImage(named: "attachment"), for: .normal)
        btn.layer.cornerRadius = 30
        return btn
    }()
    
    let typeLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Type.."
        l.font = UIFont(name: "Avenir-Medium", size: 18)
        l.textColor = .lightGray
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(dividerView)
        addSubview(typeLabel)
        addSubview(attachmentBtn)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            dividerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            dividerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            dividerView.topAnchor.constraint(equalTo: topAnchor),
            dividerView.heightAnchor.constraint(equalToConstant: 1),
            
            attachmentBtn.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            attachmentBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            attachmentBtn.widthAnchor.constraint(equalToConstant: 60),
            attachmentBtn.heightAnchor.constraint(equalToConstant: 60),
            
            typeLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            typeLabel.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
