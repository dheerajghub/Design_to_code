//
//  UserStoryHeaderCollectionReusableView.swift
//  design_to_code11
//
//  Created by Dheeraj Kumar Sharma on 07/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class UserStoryHeaderCollectionReusableView: UICollectionReusableView {
    
    let imageView:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named:"img1")
        img.clipsToBounds = true
        img.layer.cornerRadius = 34
        return img
    }()
    
    let backView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.layer.cornerRadius = 34
        v.backgroundColor = .white
        return v
    }()
    
    let addBtn:UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setImage(UIImage(named:"add"), for: .normal)
        btn.layer.cornerRadius = 10
        btn.backgroundColor = .white
        return btn
    }()
    
    let dividerView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor(white: 0, alpha: 0.08)
        return v
    }()
    
    let userName:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Add Story"
        l.textColor = UIColor.dynamicColor(.secondaryTextColor)
        l.textAlignment = .center
        l.font = UIFont(name: "Avenir-Heavy", size: 13)
        return l
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(backView)
        backView.addSubview(imageView)
        addSubview(userName)
        addSubview(dividerView)
        dividerView.addSubview(addBtn)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            backView.topAnchor.constraint(equalTo: topAnchor, constant: 28),
            backView.centerXAnchor.constraint(equalTo: centerXAnchor),
            backView.widthAnchor.constraint(equalToConstant: 68),
            backView.heightAnchor.constraint(equalToConstant: 68),
            
            imageView.centerXAnchor.constraint(equalTo: backView.centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: backView.centerYAnchor),
            imageView.widthAnchor.constraint(equalToConstant: 68),
            imageView.heightAnchor.constraint(equalToConstant: 68),
            
            userName.topAnchor.constraint(equalTo: backView.bottomAnchor, constant: 7),
            userName.centerXAnchor.constraint(equalTo: centerXAnchor),
            userName.leadingAnchor.constraint(equalTo: leadingAnchor),
            userName.trailingAnchor.constraint(equalTo: trailingAnchor),
            
            dividerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            dividerView.topAnchor.constraint(equalTo: topAnchor, constant: 40),
            dividerView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -60),
            dividerView.widthAnchor.constraint(equalToConstant: 2),
            
            addBtn.trailingAnchor.constraint(equalTo: backView.trailingAnchor),
            addBtn.bottomAnchor.constraint(equalTo: backView.bottomAnchor),
            addBtn.widthAnchor.constraint(equalToConstant: 20),
            addBtn.heightAnchor.constraint(equalToConstant: 20)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
