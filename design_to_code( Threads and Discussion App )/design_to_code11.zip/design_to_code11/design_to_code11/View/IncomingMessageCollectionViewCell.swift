//
//  IncomingMessageCollectionViewCell.swift
//  design_to_code11
//
//  Created by Dheeraj Kumar Sharma on 08/08/20.
//  Copyright © 2020 Dheeraj Kumar Sharma. All rights reserved.
//

import UIKit

class IncomingMessageCollectionViewCell: UICollectionViewCell {
    
    var data:ChatData?{
        didSet{
            manageData()
        }
    }
    
    let bubbleView:UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor.dynamicColor(.appBackground2)
        v.layer.cornerRadius = 25
        return v
    }()
    
    let userImage:UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.clipsToBounds = true
        img.layer.cornerRadius = 22.5
        img.contentMode = .scaleAspectFill
        return img
    }()
    
    let userDetail:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        return l
    }()
    
    let message:UILabel = {
        let l = UILabel()
        l.font = UIFont(name: "Avenir-Medium", size: 16)
        l.textColor = UIColor.dynamicColor(.secondaryTextColor)
        l.translatesAutoresizingMaskIntoConstraints = false
        l.numberOfLines = 0
        return l
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(bubbleView)
        bubbleView.addSubview(userImage)
        bubbleView.addSubview(userDetail)
        bubbleView.addSubview(message)
        setUpConstraints()
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            bubbleView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 30),
            bubbleView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            bubbleView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -15),
            bubbleView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -70),
            
            userImage.leadingAnchor.constraint(equalTo: bubbleView.leadingAnchor, constant: 20),
            userImage.topAnchor.constraint(equalTo: bubbleView.topAnchor, constant: 20),
            userImage.widthAnchor.constraint(equalToConstant: 45),
            userImage.heightAnchor.constraint(equalToConstant: 45),
            
            userDetail.leadingAnchor.constraint(equalTo: userImage.trailingAnchor, constant: 10),
            userDetail.topAnchor.constraint(equalTo: bubbleView.topAnchor, constant: 30),
            userDetail.trailingAnchor.constraint(equalTo: bubbleView.trailingAnchor, constant: -20),
            
            message.topAnchor.constraint(equalTo: userImage.bottomAnchor, constant: 10),
            message.bottomAnchor.constraint(equalTo: bubbleView.bottomAnchor, constant: -10),
            message.leadingAnchor.constraint(equalTo: bubbleView.leadingAnchor, constant: 20),
            message.trailingAnchor.constraint(equalTo: bubbleView.trailingAnchor, constant: -20)
        ])
    }
    
    func setUpAttributeText(isVerified:Bool, userName:String, time:String){
        let attributedText = NSMutableAttributedString(string:"@\(userName)  " , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Black", size: 16)!, NSAttributedString.Key.foregroundColor: UIColor.dynamicColor(.textColor)])
        
        if isVerified {
            let font = UIFont.systemFont(ofSize: 16)
            let verifiyImg = UIImage(named:"verify")
            let verifiedImage = NSTextAttachment()
            verifiedImage.image = verifiyImg
            verifiedImage.bounds = CGRect(x: 0, y: (font.capHeight - 16).rounded() / 2, width: 16, height: 16)
            verifiedImage.setImageHeight(height: 16)
            let imgString = NSAttributedString(attachment: verifiedImage)
            attributedText.append(imgString)
        }
        
        attributedText.append(NSAttributedString(string: "  \(time)" , attributes:[NSAttributedString.Key.font: UIFont(name: "Avenir-Medium", size: 14)! ,NSAttributedString.Key.foregroundColor: UIColor.lightGray]))
        
        userDetail.attributedText = attributedText
    }
    
    func manageData(){
        guard let data = data else {return}
        setUpAttributeText(isVerified: data.isVerified, userName: data.userName, time: data.time)
        userImage.image = UIImage(named: data.userImage)
        message.text = data.message
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
