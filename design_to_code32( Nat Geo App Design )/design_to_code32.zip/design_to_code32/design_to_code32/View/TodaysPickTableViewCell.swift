//
//  TodaysPickTableViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 08/05/21.
//

import UIKit

class TodaysPickTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    
    let dataArr = [
        TodayPick(img: "pick1", title: "Does the United States needs a space force?", by: "By Anonymous"),
        TodayPick(img: "pick2", title: "Was Napoleon Bonaparte an enlightened leader or tyrant?", by: "By Rish")
    ]
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero , collectionViewLayout: UICollectionViewFlowLayout.init())
        cv.setCollectionViewLayout(layout, animated: true)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = Colors.appBackground
        cv.showsHorizontalScrollIndicator = false
        cv.register(TodaysPickCollectionViewCell.self, forCellWithReuseIdentifier: "TodaysPickCollectionViewCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        return cv
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        addSubview(collectionView)
    }
    
    fileprivate func setUpConstraints(){
        collectionView.pin(to: self)
    }

}

extension TodaysPickTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TodaysPickCollectionViewCell", for: indexPath) as! TodaysPickCollectionViewCell
        cell.backgroundColor = Colors.appSecondayBackground
        cell.cardImage.image = UIImage(named: dataArr[indexPath.row].img)
        cell.cardTitle.text = dataArr[indexPath.row].title
        cell.cardSubtitle.text = dataArr[indexPath.row].by
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width - 100, height: 160)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
}
