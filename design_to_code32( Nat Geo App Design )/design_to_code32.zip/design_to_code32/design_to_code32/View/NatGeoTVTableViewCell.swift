//
//  NatGeoTVTableViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

protocol NatGeoTVActionDelegate {
    func didCardTapped()
}

class NatGeoTVTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    var delegate: NatGeoTVActionDelegate?
    let imgArr = ["img1", "img2"]
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero , collectionViewLayout: UICollectionViewFlowLayout.init())
        cv.setCollectionViewLayout(layout, animated: true)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = Colors.appBackground
        cv.showsHorizontalScrollIndicator = false
        cv.register(NatGeoTVCollectionViewCell.self, forCellWithReuseIdentifier: "NatGeoTVCollectionViewCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        return cv
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
       addSubview(collectionView)
    }
    
    fileprivate func setUpConstraints(){
        collectionView.pin(to: self)
    }

}

extension NatGeoTVTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imgArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NatGeoTVCollectionViewCell", for: indexPath) as! NatGeoTVCollectionViewCell
        cell.cardImage.image = UIImage(named: imgArr[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: ((collectionView.frame.width - 60) / 2), height: 240)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.didCardTapped()
    }
    
}
