//
//  TodaysPickCollectionViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class TodaysPickCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    let cardTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Does the United States needs a space force?"
        l.textColor = .white
        l.font = UIFont(name: "Poppins-Medium", size: 15)
        l.numberOfLines = 3
        return l
    }()
    
    let cardSubtitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "By Anonymous"
        l.textColor = Colors.appYellow
        l.font = UIFont(name: "Poppins-Medium", size: 12)
        return l
    }()
    
    let readMore: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = .white
        btn.setTitle("Read Here", for: .normal)
        btn.setTitleColor(.black, for: .normal)
        btn.titleLabel?.font = UIFont(name: "Poppins-Medium", size: 12)
        btn.layer.cornerRadius = 5
        return btn
    }()
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let borderView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = Colors.appYellow
        return v
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        clipsToBounds = true
        addSubview(cardTitle)
        addSubview(cardSubtitle)
        addSubview(readMore)
        addSubview(borderView)
        addSubview(cardImage)
    }
    
    fileprivate func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardImage.trailingAnchor.constraint(equalTo: trailingAnchor),
            cardImage.bottomAnchor.constraint(equalTo: bottomAnchor),
            cardImage.topAnchor.constraint(equalTo: topAnchor),
            cardImage.widthAnchor.constraint(equalToConstant: CGFloat(self.frame.width * 0.37)),
            
            borderView.leadingAnchor.constraint(equalTo: leadingAnchor),
            borderView.bottomAnchor.constraint(equalTo: bottomAnchor),
            borderView.trailingAnchor.constraint(equalTo: cardImage.leadingAnchor),
            borderView.heightAnchor.constraint(equalToConstant: 5),
            
            readMore.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            readMore.bottomAnchor.constraint(equalTo: borderView.topAnchor, constant: -20),
            readMore.widthAnchor.constraint(equalToConstant: 80),
            readMore.heightAnchor.constraint(equalToConstant: 25),
            
            cardTitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            cardTitle.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            cardTitle.trailingAnchor.constraint(equalTo: cardImage.leadingAnchor, constant: -10),
            
            cardSubtitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            cardSubtitle.topAnchor.constraint(equalTo: cardTitle.bottomAnchor, constant: 3),
            cardSubtitle.trailingAnchor.constraint(equalTo: cardImage.leadingAnchor, constant: -10)
        ])
    }
    
}
