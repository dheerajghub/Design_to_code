//
//  NatGeoTVCollectionViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class NatGeoTVCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.backgroundColor = Colors.appSecondayBackground
        img.clipsToBounds = true
        return img
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        addSubview(cardImage)
    }
    
    fileprivate func setUpConstraints(){
        cardImage.pin(to: self)
    }
    
}
