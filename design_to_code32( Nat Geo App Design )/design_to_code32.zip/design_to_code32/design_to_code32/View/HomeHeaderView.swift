//
//  HomeHeaderView.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 08/05/21.
//

import UIKit

class HomeHeaderView: UIView {

    // MARK:- PROPERTIES
    
    let dataArr = [
        LatestNews(img: "header1", title: "Chimpanzee moms are like us: They take 'me' time."),
        LatestNews(img: "header2", title: "Rare Grizly Bear Spotted in Canada"),
        LatestNews(img: "header3", title: "Rare footage shows endangered whales 'hugging'")
    ]
    
    let collectionMargin = CGFloat(30)
    let itemSpacing = CGFloat(20)
    let itemHeight = CGFloat(200)
    var itemWidth = CGFloat(0)
    var currentItem = 0
    
    lazy var collectionView: UICollectionView = {
        let cv = UICollectionView(frame: CGRect.zero , collectionViewLayout: UICollectionViewFlowLayout.init())
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .clear
        cv.showsHorizontalScrollIndicator = false
        cv.register(HeaderCollectionViewCell.self, forCellWithReuseIdentifier: "HeaderCollectionViewCell")
        return cv
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        
        // creating custom collection view layout
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()

        itemWidth =  UIScreen.main.bounds.width - collectionMargin * 2.0
        
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: itemWidth, height: itemHeight)
        layout.headerReferenceSize = CGSize(width: collectionMargin, height: 0)
        layout.footerReferenceSize = CGSize(width: collectionMargin, height: 0)
        layout.minimumLineSpacing = itemSpacing
        layout.scrollDirection = .horizontal

        collectionView.collectionViewLayout = layout
        collectionView.decelerationRate = UIScrollView.DecelerationRate.fast
        
        addSubview(collectionView)
    }
    
    fileprivate func setUpConstraints(){
        collectionView.pin(to: self)
    }

}

extension HomeHeaderView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout , UIScrollViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HeaderCollectionViewCell", for: indexPath) as! HeaderCollectionViewCell
        cell.cardImage.image = UIImage(named: dataArr[indexPath.row].img)
        cell.cardTitle.text = dataArr[indexPath.row].title
        return cell
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        
        let pageWidth = Float(itemWidth + itemSpacing)
        let targetXContentOffset = Float(targetContentOffset.pointee.x)
        let contentWidth = Float(collectionView.contentSize.width  )
        var newPage = currentItem
        
        if velocity.x == 0 {
            newPage = Int(floor( (targetXContentOffset - Float(pageWidth) / 2) / Float(pageWidth)) + 1.0)
        } else {
            newPage = Int(Float(velocity.x > 0 ? currentItem + 1 : currentItem - 1))
            if newPage < 0 {
                newPage = 0
            }
            if (newPage > Int(contentWidth / pageWidth)) {
                newPage = Int(ceil(contentWidth / pageWidth) - 1.0)
            }
        }
        currentItem = Int(newPage)
        let point = CGPoint (x: CGFloat(Float(newPage) * pageWidth), y: targetContentOffset.pointee.y)
        targetContentOffset.pointee = point
    }
    
}
