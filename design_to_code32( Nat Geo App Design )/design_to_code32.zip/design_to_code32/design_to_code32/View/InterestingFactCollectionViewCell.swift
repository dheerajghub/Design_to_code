//
//  InterestingFactCollectionViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class InterestingFactCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let cardTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Red Chameleon"
        l.textColor = Colors.appYellow
        l.font = UIFont(name: "Poppins-Medium", size: 14)
        return l
    }()
    
    let cardSubtitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Changing Colors as it climbs"
        l.textColor = .white
        l.font = UIFont(name: "Poppins-Medium", size: 14)
        l.numberOfLines = 0
        return l
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    func setUpViews() {
        backgroundColor = Colors.appSecondayBackground
        addSubview(cardImage)
        addSubview(cardTitle)
        addSubview(cardSubtitle)
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardImage.trailingAnchor.constraint(equalTo: trailingAnchor),
            cardImage.topAnchor.constraint(equalTo: topAnchor),
            cardImage.bottomAnchor.constraint(equalTo: bottomAnchor),
            cardImage.widthAnchor.constraint(equalToConstant: self.frame.width * 0.40),
            
            cardTitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            cardTitle.trailingAnchor.constraint(equalTo: cardImage.leadingAnchor, constant: -10),
            cardTitle.topAnchor.constraint(equalTo: topAnchor, constant: 45),
            
            cardSubtitle.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            cardSubtitle.trailingAnchor.constraint(equalTo: cardImage.leadingAnchor, constant: -10),
            cardSubtitle.topAnchor.constraint(equalTo: cardTitle.bottomAnchor, constant: 3)
        ])
    }
    
}
