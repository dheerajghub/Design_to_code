//
//  InterestingFactsTableViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class InterestingFactsTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    
    let dataArr = [
        InterestingFacts(title: "Red Chameleon", subTitle: "Changing colors as it climbs", img: "chameleon"),
        InterestingFacts(title: "Snow Leopard", subTitle: "They're high altitude acrobats.", img: "snowleopard")
    ]
    
    lazy var collectionView: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero , collectionViewLayout: UICollectionViewFlowLayout.init())
        cv.setCollectionViewLayout(layout, animated: true)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = Colors.appBackground
        cv.showsHorizontalScrollIndicator = false
        cv.register(InterestingFactCollectionViewCell.self, forCellWithReuseIdentifier: "InterestingFactCollectionViewCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 20, bottom: 0, right: 20)
        return cv
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        addSubview(collectionView)
    }
    
    fileprivate func setUpConstraints(){
        collectionView.pin(to: self)
    }

}

extension InterestingFactsTableViewCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InterestingFactCollectionViewCell", for: indexPath) as! InterestingFactCollectionViewCell
        cell.backgroundColor = Colors.appSecondayBackground
        cell.cardTitle.text = dataArr[indexPath.row].title
        cell.cardSubtitle.text = dataArr[indexPath.row].subTitle
        cell.cardImage.image = UIImage(named: dataArr[indexPath.row].img)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width - 100, height: 150)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
}
