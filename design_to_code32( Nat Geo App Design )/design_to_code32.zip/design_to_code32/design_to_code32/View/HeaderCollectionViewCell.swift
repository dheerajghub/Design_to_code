//
//  HeaderCollectionViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class HeaderCollectionViewCell: UICollectionViewCell {
    
    // MARK:- PROPERTIES
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let overlayView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        return v
    }()
    
    let cardTitle: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "Rare Grizly Bear Spotted in Canada"
        l.font = UIFont(name: "Poppins-Medium", size: 15)
        l.textColor = .white
        return l
    }()
    
    // MARK:- MAIN
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        addSubview(cardImage)
        addSubview(overlayView)
        overlayView.addSubview(cardTitle)
    }
    
    fileprivate func setUpConstraints(){
        cardImage.pin(to: self)
        NSLayoutConstraint.activate([
            overlayView.leadingAnchor.constraint(equalTo: leadingAnchor),
            overlayView.trailingAnchor.constraint(equalTo: trailingAnchor),
            overlayView.bottomAnchor.constraint(equalTo: bottomAnchor),
            overlayView.heightAnchor.constraint(equalToConstant: 40),
            
            cardTitle.centerYAnchor.constraint(equalTo: overlayView.centerYAnchor),
            cardTitle.leadingAnchor.constraint(equalTo: overlayView.leadingAnchor, constant: 20),
            cardTitle.trailingAnchor.constraint(equalTo: overlayView.trailingAnchor, constant: -20)
        ])
    }
    
}
