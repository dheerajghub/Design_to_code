//
//  NatGeoTVDetailCardTableViewCell.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class NatGeoTVDetailCardTableViewCell: UITableViewCell {

    // MARK:- PROPERTIES
    
    let cardView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = Colors.appSecondayBackground
        return v
    }()
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "img_detail1")
        img.contentMode = .scaleAspectFill
        img.clipsToBounds = true
        return img
    }()
    
    let playBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.backgroundColor = Colors.appBlue.withAlphaComponent(0.6)
        btn.layer.cornerRadius = 40
        btn.setImage(UIImage(named: "playBtn"), for: .normal)
        return btn
    }()
    
    let heartIcon: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.contentMode = .scaleAspectFill
        img.image = UIImage(named: "likeBtn")
        return img
    }()
    
    let likeLabel: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "1045"
        l.textColor = .white
        l.font = UIFont(name: "Poppins-Medium", size: 15)
        return l
    }()
    
    let cardDescription: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont(name: "Poppins-Medium", size: 15)
        l.numberOfLines = 0
        return l
    }()
    
    // MARK:- MAIN
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
        setUpConstraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpViews() {
        backgroundColor = Colors.appBackground
        addSubview(cardView)
        cardView.addSubview(cardImage)
        cardView.addSubview(playBtn)
        addSubview(cardDescription)
        addSubview(heartIcon)
        addSubview(likeLabel)
    }
    
    fileprivate func setUpConstraints(){
        NSLayoutConstraint.activate([
            cardView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            cardView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            cardView.topAnchor.constraint(equalTo: topAnchor, constant: 15),
            cardView.heightAnchor.constraint(equalToConstant: 250),
            
            cardImage.leadingAnchor.constraint(equalTo: cardView.leadingAnchor),
            cardImage.trailingAnchor.constraint(equalTo: cardView.trailingAnchor),
            cardImage.topAnchor.constraint(equalTo: cardView.topAnchor),
            cardImage.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -50),
            
            playBtn.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -10),
            playBtn.widthAnchor.constraint(equalToConstant: 80),
            playBtn.heightAnchor.constraint(equalToConstant: 80),
            playBtn.centerXAnchor.constraint(equalTo: cardView.centerXAnchor),
            
            cardDescription.topAnchor.constraint(equalTo: cardView.bottomAnchor, constant: 15),
            cardDescription.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            cardDescription.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            cardDescription.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -15),
            
            likeLabel.trailingAnchor.constraint(equalTo: cardView.trailingAnchor, constant: -20),
            likeLabel.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -17),
            likeLabel.heightAnchor.constraint(equalToConstant: 16),
            
            heartIcon.trailingAnchor.constraint(equalTo: likeLabel.leadingAnchor, constant: -4),
            heartIcon.heightAnchor.constraint(equalToConstant: 16),
            heartIcon.widthAnchor.constraint(equalToConstant: 16),
            heartIcon.bottomAnchor.constraint(equalTo: cardView.bottomAnchor, constant: -17)
        ])
    }

}
