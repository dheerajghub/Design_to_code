//
//  Constants.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 08/05/21.
//

import UIKit

struct Colors {
    static let appBackground = UIColor(red: 32/255, green: 32/255, blue: 37/255, alpha: 1)
    static let appSecondayBackground = UIColor(red: 38/255, green: 41/255, blue: 46/255, alpha: 1)
    static let appYellow = UIColor(red: 255/255, green: 213/255, blue: 28/255, alpha: 1)
    static let appBlue = UIColor(red: 0, green: 140/255, blue: 225/255, alpha: 1)
}
