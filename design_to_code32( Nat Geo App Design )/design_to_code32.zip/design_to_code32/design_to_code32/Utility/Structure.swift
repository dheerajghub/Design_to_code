//
//  Structure.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import Foundation

struct InterestingFacts {
    let title: String!
    let subTitle: String!
    let img: String!
}

struct LatestNews {
    let img: String!
    let title: String!
}

struct TodayPick {
    let img: String!
    let title: String!
    let by: String!
}
