//
//  HomeViewController.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 08/05/21.
//

import UIKit

class HomeViewController: UIViewController {

    // MARK:- PROPERTIES
    
    lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.tableFooterView = UIView()
        tv.separatorStyle = .none
        tv.delegate = self
        tv.dataSource = self
        tv.showsVerticalScrollIndicator = false
        tv.register(TodaysPickTableViewCell.self, forCellReuseIdentifier: "TodaysPickTableViewCell")
        tv.register(NatGeoTVTableViewCell.self, forCellReuseIdentifier: "NatGeoTVTableViewCell")
        tv.backgroundColor = Colors.appBackground
        return tv
    }()
    
    // MARK:- MAIN
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Colors.appBackground
        setUpNavigation()
        setUpViews()
        setUpConstraints()
    }
    
    // MARK:- FUNCTIONS
    
    fileprivate func setUpNavigation(){
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.barTintColor = Colors.appSecondayBackground
        navigationController?.navigationBar.isTranslucent = false
        
        // Logo Image
        let logo = UIImage(named: "logo")
        let logoImageView = UIImageView(image:resizeImage(image: logo!, targetSize: CGSize(width: 100, height: 40)))
        logoImageView.contentMode = .scaleAspectFill
        logoImageView.clipsToBounds = true
        logoImageView.frame = CGRect(x: 20, y: 0, width: 100, height: 40)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: logoImageView)
        
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = logoImageView
        
        navigationItem.setRightBarButton(leftBarButtonItem, animated: true)
        
        // Search Button
        let searchButton = UIButton(type: .system)
        searchButton.setImage(UIImage(named: "search")?.withRenderingMode(.alwaysTemplate), for: .normal)
        searchButton.tintColor = .white
        searchButton.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchButton)
        
        // Menu Button
        let menuButton = UIButton(type: .system)
        menuButton.setImage(UIImage(named: "menu")?.withRenderingMode(.alwaysTemplate), for: .normal)
        menuButton.tintColor = .white
        menuButton.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: menuButton)
        
        
        let rightBarButtonItem1 = UIBarButtonItem()
        rightBarButtonItem1.customView = menuButton
        
        let rightBarButtonItem2 = UIBarButtonItem()
        rightBarButtonItem2.customView = searchButton
        
        navigationItem.setRightBarButtonItems([rightBarButtonItem1 , rightBarButtonItem2], animated: true)
        
    }
    
    fileprivate func setUpViews() {
        view.addSubview(tableView)
        
        // setting table header view
        let headerView = HomeHeaderView(frame: CGRect(x: 0, y: 0, width: self.view.bounds.width, height: 220))
        self.tableView.tableHeaderView = headerView
        
        for family: String in UIFont.familyNames {
            print("\(family)")
            for names: String in UIFont.fontNames(forFamilyName: family) {
                print("== \(names)")
            }
        }
        
    }
    
    fileprivate func setUpConstraints(){
        tableView.pin(to: view)
    }

}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 60))
        headerView.backgroundColor = Colors.appBackground
        
        // header border
        let border = UIView()
        border.frame = CGRect.init(x: 20, y: 17.5, width: 6, height: 25)
        border.backgroundColor = Colors.appYellow
        
        // header name
        let label = UILabel()
        label.frame = CGRect.init(x: 35, y: 10, width: headerView.frame.width-120, height: 40)
        label.text = section == 0 ? "Today's picks" : "Nat Geo TV"
        label.font = UIFont(name: "Poppins-Medium", size: 15)
        label.textColor = .white
        
        // header arrow
        let image = UIImageView()
        image.frame = CGRect.init(x: headerView.frame.width-50, y: 17.5, width: 25, height: 25)
        image.image = UIImage(named: "forward")
        image.layer.cornerRadius = 5
        image.backgroundColor = Colors.appSecondayBackground
        
        headerView.addSubview(border)
        headerView.addSubview(label)
        headerView.addSubview(image)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "TodaysPickTableViewCell", for: indexPath) as! TodaysPickTableViewCell
            cell.selectionStyle = .none
            return cell
        }
        if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "NatGeoTVTableViewCell", for: indexPath) as! NatGeoTVTableViewCell
            cell.selectionStyle = .none
            cell.delegate = self
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 200
        }
        if indexPath.section == 1 {
            return 260
        }
        return CGFloat()
    }
    
}

extension HomeViewController: NatGeoTVActionDelegate {
    
    func didCardTapped() {
        let VC = NatGeoTVDetailViewController()
        navigationController?.pushViewController(VC, animated: true)
    }
    
}
