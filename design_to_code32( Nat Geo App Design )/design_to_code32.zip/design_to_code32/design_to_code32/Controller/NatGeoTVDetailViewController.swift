//
//  NatGeoTVDetailViewController.swift
//  design_to_code32
//
//  Created by Dheeraj Kumar Sharma on 09/05/21.
//

import UIKit

class NatGeoTVDetailViewController: UIViewController {

    // MARK:- PROPERTIES
    
    let cardDesc = "People living in Alaska talk about their daily struggles and explain the different techniques they use to survive in a sub-zero-degree enviornment.\n\nThe show follows people who live in the remote areaa of Alaska, trying to survive in the below-zero conditions, demonstrating their everyday struggles as they hunt and depend only on themselves and survive using the resources they have."
    
    lazy var tableView: UITableView = {
        let tv = UITableView()
        tv.translatesAutoresizingMaskIntoConstraints = false
        tv.tableFooterView = UIView()
        tv.separatorStyle = .none
        tv.delegate = self
        tv.dataSource = self
        tv.showsVerticalScrollIndicator = false
        tv.register(NatGeoTVDetailCardTableViewCell.self, forCellReuseIdentifier: "NatGeoTVDetailCardTableViewCell")
        tv.register(InterestingFactsTableViewCell.self, forCellReuseIdentifier: "InterestingFactsTableViewCell")
        tv.backgroundColor = Colors.appBackground
        return tv
    }()
    
    // MARK:- MAIN
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = Colors.appBackground
        setUpNavigation()
        setUpViews()
        setUpConstraints()
    }
    
    // MARK:- FUNCTIONS

    fileprivate func setUpNavigation(){
        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(named: "back")?.withRenderingMode(.alwaysTemplate), for: .normal)
        backButton.tintColor = .white
        backButton.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButton)
        backButton.addTarget(self, action: #selector(backBtn), for: .touchUpInside)
        let leftBarButtonItem = UIBarButtonItem()
        leftBarButtonItem.customView = backButton
        navigationItem.setLeftBarButton(leftBarButtonItem, animated: false)
    }
    
    fileprivate func setUpViews(){
        view.addSubview(tableView)
    }
    
    fileprivate func setUpConstraints() {
        tableView.pin(to: view)
    }
    
    @objc func backBtn(){
        navigationController?.popViewController(animated: true)
    }
    
}

extension NatGeoTVDetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: tableView.frame.width, height: 60))
        headerView.backgroundColor = Colors.appBackground
        
        // header border
        let border = UIView()
        border.frame = CGRect.init(x: 20, y: 17.5, width: 6, height: 25)
        border.backgroundColor = Colors.appYellow
        
        // header name
        let label = UILabel()
        label.frame = CGRect.init(x: 35, y: 10, width: headerView.frame.width-120, height: 40)
        label.text = section == 1 ? "Interesting Facts" : ""
        label.font = UIFont(name: "Poppins-Medium", size: 15)
        label.textColor = .white
        
        // header subtitle
        let label2 = UILabel()
        label2.frame = CGRect.init(x: headerView.frame.width-80, y: 10, width: 60, height: 40)
        label2.text = section == 1 ? "View All" : ""
        label2.font = UIFont(name: "Poppins-Medium", size: 15)
        label2.textColor = .white
        
        headerView.addSubview(border)
        headerView.addSubview(label)
        headerView.addSubview(label2)
        
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "NatGeoTVDetailCardTableViewCell", for: indexPath) as! NatGeoTVDetailCardTableViewCell
            cell.cardDescription.text = cardDesc
            cell.selectionStyle = .none
            return cell
        }
        if indexPath.section == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "InterestingFactsTableViewCell", for: indexPath) as! InterestingFactsTableViewCell
            cell.selectionStyle = .none
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0
        }
        return 60
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            let font = UIFont(name: "Poppins-Medium", size: 15)
            let estimatedH = cardDesc.height(withWidth: (tableView.frame.width - 40), font: font!)
            return estimatedH + 30 + 250 + 15
        }
        return 170
    }
    
}
