//
//  CustomNextButtonView.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

protocol NextButtonDelegate {
    func isAnimationCompleted()
    func didForwardBtnTapped()
    func didReloadTapped()
    func scrollToIndex(_ index: IndexPath)
}

enum ButtonState {
    case forward
    case reload
}

class CustomNextButtonView: UIView {

    // MARK: PROPERTIES -
    var duration = 15
    var buttonState: ButtonState?
    var cellCount = 0
    var pageCount = 3
    
    let trackLayer = CAShapeLayer()
    var timer = Timer()
    var changeTimer = Timer()
    var delegate: NextButtonDelegate?
    
    let forwardBtnView: UIView = {
        let v = UIView()
        v.translatesAutoresizingMaskIntoConstraints = false
        return v
    }()
    
    let forwardBtn: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "ic_forward"), for: .normal)
        btn.addTarget(self, action: #selector(forwardBtnPressed), for: .touchUpInside)
        btn.addPressAnimation()
        return btn
    }()
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
        setUpLayers()
        AnimateTrackLayer()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        buttonState = .forward
        addSubview(forwardBtnView)
        forwardBtnView.addSubview(forwardBtn)
    }
    
    func setUpContraints(){
        forwardBtnView.pin(to: self)
        NSLayoutConstraint.activate([
            forwardBtn.centerXAnchor.constraint(equalTo: centerXAnchor),
            forwardBtn.centerYAnchor.constraint(equalTo: centerYAnchor),
            forwardBtn.widthAnchor.constraint(equalToConstant: 60),
            forwardBtn.heightAnchor.constraint(equalToConstant: 60)
        ])
    }
    
    func setUpLayers(){
        let circularPath = UIBezierPath(arcCenter: CGPoint(x: 40, y: 40), radius: 37, startAngle: -CGFloat.pi / 2, endAngle: 2 * CGFloat.pi, clockwise: true)
        
        let circleLayer = CAShapeLayer()
        circleLayer.strokeColor = Constants.Colors.appGray.cgColor
        circleLayer.fillColor = UIColor.clear.cgColor
        circleLayer.lineWidth = 3
        circleLayer.lineCap = .round
        circleLayer.path = circularPath.cgPath
        forwardBtnView.layer.addSublayer(circleLayer)
        
        trackLayer.strokeColor = UIColor.black.cgColor
        trackLayer.fillColor = UIColor.clear.cgColor
        trackLayer.lineWidth = 4
        trackLayer.strokeEnd = 0
        trackLayer.path = circularPath.cgPath
        forwardBtnView.layer.addSublayer(trackLayer)
    }
    
    func AnimateTrackLayer() {
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(duration), target: self, selector: #selector(animationCompleted), userInfo: nil, repeats: false)
        changeTimer = Timer.scheduledTimer(timeInterval: Double(duration) / Double(pageCount), target: self, selector: #selector(changeCell), userInfo: nil, repeats: true)
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = 0
        animation.toValue = 0.81
        animation.duration = CFTimeInterval(duration)
        animation.fillMode = .forwards
        animation.isRemovedOnCompletion = true
        trackLayer.add(animation, forKey: "dashAnimation")
    }
    
    func updateUI(){
        timer.invalidate()
        changeTimer.invalidate()
        cellCount = 0
        buttonState = .forward
        forwardBtn.alpha = 1
        forwardBtn.setBackgroundImage(UIImage(named: "ic_forward"), for: .normal)
        AnimateTrackLayer()
    }
    
    // MARK: ACTIONS -
    
    @objc func forwardBtnPressed(){
        if buttonState == .forward {
            delegate?.didForwardBtnTapped()
        } else {
            buttonState = .forward
            delegate?.didReloadTapped()
        }
    }
    
    @objc func animationCompleted(){
        buttonState = .reload
        forwardBtn.alpha = 0
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) { [self] in
            forwardBtn.setBackgroundImage(UIImage(named: "ic_reload"), for: .normal)
            forwardBtn.alpha = 0.8
        }
        delegate?.isAnimationCompleted()
    }
    
    @objc func changeCell(){
        cellCount += 1
        if cellCount == pageCount {
            changeTimer.invalidate()
        }
        if cellCount != pageCount {
            let index = IndexPath(row: cellCount, section: 0)
            delegate?.scrollToIndex(index)
        }
    }
    
}
