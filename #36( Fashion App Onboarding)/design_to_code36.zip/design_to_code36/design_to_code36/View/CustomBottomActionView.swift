//
//  CustomBottomActionView.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

protocol CustomBottomActionDelegate {
    func didNextBtnTapped()
    func didScrollTapped(_ index: IndexPath , _ animate: Bool)
    func didReloadTapped()
    func isAnimationCompleted()
}

class CustomBottomActionView: UIView {

    // MARK: PROPERTIES -
    var delegate: CustomBottomActionDelegate?
    
    var buttonCenterAlignConstraint: NSLayoutConstraint?
    var buttonLeadingConstraints: NSLayoutConstraint?
    
    lazy var customButtonView: CustomNextButtonView = {
        let v = CustomNextButtonView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.delegate = self
        return v
    }()
    
    let nextButton: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setBackgroundImage(UIImage(named: "ic_forward"), for: .normal)
        btn.transform = CGAffineTransform(scaleX: 0.3, y: 0.3)
        btn.alpha = 0
        btn.addTarget(self, action: #selector(nextBtnTapped), for: .touchUpInside)
        btn.addPressAnimation()
        return btn
    }()
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        addSubview(nextButton)
        addSubview(customButtonView)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            customButtonView.centerYAnchor.constraint(equalTo: centerYAnchor),
            customButtonView.widthAnchor.constraint(equalToConstant: 80),
            customButtonView.heightAnchor.constraint(equalToConstant: 80),
            
            nextButton.centerYAnchor.constraint(equalTo: centerYAnchor),
            nextButton.widthAnchor.constraint(equalToConstant: 70),
            nextButton.heightAnchor.constraint(equalToConstant: 70),
            nextButton.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
        
        buttonCenterAlignConstraint = customButtonView.centerXAnchor.constraint(equalTo: centerXAnchor)
        buttonCenterAlignConstraint?.isActive = true
    }
    
    @objc func nextBtnTapped(){
        delegate?.didNextBtnTapped()
    }

}

extension CustomBottomActionView: NextButtonDelegate {
    
    func scrollToIndex(_ index: IndexPath) {
        delegate?.didScrollTapped(index, false)
    }
    
    func isAnimationCompleted() {
        
        delegate?.isAnimationCompleted()
        
        buttonCenterAlignConstraint?.isActive = false
        buttonLeadingConstraints = customButtonView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20)
        buttonLeadingConstraints?.isActive = true
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) { [self] in
            layoutIfNeeded()
            customButtonView.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
            nextButton.alpha = 1
            nextButton.transform = .identity
        }
    }
    
    func didReloadTapped() {

        delegate?.didReloadTapped()
        
        /// Taking back to first cell
        let index = IndexPath(row: 0, section: 0)
        delegate?.didScrollTapped(index, false)
        
        buttonLeadingConstraints?.isActive = false
        buttonCenterAlignConstraint = customButtonView.centerXAnchor.constraint(equalTo: centerXAnchor)
        buttonCenterAlignConstraint?.isActive = true
        UIView.animate(withDuration: 0.3, delay: 0, options: .curveEaseInOut) { [self] in
            layoutIfNeeded()
            customButtonView.transform = .identity
            nextButton.alpha = 0
            nextButton.transform = CGAffineTransform(scaleX: 0.3, y: 0.3)
        } completion: { [self] finished in
            customButtonView.updateUI()
        }
        
    }
    
    func didForwardBtnTapped() {
        delegate?.didNextBtnTapped()
    }
    
}
