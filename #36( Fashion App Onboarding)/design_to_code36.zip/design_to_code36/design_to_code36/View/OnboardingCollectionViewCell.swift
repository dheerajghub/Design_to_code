//
//  OnboardingCollectionViewCell.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

class OnboardingCollectionViewCell: UICollectionViewCell {
    
    // MARK: PROPERTIES -
    
    var data: OnboardingData? {
        didSet {
            manageData()
        }
    }
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "card2")
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    lazy var descriptionText: UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.attributedText = setAttributedString("Explore Fashion", "Explore the 2020’s hottest fashion, jewellery, accessories and more...")
        l.textAlignment = .center
        l.numberOfLines = 0
        return l
    }()
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        addSubview(cardImage)
        addSubview(descriptionText)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            
            cardImage.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            cardImage.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            cardImage.topAnchor.constraint(equalTo: topAnchor, constant: 20),
            cardImage.bottomAnchor.constraint(equalTo: descriptionText.topAnchor, constant: -20),
            
            descriptionText.bottomAnchor.constraint(equalTo: bottomAnchor),
            descriptionText.heightAnchor.constraint(equalToConstant: 120),
            descriptionText.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 40),
            descriptionText.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -40)
        ])
    }
    
    func setAttributedString(_ title: String , _ subtitle: String) -> NSAttributedString {
        let attributedText = NSMutableAttributedString(string: "\(title)\n", attributes: [NSAttributedString.Key.foregroundColor: Constants.Colors.appPrimaryText, NSAttributedString.Key.font: UIFont(name: Constants.Fonts.appAliceFont, size: 27)!])
        
        attributedText.append(NSAttributedString(string: "\n", attributes: [NSAttributedString.Key.font: UIFont(name: "Avenir", size: 10)!]))

        attributedText.append(NSAttributedString(string:"\(subtitle)", attributes: [NSAttributedString.Key.foregroundColor: Constants.Colors.appSecondaryText, NSAttributedString.Key.font: UIFont(name: "Avenir", size: 16)!]))
        return attributedText
    }
    
    func manageData(){
        guard let data = data else { return }
        cardImage.image = UIImage(named: data.image)
        descriptionText.attributedText = setAttributedString(data.title, data.subtitle)
    }
    
    func animateContent(){
        descriptionText.alpha = 0
        descriptionText.center.y += 70
        cardImage.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
        cardImage.alpha = 0
        UIView.animate(withDuration: 1, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseIn, animations: { [self] in
            descriptionText.alpha = 1
            cardImage.alpha = 1
            descriptionText.center.y -= 70
            cardImage.transform = .identity
        })
    }
    
}
