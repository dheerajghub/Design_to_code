//
//  CustomFinalView.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

class CustomFinalView: UIView {

    // MARK: PROPERTIES -
    
    let cardImage: UIImageView = {
        let img = UIImageView()
        img.translatesAutoresizingMaskIntoConstraints = false
        img.image = UIImage(named: "exploreCard")
        img.contentMode = .scaleAspectFit
        return img
    }()
    
    let titleText: UIButton = {
        let btn = UIButton()
        btn.translatesAutoresizingMaskIntoConstraints = false
        btn.setTitle("Explore", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont(name: Constants.Fonts.appAliceFont, size: 40)
        btn.backgroundColor = .black.withAlphaComponent(0.7)
        btn.layer.cornerRadius = 10
        btn.contentEdgeInsets = UIEdgeInsets(top: 10, left: 20, bottom: 10, right: 20)
        return btn
    }()
    
    // MARK: MAIN -
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpViews()
        setUpContraints()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        addSubview(cardImage)
        addSubview(titleText)
    }
    
    func setUpContraints(){
        cardImage.pin(to: self)
        NSLayoutConstraint.activate([
            titleText.centerYAnchor.constraint(equalTo: centerYAnchor),
            titleText.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }

}
