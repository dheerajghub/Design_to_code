//
//  Constants.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

struct Constants {
    
    struct Colors {
        static let appGray = UIColor(red: 241/255, green: 243/255, blue: 246/255, alpha: 1)
        static let appPrimaryText = UIColor(red: 16/266, green: 16/255, blue: 16/255, alpha: 1)
        static let appSecondaryText = UIColor(red: 112/255, green: 116/255, blue: 147/255, alpha: 1)
    }
    
    struct Fonts {
        static let appAliceFont = "Alice-Regular"
    }

}
