//
//  HomeViewController.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

class HomeViewController: UIViewController {

    // MARK: PROPERTIES -
    
    let titleLabel:UILabel = {
        let l = UILabel()
        l.translatesAutoresizingMaskIntoConstraints = false
        l.text = "HomePage"
        l.font = UIFont(name: Constants.Fonts.appAliceFont, size: 40)
        l.textColor = .black
        l.textAlignment = .center
        return l
    }()
    
    // MARK: MAIN -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigations()
        setUpViews()
        setUpContraints()
    }
    
    // MARK: FUNCTIONS -
    
    func setUpViews(){
        view.backgroundColor = .white
        view.addSubview(titleLabel)
    }
    
    func setUpContraints(){
        titleLabel.pin(to: view)
    }
    
    func setUpNavigations(){
        navigationController?.navigationBar.barTintColor = .white
        navigationController?.navigationBar.shadowImage = UIImage()
        
        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(named: "")?.withRenderingMode(.alwaysTemplate), for: .normal)
        backButton.tintColor = .black
        backButton.frame = CGRect(x: 0, y: 0, width: 35, height: 35)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButton)
        backButton.addTarget(self, action: #selector(backBtnPressed), for: .touchUpInside)
    }
    
    @objc func backBtnPressed(){
        navigationController?.popViewController(animated: true)
    }

}
