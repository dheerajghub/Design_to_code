//
//  ViewController.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import UIKit

class ViewController: UIViewController {

    // MARK: PROPERTIES -
    
    lazy var collectionView: UICollectionView = {
        let layout:UICollectionViewFlowLayout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout.init())
        cv.setCollectionViewLayout(layout, animated: false)
        cv.translatesAutoresizingMaskIntoConstraints = false
        cv.delegate = self
        cv.dataSource = self
        cv.register(OnboardingCollectionViewCell.self, forCellWithReuseIdentifier: "OnboardingCollectionViewCell")
        cv.backgroundColor = .clear
        cv.showsHorizontalScrollIndicator = false
        cv.isPagingEnabled = true
        cv.isScrollEnabled = false
        return cv
    }()
    
    lazy var bottomNavView: CustomBottomActionView = {
        let v = CustomBottomActionView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.delegate = self
        return v
    }()
    
    let finalView: CustomFinalView = {
        let v = CustomFinalView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.backgroundColor = .white
        v.isHidden = true
        v.alpha = 0
        return v
    }()
    
    // MARK: MAIN -
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavigations()
        setUpViews()
        setUpContraints()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        /// When View appear againt set to first cell
        let index = IndexPath(row: 0, section: 0)
        collectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: false)
    }
    
    // MARK: FUNCTIONS -
    
    func setUpNavigations(){
        navigationController?.navigationBar.barTintColor = .white
        navigationController?.navigationBar.shadowImage = UIImage()
        
        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(named: "ic_back")?.withRenderingMode(.alwaysTemplate), for: .normal)
        backButton.tintColor = .black
        backButton.frame = CGRect(x: 0, y: 0, width: 35, height: 35)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: backButton)
        backButton.addTarget(self, action: #selector(backBtnPressed), for: .touchUpInside)
    }
    
    func setUpViews(){
        view.backgroundColor = .white
        view.addSubview(collectionView)
        view.addSubview(bottomNavView)
        view.addSubview(finalView)
    }
    
    func setUpContraints(){
        NSLayoutConstraint.activate([
            bottomNavView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            bottomNavView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bottomNavView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bottomNavView.heightAnchor.constraint(equalToConstant: 150),
            
            collectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            collectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            collectionView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            collectionView.bottomAnchor.constraint(equalTo: bottomNavView.topAnchor),
            
            finalView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            finalView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            finalView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            finalView.bottomAnchor.constraint(equalTo: bottomNavView.topAnchor)
        ])
    }
    
    // MARK: ACTIONS -
    
    @objc func backBtnPressed(){
        /// Back btn
    }

}

extension ViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return onboardingDummyData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnboardingCollectionViewCell", for: indexPath) as! OnboardingCollectionViewCell
        cell.data = onboardingDummyData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        DispatchQueue.main.async {
            if let cell = collectionView.cellForItem(at: indexPath) as? OnboardingCollectionViewCell {
                cell.animateContent()
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
}

extension ViewController: CustomBottomActionDelegate {
    
    func didReloadTapped() {
        collectionView.reloadData()
        UIView.animate(withDuration: 0.3) { [self] in
            finalView.alpha = 0
        } completion: { [self] finished in
            finalView.isHidden = true
        }
    }
    
    func isAnimationCompleted() {
        finalView.isHidden = false
        UIView.animate(withDuration: 0.5) { [self] in
            finalView.alpha = 1
        }
    }
    
    func didScrollTapped(_ index: IndexPath , _ animate: Bool) {
        collectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: animate)
    }
    
    func didNextBtnTapped() {
        let VC = HomeViewController()
        navigationController?.pushViewController(VC, animated: true)
    }
    
}

