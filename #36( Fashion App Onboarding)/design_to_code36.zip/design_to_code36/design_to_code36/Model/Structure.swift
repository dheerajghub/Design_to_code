//
//  Structure.swift
//  design_to_code36
//
//  Created by Dheeraj Kumar Sharma on 08/08/21.
//

import Foundation

struct OnboardingData {
    let image: String!
    let title: String!
    let subtitle: String!
}

let onboardingDummyData = [
    OnboardingData(image: "card1", title: "Explore Fashion", subtitle: "Explore the 2021’s hottest fashion, jewellery, accessories and more..."),
    OnboardingData(image: "card2", title: "Select what you love", subtitle: "Exclusively curated selection of top brands in the palm of your hand..."),
    OnboardingData(image: "card3", title: "Be the real you", subtitle: "It brings you the latest trends and products from all over the world...")
]
